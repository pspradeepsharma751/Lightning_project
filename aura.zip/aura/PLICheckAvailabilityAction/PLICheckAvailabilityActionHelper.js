({
	doInit: function(component) {
        var action = component.get("c.getPLIRecord");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                var record = JSON.parse(response.getReturnValue());
                component.set('v.PLIRecord', record);
                
            }
            else if(state === 'ERROR') {
              var errorMessage = response.getError()[0].message;
            }
      });
      $A.enqueueAction(action);
    },
    
    validateLineItem: function(component){
        var lineItemType = component.get('v.PLIRecord.adsalescloud__Line_Item_Type__c');
        var productType = component.get('v.PLIRecord.adsalescloud__Product_Type__c');
        var endDate = component.get('v.PLIRecord.adsalescloud__End_Date__c');
        var endDateTime = this.getDateObjectInSpecificTimezone(component.get('v.PLIRecord.adsalescloud__End_Date__c'), component.get('v.PLIRecord.adsalescloud__Time_Zone__c'));
        var currentTime = new Date();
        if((lineItemType != 'Standard' && lineItemType != 'Sponsorship') || (productType != 'DFP Ads')){
            component.set("v.toast", {"message": "Check Availability is only available for DFP standard or sponsorship lineItems. Other product types or line item types are not allowed.", "type" : "error", "closable" : true, "autoHide" : false});
            component.set("v.hasErrors", true);
        }
        else if(endDateTime < currentTime ){
            component.set("v.toast", {"message": "End Date must be in the future to Check Availability", "type" : "error", "closable" : true, "autoHide" : false});
            component.set("v.hasErrors", true);
        }
        else
            component.set("v.hasErrors", false);
            
        
    }
})