({
    
    validateRecord: function(component){
        var endDateTime = component.get('v.endDateTime');
        endDateTime = this.getDateObjectInSpecificTimezone(endDateTime, timeZone);
        var currentTime = new Date();
        if(endDateTime < currentTime ){
            //component.set("v.toast", {"message": "End Date must be in the future to Forecast.", "type" : "error", "closable" : true, "autoHide" : true});
            component.set('v.error', 'End Date must be in the future to Forecast');
            component.set('v.loading',false);
        }
        else
            this.getAvailabilityForecast(component);
    },  
    
    getAvailabilityForecast: function(component) {
        var recordId = component.get('v.recordId');
        this.fetchData(component, 'getForecastAvailability',
                       {
                           recordId: recordId,
                           apiName: component.get('v.sobjectName'),
                           isForecastingSummary:component.get('v.isForeCastSummary'),
                           isMaxAvailable:component.get('v.isMaxAvailable')  
                       }, function(res) {
                           if(res.status === 'OK') {
                               component.set('v.data', res.data);
                               component.set('v.lineItemType', res.lineItemType.toLowerCase()); 
                               component.set('v.goalType', res.goalType); 
                               component.set('v.quantity', res.quantity);
                               component.set('v.unitType', res.unitType);  
                               if(component.get('v.isForeCastSummary')) {
                                   if(component.get('v.getTargetingCriteriaBreakdowns')) { 
                                       Object.keys(res.targetingCriteriaBreakdowns).forEach(function(key){
                                           res.targetingCriteriaBreakdowns[key].forEach(function(targetingCriteriaBreakdown){
                                               targetingCriteriaBreakdown['targetingCriteriaName'] = (targetingCriteriaBreakdown.targetingCriteriaName || '0') + '';
                                               targetingCriteriaBreakdown['availableUnits'] = (targetingCriteriaBreakdown.availableUnits || '0') + '';
                                               targetingCriteriaBreakdown['matchedUnits'] = (targetingCriteriaBreakdown.matchedUnits || '0') + '';
                                           });
                                       });
                                       component.set('v.targetingCriteriaBreakdowns', res.targetingCriteriaBreakdowns);
                                   }
                                   res.contendingLineItems.forEach(function(contendingLineItem){
                                       contendingLineItem['lineItemId'] = (contendingLineItem.lineItemId || '0') + '';
                                       contendingLineItem['pliName'] = (contendingLineItem.pliName || '') + '';
                                       contendingLineItem['pliId'] = (contendingLineItem.pliId || '') + '';
                                       contendingLineItem['advertiserName'] = (contendingLineItem.advertiserName || '') + '';
                                       contendingLineItem['contendingImpressions'] = (contendingLineItem.contendingImpressions || '0') + '';
                                   });
                                   component.set('v.contendingLineItems', res.contendingLineItems);
                                   //component.set('v.data3',res.alternativeUnitTypeForecasts);
                               }
                           } else {
                               component.set('v.error', res.message);
                           }
                           component.set('v.loading',false);
                       });
        
    }
});