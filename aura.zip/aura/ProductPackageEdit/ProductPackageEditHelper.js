({
  doInitialize: function(component) {

    this.fetchData(component, 'getProductPackageRecord',
      {
        'recordId': component.get('v.recordId')
      },
      function(response) {
        if(response) {
          var record = JSON.parse(response['DefaultFields']);
          var packageProductList = response['PackageProducts'];
          var packagePriceBook = response['PackagePriceBook'];
          component.set('v.packageProductList', packageProductList);
            component.set('v.record', record);    
          component.set('v.allPriceBookMap', packagePriceBook);
        }
      });
  },
  redirectToRecord: function(component) {
    var recordId = component.get('v.recordId');
    if($A.util.isEmpty(recordId) || component.get('v.isListViewProductPackageEdit')) {
      var homeEvent = $A.get('e.force:navigateToObjectHome');
      homeEvent.setParams({
        'scope': 'adsalescloud__Ad_Sales_Product_Package__c'
      });
      homeEvent.fire();

    }
    else {
      $A.get('e.force:closeQuickAction').fire();
    }

  },

  validateRecord: function(component) {
    var productPackageObj = component.get('v.record');
    var packageProduct = component.get('v.packageProductList');
    var errorMessage = '';
    var isValid = true;
    if(packageProduct) {
      for(var row = 0; row < packageProduct.length; row++) {
        if(packageProduct[row]) {
          for(var col = 0; col < packageProduct[row]['packageProductRate'].length; col++) {
            if(!packageProduct[row]['packageProductRate']
              || packageProduct[row]['packageProductRate'][col]['netRate'] === null
              || packageProduct[row]['packageProductRate'][col]['netRate'] === 'undefined'
              || packageProduct[row]['packageProductRate'][col]['netRate'] < 0) {
              isValid = false;
              errorMessage = 'Package Product\'s net rate should be greater than or equal to 0.';
              break;
            }
          }
        } else {
          isValid = false;
          errorMessage = 'Package Product\'s net rate should be greater than or equal to 0.';
          break;
        }
      }
    }

    if(!productPackageObj['Name'] || !productPackageObj['Name'].trim()) {
      isValid = false
      errorMessage = 'Package Name can\'t be Empty';
    }
    if(!isValid) {
      this.showToast(component, 'Error', errorMessage, 'error');
      return false;
    }
    return true;
  },

  onSave: function(component) {
    var productPackageObj = component.get('v.record');
    var selectedPriceBook = JSON.stringify(component.get('v.selectedPriceBookList'));
    var packageProduct = JSON.stringify(component.get('v.packageProductList'));
    var productPackageRecord = JSON.stringify(productPackageObj);
    var action = component.get('c.upsertRecord');
    action.setParams({
      productPackageRecord: productPackageRecord,
      selectedPriceBook: selectedPriceBook,
      packageProduct: packageProduct
    });

    action.setCallback(this, function(response) {
      var state = response.getState();
      if(state === 'SUCCESS') {
        var resp = response.getReturnValue();
        var record = component.get('v.record');
        var r_id = response.getReturnValue().IsSuccess;
        component.set('v.recordId', r_id);
        /*if(r_id) {
          document.location.href = '/' + r_id;
        } else {
          //$A.get('e.force:refreshView').fire();
          $A.get('e.force:closeQuickAction').fire();
        }*/
        if(r_id) {
          if(component.get('v.isListViewProductPackageEdit')) {
            var navEvt = $A.get('e.force:navigateToSObject');
            navEvt.setParams({
              'recordId': r_id,
              'slideDevName': 'detail'
            });
            navEvt.fire();
          }
          else {
            var toastEvent = $A.get('e.force:showToast');
            toastEvent.setParams({
              'title': 'Success!',
              'type': 'success',
              'message': 'Record updated successfully.'
            });
            toastEvent.fire();
            $A.get('e.force:refreshView').fire();
            $A.get('e.force:closeQuickAction').fire();
          }
        }
        else {
            if(r_id){
                var navEvt = $A.get('e.force:navigateToSObject');
                navEvt.setParams({
                    'recordId': r_id,
                    'slideDevName': 'detail'
                });
                navEvt.fire(); 
            }  else {
                component.set('v.disableButtons', false);
                var errors = resp.message;
                if(errors) {
                    this.showToast(component, 'Error', resp.errorResults[0].message, 'error');
                } else {
                    this.showToast(component, 'Error', 'Unknown error', 'error');
                }
            }
        }

      } else if(state === 'ERROR') {
        component.set('v.disableButtons', false);
        var errors = response.getError();
        if(errors) {
          if(errors[0] && errors[0].message) {
            this.showToast(component, 'Error', errors[0].message, 'error');
          }
        } else {
          this.showToast(component, 'Error', 'Unknown error', 'error');
        }
      }
    });
    $A.enqueueAction(action);
  },

  showToast: function(component, title, message, type) {
    component.set('v.toastTitle', title);
    component.set('v.message', message);
    component.set('v.messageType', type);
    component.set('v.showToast', true);
  },
  updateProductList: function(component) {
    var selectedPriceBook = component.get('v.selectedPriceBookList');
    var packageProductList = component.get('v.packageProductList');
    var priceBookNameMap = component.get('v.allPriceBookMap')['standardPriceBook'];
    var productPriceBookIdList = [];
    var productPriceBookToAdd = [];
    if(packageProductList && packageProductList[0] && packageProductList[0].packageProductRate) {
      for(var index = 0; index < packageProductList[0].packageProductRate.length; index++) {
        if(packageProductList[0].packageProductRate[index].priceBookId) {
          productPriceBookIdList.push(packageProductList[0].packageProductRate[index].priceBookId);
        }
      }
    }

    for(var index = 0; index < selectedPriceBook.length; index++) {
      if(productPriceBookIdList.indexOf(selectedPriceBook[index]) === -1) {
        productPriceBookToAdd.push({
          'id': '',
          'priceBookName': priceBookNameMap[selectedPriceBook[index]].Name,
          'netRate': 0,
          'packagePriceBookId': selectedPriceBook[index],
          'priceBookId': priceBookNameMap[selectedPriceBook[index]].Id
        });
      }
    }

    for(var row = 0; row < packageProductList.length; row++) {
      var packageProductRateList = [];
      for(var col in packageProductList[row].packageProductRate) {
        if(selectedPriceBook.indexOf(packageProductList[row].packageProductRate[col].priceBookId) !== -1) {
          packageProductRateList.push(packageProductList[row].packageProductRate[col]);
        }
      }
      packageProductList[row].packageProductRate = packageProductRateList.concat(JSON.parse(JSON.stringify(productPriceBookToAdd)));
    }
    component.set('v.packageProductList', packageProductList);
  },

  addPriceBookOnProducts: function(component, event) {
    var selectedPriceBook = component.get('v.selectedPriceBookList');
    var eventPricebookList = event.getParam('packageProductList');
    var priceBookNameMap = component.get('v.allPriceBookMap')['standardPriceBook'];
    var productPriceBookToAdd = [];
    var packageProductList = component.get('v.packageProductList');
    if(eventPricebookList) {
      packageProductList = packageProductList.concat(JSON.parse(JSON.stringify(eventPricebookList)));
    }
    for(var index = 0; index < selectedPriceBook.length; index++) {
      productPriceBookToAdd.push({
        'id': '',
        'priceBookName': priceBookNameMap[selectedPriceBook[index]].Name,
        'netRate': 0,
        'packagePriceBookId': selectedPriceBook[index],
        'priceBookId': priceBookNameMap[selectedPriceBook[index]].Id
      });
    }
    for(var row = 0; row < packageProductList.length; row++) {
      if(packageProductList[row].id === '' && (packageProductList[row].packageProductRate === null || packageProductList[row].packageProductRate.length <= 0)) {
        packageProductList[row].packageProductRate = JSON.parse(JSON.stringify(productPriceBookToAdd));
      }
    }
    component.set('v.packageProductList', packageProductList);

  },

  getObjKeyPrefix: function(component) {
    var actionTogetObjKeyPrefix = component.get('c.getObjKeyPrefix');

    actionTogetObjKeyPrefix.setCallback(this,
      function(response) {
        var state = response.getState();
        if(state === 'SUCCESS') {
          component.set('v.customObjectId', response.getReturnValue());
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
        }
      }
    );
    $A.enqueueAction(actionTogetObjKeyPrefix);
    //return objId;
  }
});