({
  doInitialize: function(component, event, helper) {
    component.set('v.cval', '<style>.slds-modal__container{min-width: 60rem;}section .panel .closeIcon{display:none}</style>');
    helper.doInitialize(component);
  },

  onSave: function(component, event, helper) {
    component.set('v.disableButtons', true);
    if(helper.validateRecord(component)) {
      helper.onSave(component);
    } else {
      component.set('v.disableButtons', false);
    }
  },

  onCancel: function(component, event, helper) {
    helper.redirectToRecord(component);
  },

  updateProductList: function(component, event, helper) {
    helper.updateProductList(component);
  },

  addPriceBookOnProducts: function(component, event, helper) {
    helper.addPriceBookOnProducts(component, event, helper);
  }

});