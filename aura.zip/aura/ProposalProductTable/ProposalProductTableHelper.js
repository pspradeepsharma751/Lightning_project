({
  checkUiEnvironment: function(component) {
    if(window.location.host.indexOf('lightning') >= 0) {
      component.set('v.lightning', true);
      var os = navigator.appVersion;
      if(os.indexOf('Macintosh') !== -1){
        component.set('v.specificClass', 'slds-scrollable');
      }
      else if(os.indexOf('Windows') !== -1){
        component.set('v.specificClass', '');
      }
    }
    else{
      component.set('v.specificClass', 'slds-scrollable cTableContainerWidth');
    }

  },
  setStartEndDates: function(component) {
    var startDate = new Date();
    var endDate = new Date();
    startDate.setDate(startDate.getDate() + 2);
    startDate.setHours(0);
    startDate.setMinutes(0 - (new Date().getTimezoneOffset() + component.get('v.timezoneOffsetMinutes')));
    startDate.setSeconds(0);
    endDate.setMonth(startDate.getMonth() + 1);
    endDate.setDate(startDate.getDate());
    endDate.setHours(23);
    endDate.setMinutes(59 - (new Date().getTimezoneOffset() + component.get('v.timezoneOffsetMinutes')));
    endDate.setSeconds(0);

    var proposalItems = component.get('v.proposal_items');
    proposalItems.forEach(function(item) {
      item.start_date = startDate.toISOString();
      item.end_date = endDate.toISOString();
    });
    component.set('v.proposal_items', proposalItems);
  },
  validateRequiredField: function(component) {
    var proposalItems = component.get('v.proposal_items');
    var isValid = true;
    proposalItems.forEach(function(proposalItem) {
      /*proposalItem.errors['quantity'] = '';
      proposalItem.errors['start_date'] = '';
      proposalItem.errors['end_date'] = '';*/
      proposalItem.errors = {
        'net_rate': {'error': '', 'msg': ''},
        'gross_rate': {'error': '', 'msg': ''},
        'quantity': {'error': '', 'msg': ''},
        'goal': {'error': '', 'msg': ''},
        'end_date': {'error': '', 'msg': ''},
        'start_date': {'error': '', 'msg': ''}
      };
      if($A.util.isEmpty(proposalItem.net_rate)) {
        isValid = false;
        proposalItem.errors.net_rate.error = 'requiredErrorField';
        proposalItem.errors.net_rate.msg = 'Value is required';
      } else if(proposalItem.net_rate < 0) {
        isValid = false;
        proposalItem.errors.net_rate.error = 'requiredErrorField';
        proposalItem.errors.net_rate.msg = 'Must be greater th';
        proposalItem.errors.gross_rate.msg = 'an or equal to 0';
      }
      if($A.util.isEmpty(proposalItem.gross_rate)) {
        isValid = false;
        proposalItem.errors.gross_rate.error = 'requiredErrorField';
        proposalItem.errors.gross_rate.msg = 'Value is required';
      }
      if(!$A.util.isEmpty(proposalItem.quantity) && proposalItem.quantity < 1) {
        isValid = false;
        proposalItem.errors.quantity.error = '';
        proposalItem.errors.quantity.msg = 'Minimum value 1';
      }
      if($A.util.isEmpty(proposalItem.quantity)) {
        isValid = false;
        proposalItem.errors.quantity.error = 'requiredErrorField';
        proposalItem.errors.quantity.msg = 'Value is required';
      }
      if(!proposalItem.start_date) {
        isValid = false;
        proposalItem.errors.start_date.error = 'requiredErrorField';
        proposalItem.errors.start_date.msg = '';  // default error message of lightning:input will be rendered

      }
      if(!proposalItem.end_date) {
        isValid = false;
        proposalItem.errors.end_date.error = 'requiredErrorField';
        proposalItem.errors.end_date.msg = '';  // default error message of lightning:input will be rendered
      }
      if(proposalItem.start_date && proposalItem.end_date) {
        if(!$A.localizationService.isBefore(proposalItem.start_date, proposalItem.end_date)) {
          isValid = false;
          proposalItem.errors.start_date.error = 'requiredErrorField';
          proposalItem.errors.start_date.msg = 'Start Date must be earlier than End Date';
        }
      }
    });
    if(!isValid) {
      this.renderErrors(component, proposalItems);
    }
    return isValid;
  },
  renderErrors: function(component, opportunityItems) {
    var errorMessage = 'There were errors while saving your records';
    if($A.util.isEmpty(component.get('v._error'))) {
      component.set('v._error', errorMessage);
    }
    component.set('v.proposal_items', opportunityItems);
  },
  handleErrorOfOppItemsCreation: function(response, component) {
    var results = response.errorResults;
    var opportunityItems = component.get('v.proposal_items');
    for(var key in results) {
      if(key === 'remove') {continue;}
      var result = results[key];
      var fields = result.fields;
      if($A.util.isEmpty(fields) || fields === 'null') {
        component.set('v._error', result.message);
        continue;
      }
      fields = fields.replace('(', '');
      fields = fields.replace(')', '');
      var opportunityItem = opportunityItems[result.index];
      opportunityItem.errors.quantity = '';
      opportunityItem.errors.salesPrice = '';
      opportunityItem.errors.serviceDate = '';
      opportunityItem.errors.description = '';
      if(fields.indexOf('Quantity') !== -1) {
        opportunityItem.errors.quantity = 'requiredErrorField';
      }
      /*if(fields.indexOf('UnitPrice') !== -1){
          opportunityItem.errors.salesPrice = 'requiredErrorField';
      }
      if(fields.indexOf('ServiceDate') !== -1){
          opportunityItem.errors.serviceDate = 'requiredErrorField';
      }
      if(fields.indexOf('Description') !== -1){
          opportunityItem.errors.description = 'requiredErrorField';
      }*/
      opportunityItem.errors.message = result.message;
    }
    this.renderErrors(component, opportunityItems);
  },
  fireHandlePropProductsEvent: function(component, command) {
    var handlePropProducts = component.getEvent('handlePropProducts');
    handlePropProducts.setParams({
      'command': command
    });
    handlePropProducts.fire();
  }
});