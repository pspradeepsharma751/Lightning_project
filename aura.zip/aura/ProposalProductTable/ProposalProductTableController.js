({
  doInit: function(component, event, helper) {
    component.set('v.isLightning', window.location.host.indexOf('lightning')>=0? true: false);
    helper.checkUiEnvironment(component);
    helper.setStartEndDates(component);
    component.set('v.style', '<style> .slds-modal__container { max-width: 70%;width: 70% !important;}.slds-tabs__nav-scroller {display: none;} .slds-tabs_default__nav{width: calc(70vw - 17px) !important;}</style>');
  },
  cancel: function(component, event, helper) {
    component.set('v._error', '');
    helper.fireHandlePropProductsEvent(component, 'cancel');
  },
  save: function(component, event, helper) {
    if(helper.validateRequiredField(component)) {
      component.set('v.disableButtons', true);
      helper.fireHandlePropProductsEvent(component, 'save');
    }
  },
  handleErrors: function(component, event, helper) {
    var response = event.getParam('arguments')._server_response;
    helper.handleErrorOfOppItemsCreation(response, component);
  },
  handleErrorChange: function(component, event, helper) {
    if(!$A.util.isEmpty(component.get('v._error'))) {
      component.set('v.disableButtons', false);
      window.setTimeout(function() {component.set('v._error', '');}, 3000);
    }
  },
  closeQuickAction: function() {
    $A.get('e.force:closeQuickAction').fire();
  },
});