({
  doInit: function(component) {
    var premiums = component.get('v.premiums');
    var self = this;
    self.fetchData(component, 'getPremiumValuesRecords', {
      'recordId': component.get('v.recordId') ? component.get('v.recordId') : null
    }, function(response) {
      if(response.status === 'OK') {
        component.set('v.premiumMap', response.premiumMap);
        component.set('v.product', response.product);
        if(response.premiumMap)
          self.recordChangeHandler(component);
      }
    });
  },
  recordChangeHandler: function(component) {
    var pli = component.get('v.record');
    var premiumMap = component.get('v.premiumMap');
    var pro = component.get('v.product');
    var premiums = component.get('v.premiums');
    var selectedPremiumMap = component.get('v.selectedPremiumMap');
    var premiumCategories = Object.keys(premiumMap);
    if(!premiums){
      premiums = [];
    }
    if(!selectedPremiumMap){
      selectedPremiumMap = {};
    }

    var categories = {'adsalescloud__Ad_Units_Targeting__c': 'Ad Units', 'adsalescloud__Placements_Targeting__c': 'Placements', 'adsalescloud__Geo_Targeting__c': 'Geography', 'adsalescloud__Bandwidth_Group_Targeting__c': 'Bandwidth', 'adsalescloud__Mobile_Carrier_Targeting__c': 'Mobile Carrier', 'adsalescloud__User_Domain_Targeting__c': 'User Domains', 'adsalescloud__Browser_Targeting__c': 'Browser', 'adsalescloud__Browser_Language_Targeting__c': 'Browser Language', 'adsalescloud__Device_Capability_Targeting__c': 'Device Capability', 'adsalescloud__Device_Category_Targeting__c': 'Device Category', 'adsalescloud__Operating_System_Targeting__c': 'Operating System', 'adsalescloud__Device_Manufacturer_Targeting__c': 'Manufacturer/Device', 'adsalescloud__Mobile_Devices_Targeting__c': 'Manufacturer/Device', 'adsalescloud__Mobile_Device_Submodels_Targeting__c': 'Manufacturer/Device', 'adsalescloud__Operating_System_Version_Targeting__c': 'Operating System'};
    var sub_categories = {'Manufacturer/Device': true, 'Operating System': true};

    try {
      for(var category in categories) {
        var premium_cat = categories[category];
        var isMatched = true;
        if(pli[category] && pro && pro[category]) {
          var selectedPliTargets = JSON.parse(pli[category].replace(/&quot;/g, '"'));
          var selectedProductTargets = JSON.parse(pro[category].replace(/&quot;/g, '"'));

          if(premiumCategories.indexOf(premium_cat) !== -1) {
            isMatched = this.compareSelectedTargets(selectedPliTargets, selectedProductTargets);
            if(sub_categories.hasOwnProperty(premium_cat)) {
              sub_categories[premium_cat] = sub_categories[premium_cat] && isMatched;
              continue;
            }

            if(isMatched) {
              delete selectedPremiumMap[premium_cat];
            }
            else if(!selectedPremiumMap[premium_cat]) {
              selectedPremiumMap[premium_cat] = this.newPremiumObject(premiumMap[premium_cat], pli['adsalescloud__List_Price__c']);
            }
          }
        } else if((pli[category] && pro && !pro[category]) || (!pli[category] && pro && pro[category])) {
          var selectedTargets;
          if(pro[category])
            selectedTargets = JSON.parse(pro[category].replace(/&quot;/g, '"'));
          else
            var selectedTargets = JSON.parse(pli[category].replace(/&quot;/g, '"'));

          if(premiumCategories.indexOf(premium_cat) !== -1) {
            if(sub_categories[premium_cat]) {
              sub_categories[premium_cat] = false;
            }
            if(!selectedPremiumMap[premium_cat]) {
              selectedPremiumMap[premium_cat] = this.newPremiumObject(premiumMap[premium_cat], pli['adsalescloud__List_Price__c']);
            }
          }

        } else {
          if(sub_categories[premium_cat]) {
            continue;
          }
          delete selectedPremiumMap[premium_cat];
        }
      }

      for(var category in sub_categories) {
        if(!sub_categories[category] && !selectedPremiumMap[category]) {
          selectedPremiumMap[category] = this.newPremiumObject(premiumMap[category], pli['adsalescloud__List_Price__c']);
        } else if(sub_categories[category]) {
          delete selectedPremiumMap[category];
        }
      }

    } catch(e) {console.log(e.message);}

    component.set('v.selectedPremiumMap', selectedPremiumMap);
    component.set('v.premiums', Object.values(selectedPremiumMap));
    this.recalculatePremiumCost(component);
  },
  compareSelectedTargets: function(selectedPliMap, selectedProductMap) {
    var includedPliList = selectedPliMap['included'];
    var excludedPliList = selectedPliMap['excluded'];
    var includedProductList = selectedProductMap['included'];
    var excludedProductList = selectedProductMap['excluded'];

    if(includedPliList.length !== includedProductList.length)
      return false;
    else {
      for(var ind=0; ind<includedPliList.length;ind++) {
        if(includedProductList.indexOf(includedPliList[ind]) === -1)
          return false;
      }
    }

    if(excludedPliList.length != excludedProductList.length)
      return false;
    else {
      for(var ind=0; ind<excludedPliList.length;ind++) {
        if(excludedProductList.indexOf(excludedPliList[ind]) === -1)
          return false;
      }
    }
    return true;
  },
  newPremiumObject: function(premium, listPrice) {
    var amount;
    if(premium.adsalescloud__Percent__c) {
      amount = listPrice * premium.adsalescloud__Percent__c / 100;
    }
    else
      amount = premium.adsalescloud__Amount__c;

    if(premium.adsalescloud__Rate_Type__c.includes('CPM')){
      amount *= 1000;
    }

    return {'feature': premium.adsalescloud__Premium_Feature__c, 'priceMethod': premium.adsalescloud__Pricing_Method__c, 'amount': amount, 'rateType': premium.adsalescloud__Rate_Type__c, 'paymentModel': premium.adsalescloud__Payment_model__c, 'percent': (premium.adsalescloud__Percent__c) ? premium.adsalescloud__Percent__c : 0, 'status': true};
  },
  recalculatePremiumCost: function(component) {
   var record = component.get('v.record');
    var premiums = component.get('v.premiums');
    var premiumJson = [];
    var premiumRate = 0;
    var premiumRateUnadjusted = 0;
    premiums.forEach(function(premium) {
      var pre = {};
      pre['premiumRateValue'] = {'premiumFeature': premium.feature, 'rateType': premium.rateType, 'adjustmentType': premium.paymentModel, 'adjustmentSize': premium.percent};
      pre['status'] = 'EXCLUDED';
      premiumRateUnadjusted += premium.amount;
      if(premium.status) {
        premiumRate += premium.amount;
        pre['status'] = 'INCLUDED';
      }
      premiumJson.push({'premiums': pre});
    });
    component.set('v.record.adsalescloud__Premium_Rate_Unadjusted__c', premiumRateUnadjusted);
    component.set('v.record.adsalescloud__Premium_Rate__c', premiumRate);
    component.set('v.record.adsalescloud__Listing_Rate__c', record.adsalescloud__List_Price__c + premiumRate);
    component.set('v.record.adsalescloud__Premium_Rate_Detail__c', JSON.stringify(premiumJson));
   // component.set('v.record', record);
  }

});