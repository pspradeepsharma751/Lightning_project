({
  doInit: function(component, event, helper) {
    helper.doInit(component);
  },
  recordChangeHandler: function(component, event, helper) {
    if(component.get('v.recordId')){
      helper.recordChangeHandler(component);
    }
  },
  recalculatePremiumCost: function(component, event, helper) {
    helper.recalculatePremiumCost(component);
  }
});