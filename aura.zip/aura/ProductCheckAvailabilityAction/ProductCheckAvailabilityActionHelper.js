({
	doInit: function(component) {
        var action = component.get("c.getProductRecord");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                var record = JSON.parse(response.getReturnValue());
                component.set('v.product2', record);
                var startDate = new Date();
                startDate.setDate(startDate.getDate()+2);
                startDate.setHours(0);
                startDate.setMinutes(0);
                startDate.setSeconds(0);
                var endDate = new Date();
                endDate.setDate(endDate.getDate()+2);
                endDate.setMonth(startDate.getMonth() + 1);
                endDate.setHours(23);
                endDate.setMinutes(59);
                endDate.setSeconds(59);
                component.set('v.startDate', startDate);
                component.set('v.endDate', endDate);
                
            }
            else if(state === 'ERROR') {
              var errorMessage = response.getError()[0].message;
            }
      });
      $A.enqueueAction(action);
    },
    
    validateProduct2: function(component){
        var lineItemType = component.get('v.product2.adsalescloud__Line_Item_Type__c');
        var productType = component.get('v.product2.adsalescloud__Product_Type__c');
        if((lineItemType != 'Standard' && lineItemType != 'Sponsorship') || (productType != 'DFP Ads')){
            component.set("v.toast", {"message": "Check Availability is only available for DFP standard or sponsorship lineItems. Other product types or line item types are not allowed.", "type" : "error", "closable" : true, "autoHide" : false});
            component.set("v.hasErrors", true);
        }
        else
            component.set("v.hasErrors", false);
            
        
    }
})