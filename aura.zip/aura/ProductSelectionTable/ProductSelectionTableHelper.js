({
  checkAllCheckBoxes: function(component, event, target) {
    var selectedProductMap = component.get('v.selectedProductMap');
    if(!selectedProductMap) {
      selectedProductMap = {};
    }
    var currentRecords = component.get('v.productCandidatesInCurrentPage');
    var checked = target.get('v.value');
    if(target.get('v.name') === 'selectAll') {
      this.checkCurrentRecordsCheckBoxes(selectedProductMap, currentRecords, checked);
    } else {
      var recordId = target.get('v.name');
      this.checkOneUnitWithId(selectedProductMap, currentRecords, recordId, checked);
      component.set('v.checkedAll', this.checkIfNeedToCheckAllCheckBoxes(selectedProductMap, currentRecords));
    }
    component.set('v.productCandidatesInCurrentPage', currentRecords);
    component.set('v.selectedProductMap', selectedProductMap);
  },

  checkCurrentRecordsCheckBoxes: function(selectedProductMap, currentRecords, checked) {
    for(var key in currentRecords) {
      currentRecords[key].isSelected = checked;
      this.checkOneUnit(selectedProductMap, currentRecords[key], checked);
    }
  },
  checkOneUnit: function(selectedProductMap, currentRecord, checked) {
    if(currentRecord.hasProducts) {
      for(var index in currentRecord.packageProductList) {
        if(currentRecord.packageProductList[index].id) {
          selectedProductMap[currentRecord.packageProductList[index].id] = checked;
          currentRecord.packageProductList[index].isSelected = checked;
        }
      }
    }
    if(currentRecord.id && !currentRecord.hasProducts) {
      selectedProductMap[currentRecord.id] = checked;
    }
  },

  checkOneUnitWithId: function(selectedProductMap, currentRecords, recordId, checked) {
    for(var key in currentRecords) {
      if(currentRecords[key].id === recordId && currentRecords[key].hasProducts) {
        currentRecords[key].isSelected = checked;
        for(var index in currentRecords[key].packageProductList) {
          selectedProductMap[currentRecords[key].packageProductList[index].id] = checked;
          currentRecords[key].packageProductList[index].isSelected = checked;
        }
      }
      else if(currentRecords[key].id != recordId && currentRecords[key].hasProducts) {
        var isPackageSelected = false;
        for(var index in currentRecords[key].packageProductList) {
          if(currentRecords[key].packageProductList[index].isSelected) {
            isPackageSelected = true;
            selectedProductMap[currentRecords[key].packageProductList[index].id] = true;
          } else {
            currentRecords[key].isSelected = isPackageSelected;
            selectedProductMap[currentRecords[key].packageProductList[index].id] = false;
            //break;
          }
        }
        /* if(currentRecords[key].id != 'undefined') {
           currentRecords[key].isSelected = isPackageSelected;
           selectedProductMap[currentRecords[key].id] = isPackageSelected;
         } */
      }
      if(currentRecords[key].id != 'undefined') {
        if(currentRecords[key].id == recordId && !currentRecords[key].hasProducts)
          selectedProductMap[recordId] = checked;
      }
    }
  },

  checkIfNeedToCheckAllCheckBoxes: function(selectedProductMap, currentRecords) {
    var checkAllBox = true;
    for(var key in currentRecords) {
      if(key === 'remove') {continue;}
      if(!selectedProductMap[currentRecords[key].id]) {
        checkAllBox = false;
      }
    }
    return checkAllBox;
  },
  fireCreateProductsEvent: function(component) {
    var createProducts = component.getEvent('createProducts');
    var selectedProductMap = component.get('v.selectedProductMap');
    var productCandidates = component.get('v.productCandidates');
    var selectedProducts = [];
    try {
      selectedProducts = this.convertSelectedProducts(selectedProductMap, productCandidates, component);
      createProducts.setParams({
        '_selected_products': selectedProducts

      });
      createProducts.fire();
    }
    catch(e) {

    }
  },
  convertSelectedProducts: function(selectedProductsMap, productCandidates, component) {
    var proposalLineItems = [];
    var proposal = component.get('v.proposal');
    var productCandidateList = [];
    for(var key = 0; key < productCandidates.length; key++) {
      var candidate = productCandidates[key];
      if(candidate.hasProducts) {
        for(var index = 0; index < candidate.packageProductList.length; index++) {
          if(selectedProductsMap[candidate.packageProductList[index].id]) {
            productCandidateList.push(candidate.packageProductList[index]);
          }
        }
      }
      else if(selectedProductsMap[candidate.id]) {
        productCandidateList.push(candidate);
      }
    }
    productCandidateList.forEach(function(candidate) {
      //var candidate = productCandidateList[key];
      try {
        var premiumRate = 0;
        var net_rate = 0;
        var advertiser_Rate_Discount = (candidate.listPrice + premiumRate) * (proposal.adsalescloud__Advertiser_Discount__c / 100 || 0);
        var product_rate_adjustment = (net_rate * (1 / (1 - (proposal.adsalescloud__Proposal_Discount__c / 100 || 0)))) - (((candidate.listPrice + premiumRate) - advertiser_Rate_Discount));
        var product_Adjustment = product_rate_adjustment / ((candidate.listPrice + premiumRate) * (1 - (proposal.adsalescloud__Advertiser_Discount__c / 100 || 0)));
        var proposal_Rate_Discount = (candidate.listPrice + premiumRate - advertiser_Rate_Discount) * (proposal.adsalescloud__Proposal_Discount__c / 100 || 0);
        net_rate = candidate.listPrice - advertiser_Rate_Discount - proposal_Rate_Discount;
        var gross_rate = (net_rate / (1 - (proposal.adsalescloud__Agency_Commission__c / 100 || 0)));
        var item = {
          'advertiser_Rate_Discount': advertiser_Rate_Discount,
          'proposal_Rate_Discount': proposal_Rate_Discount,
          'proposal_discount': (proposal.adsalescloud__Proposal_Discount__c / 100 || 0),
          'quantity': 0,
          'listPrice': candidate.rate_type.includes('CPM') ? candidate.listPrice * 1000 : candidate.listPrice,
          'start_date': null,
          'end_date': null,
          'productId': candidate.productId,
          'name': candidate.name,
          'premiumRate': premiumRate,
          'total_price': 0,
          'agency_commission': (proposal.adsalescloud__Agency_Commission__c / 100 || 0),
          'gross_rate': candidate.rate_type.includes('CPM') ? gross_rate * 1000 : gross_rate,
          'net_rate': candidate.rate_type.includes('CPM') ? net_rate * 1000 : net_rate,
          'rate_type': candidate.rate_type,
          'inventorySize': candidate.inventorySize,
          'inventoryTargeting': candidate.inventoryTargeting,
          'dayAndTimeDetails': candidate.dayAndTimeDetails,
          'frequencyCapsPerUserDetails': candidate.frequencyCapsPerUserDetails,
          'mobileApplicationTargeting': candidate.mobileApplicationTargeting,
          'connectionTargeting': candidate.connectionTargeting,
          'deviceTargeting': candidate.deviceTargeting,
          'geoTargeting': candidate.geoTargeting,
          'keyValueTargeting': candidate.keyValueTargeting,
          'adUnitsTargeting': candidate.adUnitsTargeting,
          'bandwidthGroupTargeting': candidate.bandwidthGroupTargeting,
          'browserLanguageTargeting': candidate.browserLanguageTargeting,
          'browserTargeting': candidate.browserTargeting,
          'deviceCapabilityTargeting': candidate.deviceCapabilityTargeting,
          'deviceCategoryTargeting': candidate.deviceCategoryTargeting,
          'placementsTargeting': candidate.placementsTargeting,
          'deviceManufacturerTargeting': candidate.deviceManufacturerTargeting,
          'mobileCarrierTargeting': candidate.mobileCarrierTargeting,
          'operatingSystemTargeting': candidate.operatingSystemTargeting,
          'userDomainTargeting': candidate.userDomainTargeting,
          'videoContentTargeting': candidate.videoContentTargeting,
          'videoPositionTargeting': candidate.videoPositionTargeting,
          'delivery_Impressions': candidate.delivery_Impressions,
          'display_Creatives': candidate.display_Creatives,
          'rotate_Creatives': candidate.rotate_Creatives,
          'mobileDeviceTargeting': candidate.mobileDeviceTargeting,
          'mobileDeviceSubmodelsTargetting': candidate.mobileDeviceSubmodelsTargetting,
          'billingCycle': proposal.adsalescloud__Billing_Cycle__c,
          'billingSchedule': proposal.adsalescloud__Billing_Schedule__c,
          'billingSource': proposal.adsalescloud__Billing_Source__c,
          'capsAndRollovers': proposal.adsalescloud__Caps_and_Rollovers__c,
          'thirdPartAdServer': proposal.adsalescloud__Third_Party_Ad_Server__c,
          'parentLabelsDetail': proposal.adsalescloud__Labels_Detail__c,
          'labels': proposal.adsalescloud__Labels__c,
          'timezone': proposal.adsalescloud__Time_Zone__c,
          'lineItemType': candidate.line_Item_Type,
          'lineItemPriority': candidate.lineItemPriority,
          'environmentType': candidate.environmentType,
          'isProgrammatic': proposal.adsalescloud__isProgrammatic__c,
          'creativeSource': (proposal.adsalescloud__isProgrammatic__c && (candidate.line_Item_Type == 'Standard' || candidate.line_Item_Type == 'Sponsorship')) ? 'Advertiser' : null,
          'goal': candidate.line_Item_Type === 'Sponsorship' || candidate.line_Item_Type === 'House' || candidate.line_Item_Type === 'Network' ? 100 : 0,
          'errors': {
            'quantity': {'error': '', 'msg': ''},
            'end_date': {'error': '', 'msg': ''},
            'start_date': {'error': '', 'msg': ''},
            'goal': {'error': '', 'msg': ''}
          }
        };
        if(candidate.isPackageProduct) {
          item.productRateId = candidate.productRateId;
          item.priceBookEntryId = candidate.priceBookEntryId;
        } else {
          item.priceBookEntryId = candidate.id;
        }
        if(proposal.adsalescloud__isProgrammatic__c) {
          if(candidate.environmentType === 'Browser')
            item.adExchangeEnvType = 'Display';
          else
            item.adExchangeEnvType = 'Video';
        } else {
          item.adExchangeEnvType = null;
        }
        proposalLineItems.push(item);
      }
      catch(e) {
        if(!candidate.rate_type) {
          component.set('v.message', 'Can not  add a product until Rate Type is not defined. Please check product: ' + candidate.name);
          component.set('v.messageType', 'error');
        }
        else {
          component.set('v.message', 'An error occured while creating Proposal Line Items. Please verify all selected Products are having adequate or valid data');
          component.set('v.messageType', 'error');
        }
        throw e;
      }
    });
    return proposalLineItems;
  },

  setAdExchangeEnvType: function(component, isProgrammatic, lineItemType, environmentType) {
    if(lineItemType == 'Preferred Deal' || lineItemType == 'Standard ') {
      if(environmentType != 'Browser')
        return 'Display';
      else
        return 'Video';
    }
    return null;
  },
  sortProducts: function(component) {
    var product = component.get('v.productCandidates');
    var order = component.get('v.sortOrder');
    var fieldName = component.get('v.orderBy');
    if(order && fieldName) {
      component.set('v.showSpinner', true);
      setTimeout(function() {
        /*var temp;
for(var i = 0; i < product.length - 1; i++) {
for(var j = i + 1; j < product.length; j++) {
if(order === 'ASC') {
if(product[i][fieldName] > product[j][fieldName] || (product[i][fieldName] == undefined && product[j][fieldName] != undefined)) {
temp = product[i];
product[i] = product[j];
product[j] = temp;
}
}
else {
if(product[i][fieldName] < product[j][fieldName] || (product[i][fieldName] != undefined && product[j][fieldName] == undefined)) {
temp = product[i];
product[i] = product[j];
product[j] = temp;
}
}
}
}*/
        if(order === 'ASC') {
          component.set('v.productCandidates', product.sort(function(a, b) {if(a[fieldName] > b[fieldName]) {return -1;} if(a[fieldName] < b[fieldName]) {return 1;} return 0;}));
        }
        else {
          component.set('v.productCandidates', product.sort(function(a, b) {if(a[fieldName] > b[fieldName]) {return 1;} if(a[fieldName] < b[fieldName]) {return -1;} return 0;}));
        }
        component.set('v.showSpinner', false);
      }, 5);
    }
  },
  handleAvailabilityDateChange: function(component) {
    var checkAvailabilityDateData = component.get("v.checkAvailabilityDateData");
    checkAvailabilityDateData.outputString = new Date(checkAvailabilityDateData.startDate).toLocaleDateString('en-US', {year: 'numeric', month: 'short', day: 'numeric'});
    checkAvailabilityDateData.outputString += " - " + new Date(checkAvailabilityDateData.endDate).toLocaleDateString('en-US', {year: 'numeric', month: 'short', day: 'numeric'});


    component.set("v.checkAvailabilityDateData", checkAvailabilityDateData);
  },
  fetchTimezoneOptions: function(component) {
    var action = component.get("c.getTimezoneOptions");
    action.setCallback(this, function(response) {
      if(response.getState() === "SUCCESS") {
        component.set("v.timezoneOptions", response.getReturnValue());
      }
    });
    $A.enqueueAction(action);
  },
});