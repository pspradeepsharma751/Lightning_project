({
  doInit: function(component, event, helper) {
    component.set('v.isLightning', window.location.host.indexOf('lightning') >= 0 ? true : false);
      helper.initializeUtilsHelper();
      helper.fetchTimezoneOptions(component);
      var startDate = new Date();
      startDate.setDate(startDate.getDate()+2); startDate.setHours(0); startDate.setMinutes(0); startDate.setSeconds(0);
      var checkAvailabilityDateData = {"startDate": helper.toPliTimezone(startDate, "America/New_York").toISOString()};
      startDate.setMonth(startDate.getMonth()+1); startDate.setHours(23); startDate.setMinutes(59); startDate.setSeconds(0);
      checkAvailabilityDateData.endDate = helper.toPliTimezone(startDate, "America/New_York").toISOString();          
      checkAvailabilityDateData.timezone = "America/New_York"; 
      component.set("v.checkAvailabilityDateData",checkAvailabilityDateData);
      helper.handleAvailabilityDateChange(component);
  },
  createProducts: function(component, event, helper) {
    var selectedItemNum = component.get('v.selectedItemNum');
    if(selectedItemNum > 0) {
      helper.fireCreateProductsEvent(component);
    }
  },
  checkAllCheckBoxes: function(component, event, helper) {
    var target = event.getSource();
    helper.checkAllCheckBoxes(component, event, target);
  },


  checkAllBoxesByEvent: function(component, event, helper) {
    var target = event.getParam('target');
    helper.checkAllCheckBoxes(component, event, target);
  },


  autoUpdateCheckBox: function(component, event, helper) {
    var selectedProductMap = component.get('v.selectedProductMap');
    if(!selectedProductMap) {
      selectedProductMap = {};
    }
    var currentRecords = component.get('v.productCandidatesInCurrentPage');
    component.set('v.checkedAll',
      helper.checkIfNeedToCheckAllCheckBoxes(selectedProductMap, currentRecords));
    component.set('v.isPackageProductVisible', false);
  },
  updateSelectedItems: function(component, event, helper) {
    var selectedProductMap = component.get('v.selectedProductMap');
    var count = 0;
    for(var key in selectedProductMap) {
      if(selectedProductMap[key] && key!='undefined') {
        count++;
      }
    }
    component.set('v.selectedItemNum', count);
  },
  clearSelectedItems: function(component, event, helper) {
    component.set('v.selectedProductMap', {});
    component.set('v.checkedAll', false);

  },
  toggleFilterBar: function(component, event, helper) {
    var showFilter = component.get('v.showFilterBar');
    showFilter = !showFilter;
    component.set('v.showFilterBar', showFilter);
  },
  updateFilterListStyle: function(component) {
    var showFilter = component.get('v.showFilterBar');
    if(showFilter) {
      $A.util.addClass(component.find('filterList'), 'slds-is-selected');
    } else {
      $A.util.removeClass(component.find('filterList'), 'slds-is-selected');
    }
  },
  closeQuickAction: function() {
    $A.get('e.force:closeQuickAction').fire();
  },

  showHideSection: function(component, event) {
    var divId = event.getSource().get('v.name');
    var htmlelement = document.getElementById(divId);
    htmlelement.style.display = 'block';
  },
  sortProducts: function(component, event, helper) {
    helper.sortProducts(component);
  },
    showAvailabilityDateInputModal: function(component, event, helper) {
        component.set("v.showAvailabilityDateInput", true);
    },
    cancelAvailabilityDate: function(component, event, helper) {
        component.set("v.showAvailabilityDateInput", false);
    },
    applyAvailabilityDate: function(component, event, helper) {
        helper.handleAvailabilityDateChange(component);
        component.set("v.showAvailabilityDateInput", false);
    },
    handleTimezoneChange : function(component, event, helper){
        { // refresh Datetime fields with new timezone
            component.set("v.refreshDatetimeFields", true);
            component.set("v.refreshDatetimeFields", false);  
        }
    },
});