({
    doInit : function(component) {  
        var self = this;
        if($A.util.isEmpty(component.get("v.record"))){
            window.setTimeout(function(){
                self.doInit(component);            
            },40);
        }
        else{
            component.set("v.showSpinner", false);
            var dfpStatus = component.get("v.record.adsalescloud__DFP_Order_Line_Item_Status__c");
            var proposalStatus = component.get("v.record.adsalescloud__Proposal__r.adsalescloud__Status__c");
            var dfpUnitsDelivered = component.get("v.record.adsalescloud__DFP_Units_Delivered__c");
            if(!(dfpUnitsDelivered >0  && (proposalStatus == 'Draft (sold)') && (dfpStatus == "Paused"  ||  dfpStatus == "Completed"))){
                component.set("v.hideUserPrompt", true);
            }
        }
    },
    doAction : function(component){
        var self = this;
        var action = component.get("c.actualize");
        action.setParams({
            "pliIDs" : [component.get("v.recordId")],
        });
        action.setCallback(this, function(response){
            component.set("v.showSpinner", false);
            //component.set("v.hideUserPrompt", true)
            if(response.getState() === "SUCCESS"){
                var toastEvent = $A.get('e.force:showToast');
                toastEvent.setParams({
                    'title': 'Success!',
                    'type': 'success',
                    'message': 'The proposal line item was actualized successfully. Please navigate to the Proposal and Sync to Ad Server to complete the order line item.'
                });
                toastEvent.fire();
                $A.get('e.force:refreshView').fire();
                $A.get('e.force:closeQuickAction').fire();
                
               // component.set("v.message", "The proposal line item was actualized successfully. Please navigate to the Proposal and Push to DFP to complete the order line item. ");
                //component.set("v.messageType", "success");
                component.set("v.doRefresh", true);
                //self.makeDfpCallouts(component);
            }else{
                component.set("v.showSpinner", false);
                component.set("v.hideUserPrompt", true);
                component.set("v.message", "An error occured while actualizing the Proposal line item.");
                component.set("v.messageType", "error");
            }
        });
        $A.enqueueAction(action);
    },
    makeDfpCallouts : function(component){
        var action = component.get("c.postActualizeCallouts");
        action.setParams({
            "objectId" : [component.get("v.recordId")],
        });
        action.setCallback(this, function(response){
            component.set("v.showSpinner", false);
            component.set("v.hideUserPrompt", true);
            if(response.getState() === "SUCCESS"){
                var toastEvent = $A.get('e.force:showToast');
                toastEvent.setParams({
                    'title': 'Success!',
                    'type': 'success',
                    'message': 'Proposal line item actualized succesfully.'
                });
                toastEvent.fire();
                $A.get('e.force:refreshView').fire();
                $A.get('e.force:closeQuickAction').fire();
                //component.set("v.message", "Proposal line item actualized succesfully.");
                //component.set("v.messageType", "success");
            }else{
                component.set("v.showToast",true);
                component.set("v.message", "An error occured while actualizing the Proposal line item.");
                component.set("v.messageType", "error");
            }
        });
        $A.enqueueAction(action);
    },
})