({
  showHideModal: function(component,event,helper) {
    var modalContainer = component.find("modalContainer");
    $A.util.toggleClass(modalContainer, "slds-hide");
    helper.createDynamicComponent(component);
  }
})