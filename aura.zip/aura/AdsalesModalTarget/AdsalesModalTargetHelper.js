({
	createDynamicComponent: function(component) {
    //component.set('v.showSpinner', true);
    $A.createComponent(
      'c:SelectedTargets',
      {
        'aura:id': 'newComponentId',
        'readOnly': true,
        'recordId': component.get('v.recordId')
      },
      function(newCmp, status, errorMessage) {
        if(status === 'SUCCESS') {
          var parent = component.find('modalBody');
          parent.set('v.body', newCmp);
          //component.set('v.showSpinner', false);
        }
        else if(status === 'INCOMPLETE') {
          console.log('No response from server or client is offline.');
        }
        else if(status === 'ERROR') {
          console.log('Error: ', errorMessage);
        }
      }
    );
  }
})