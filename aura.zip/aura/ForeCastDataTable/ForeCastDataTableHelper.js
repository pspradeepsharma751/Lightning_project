({
  doInit: function(component) {
    var totalNoOfRecords = component.get('v.totalNoOfRecords');
    var noOfRecordToDisplay = component.get('v.noOfRecordToDisplay');
    var totalNoOfPage = Math.ceil(totalNoOfRecords / noOfRecordToDisplay);
      component.set('v.totalNoOfPage', totalNoOfPage);
    // if no record found display message on screen.
    if(totalNoOfRecords === 0) {
      component.set('v.isRecordListEmpty', true);
    }
    var currentPageNo = 1;
  },
    
  
})