({
  doInit: function(component, event, helper) {
    var rowData = component.get('v.rowData');
    if(component.get('v.criteriaBreakdown')) {
      var data = [];
        Object.keys(rowData).forEach(function(key){
            data.push({'targetingDimension': key});
            rowData[key].forEach(function(item){
                item.targetingDimension = item.targetingCriteriaName;
                item.availableUnits = item.availableUnits;
                item.matchedUnits = item.matchedUnits;
                data.push(item);
            });
        });
      component.set('v.data', data);
      component.set('v.paginationList', data);
    }else{
        var data = [];
        for(var i = 0; i < rowData.length; i++) {
            data.push({'lineItemId':rowData[i].lineItemId ? rowData[i].lineItemLink :'#', 
                       'lineItemLink':rowData[i].lineItemId || '',
                       'pliId': rowData[i].pliId ? '/'+rowData[i].pliId : '#', 
                       'linkLabel': rowData[i].pliName ? rowData[i].pliName : 'Not created in Ad Sales Cloud',
                       'advertiserName':rowData[i].advertiserName || '',
                       'contendingImpressions':rowData[i].contendingImpressions || ''});
            
        }
        component.set('v.data',data);
        component.set('v.totalNoOfRecords', rowData.length);
        //helper.doInit(component);
    }
      
  },
})