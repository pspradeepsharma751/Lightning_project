({
  doInit: function(component, event, helper) {
    var recordId = component.get('v.recordId');
    if(recordId)
      component.set('v.newRecord', false);
    else
      component.set('v.newRecord', true);

    component.set('v.cval', '<style>.slds-modal__container{min-width: 60rem;}section .panel .closeIcon{display:none}</style>');
    helper.doInit(component);
    helper.createTimezoneSelectComponent(component);
  },
  onSave: function(component, event, helper) {
    var freqErrorMessage = component.get('v.frequencyCapErrorMessage');
    var errorMiscMessage = component.get('v.errorMessage');
    var objectData = component.get('v.record');
    if(!$A.util.isEmpty(freqErrorMessage)) {
      helper.onError(component, freqErrorMessage);
    }
    else if(!$A.util.isEmpty(errorMiscMessage)) {
      helper.onError(component, errorMiscMessage);
    }
    if(!objectData.Name || $A.util.isEmpty(objectData.Name.trim())) {
      helper.onError(component, 'Proposal Name cannot be blank.');
    }
      else if ($A.util.isEmpty(component.get('v.selectedRecord.Id'))){
          helper.onError(component, 'Opportunity cannot be blank.');
      }
      else if (!objectData.adsalescloud__Programmatic_Buyer_Details__c && objectData.adsalescloud__isProgrammatic__c){
          helper.onError(component, 'Buyer field must be set.');
      }
    else {
      helper.onSave(component, helper);
    }
  },
  onCancel: function(component, event, helper) {
    if(component.get('v.newRecord') || component.get('v.isOppProposalEdit')) {
      var homeEvent = $A.get('e.force:navigateToObjectHome');
      homeEvent.setParams({
        'scope': 'adsalescloud__Proposal__c'
      });
      homeEvent.fire();
    }
    else {
      $A.get('e.force:closeQuickAction').fire();
    }
  },
  budgetChangeHandler: function(component) {
    var record = component.get('v.record');
    record.adsalescloud__Remaining_Budget__c = record.adsalescloud__Budget__c - record.adsalescloud__Total_Net_Cost__c;
    component.set('v.record', record);
  },
  discountChangeHandler: function(component) {
    var record = component.get('v.record');
    record.adsalescloud__Total_Net_Cost__c = (record.adsalescloud__Total_Listing_Cost__c * (1 - record.adsalescloud__Advertiser_Discount__c / 100) + record.adsalescloud__Total_Product_Cost_Adjustment__c) * (1 - record.adsalescloud__Proposal_Discount__c / 100);
    record.adsalescloud__Total_Gross_Cost__c = record.adsalescloud__Total_Net_Cost__c / (1 - record.adsalescloud__Agency_Commission_Percentage__c / 100);
    record.adsalescloud__Agency_Commission__c = record.adsalescloud__Total_Gross_Cost__c * record.adsalescloud__Agency_Commission_Percentage__c / 100;
    record.adsalescloud__Remaining_Budget__c = record.adsalescloud__Budget__c - record.adsalescloud__Total_Net_Cost__c;
    record.adsalescloud__Value_added_tax__c = record.adsalescloud__VAT_Percentage__c / 100 * record.adsalescloud__Total_Net_Cost__c;
    record.adsalescloud__Total_Net_Cost_with_VAT__c = record.adsalescloud__Total_Net_Cost__c + record.adsalescloud__Value_added_tax__c;
    component.set('v.record', record);
  },
  agencyCommPerChangeHandler: function(component) {
    var record = component.get('v.record');
    record.adsalescloud__Total_Gross_Cost__c = record.adsalescloud__Total_Net_Cost__c / (1 - record.adsalescloud__Agency_Commission_Percentage__c / 100);
    record.adsalescloud__Agency_Commission__c = record.adsalescloud__Total_Gross_Cost__c * record.adsalescloud__Agency_Commission_Percentage__c / 100;
    component.set('v.record', record);
  },
  vatChangeHandler: function(component) {
    var record = component.get('v.record');
    record.adsalescloud__Value_added_tax__c = record.adsalescloud__VAT_Percentage__c / 100 * record.adsalescloud__Total_Net_Cost__c;
    record.adsalescloud__Total_Net_Cost_with_VAT__c = record.adsalescloud__Total_Net_Cost__c + record.adsalescloud__Value_added_tax__c;
    component.set('v.record', record);
  },
  getSelectedOppRecord: function(component, event, helper) {
    helper.getSelectedOppRecord(component);
  },
  navigateToRecord: function(component, event, helper) {
    window.open(component.get('v.record.adsalescloud__Ad_Server_Order__c').split('"')[1]);
  },
  onStatusChange: function(component, event, helper) {
    var proposalStatus = event.getSource().get('v.value');
    if(proposalStatus === 'Finalized' || proposalStatus == 'Rejected (sold)' || proposalStatus == 'Draft (sold)' || proposalStatus == 'Pending Approval (sold)')
      component.set('v.record.adsalescloud__Sold__c', true);
    else
      component.set('v.record.adsalescloud__Sold__c', false);
  },
  setProgammaticType: function(component, event, helper) {
      if(component.get('v.record.adsalescloud__isProgrammatic__c'))
          component.set('v.record.adsalescloud__Programmatic_Type__c', 'Guaranteed');
      else
          component.set('v.record.adsalescloud__Programmatic_Type__c', null);
  }, 
    
   loadBuyerData: function(component, event, helper) {
          component.set('v.showBuyerSpinner', true);
     
  },   

});