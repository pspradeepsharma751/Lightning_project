({
  doInit: function(component) {
    var actionToFetchPackageFields = component.get('c.getProposalRecordWrp');
    actionToFetchPackageFields.setParams({
      'recordId': component.get('v.recordId') ? component.get('v.recordId') : null,
      'oppRecId': component.get('v.oppRecId') ? component.get('v.oppRecId') : null
    });
    actionToFetchPackageFields.setCallback(this,
      function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
            var response = JSON.parse(response.getReturnValue());
            var record = JSON.parse(response.proposalRecord);
            if(record['adsalescloud__Status__c'] =='Draft' && 
               	(record['adsalescloud__Count_of_Proposal_Line_Items__c']== 0 ||
                  record['adsalescloud__Count_of_Proposal_Line_Items__c']== undefined))
               {
               		component.set('v.isProgrammaticEditable', false);
        		}  
            if(component.get('v.cloneRecordWithPLI') || component.get('v.cloneRecordWithoutPLI')) {
                record.Name = 'Copy of ' + record.Name;
                record.adsalescloud__Ad_Server_Id__c = null;
                record.adsalescloud__Ad_Server_Order__c = 'Not Synced';
                record.adsalescloud__Status__c = 'DRAFT';
            }
            if(component.get('v.cloneRecordWithoutPLI')){
                record.adsalescloud__End_Date__c = null;
                record.adsalescloud__Start_Date__c = null;
            }
            component.set('v.selectedOppRecord', record.adsalescloud__Opportunity__r);
            component.set('v.record', record);
            if(!component.get('v.newRecord')) {
                try {
                    var startDateTime = component.get('v.record.adsalescloud__Start_Date__c');
                    if(startDateTime) {
                        var startFormattedDate = $A.localizationService.formatDate(startDateTime, 'yyyy-MM-ddTHH:mm:ss');
                        component.set('v.startdate', startFormattedDate);
                    }
                    
                    var endDateTime = component.get('v.record.adsalescloud__End_Date__c');
                    if(endDateTime) {
                        var endDateFormattedDate = $A.localizationService.formatDate(endDateTime, 'yyyy-MM-ddTHH:mm:ss');
                        component.set('v.enddate', endDateFormattedDate);
                    }
                    
                }
                catch(e) {
                    component.set('v.message', e.message);
                    component.set('v.messageType', 'error');
                    console.log(e);
                }
            }
            else {
                record.adsalescloud__Pricing_Model__c = 'Net';
            }
            component.set('v.record', record);
            this.getObjKeyPrefix(component);
           // this.getCustomSettingValue(component);
            var ele = component.find('mainContainer');
            console.log(ele);
            var resp = JSON.parse(response.cusOppAccSettings);
            var isEnableProgrammaticProposal = false;
            if(resp.adsalescloud__Enable_Programmatic_Proposals__c){
                isEnableProgrammaticProposal = true;
            } 
            component.set('v.isEnableProgrammaticProposal', isEnableProgrammaticProposal ); 
        }else if(state === 'ERROR') {
            var errorMessage = response.getError()[0].message;
        }
      }
    );
    $A.enqueueAction(actionToFetchPackageFields);
  },
  createTimezoneSelectComponent: function(component) {

    var action = component.get('c.fetchPicklistValues');
    action.setParams({
      'pickListFieldName': component.get('v.timeZoneAPIName')
    });
    action.setCallback(this,
      function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
          // create a empty array var for store dependent picklist values for controller field)
          var dependentFields = [];
            /*dependentFields.push({
                    class: 'optionClass',
                    label: '--- None ---',
                    value: '--- None ---'
                    });*/
          var listPicklistValues = response.getReturnValue();
          for(var i = 0; i < listPicklistValues.length; i++) {
            dependentFields.push({
              class: 'optionClass',
              label: listPicklistValues[i].label,
              value: listPicklistValues[i].value,
              selected: component.get('v.record').adsalescloud__Time_Zone__c !== undefined && listPicklistValues[i] == component.get('v.record').adsalescloud__Time_Zone__c
            });
          }
          component.set('v.options', dependentFields);
          if(component.get('v.newRecord'))
            component.set('v.record.adsalescloud__Time_Zone__c', 'America/New_York');
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
          component.set('v.errorMessage', errorMessage);
        }
      }
    );
    $A.enqueueAction(action);
  },
  onSave: function(component) {
    //this.updateRecordWithPLIRevenueEntry(component);
    var rawDate = component.get('v.startdate');
    var rawDate1 = component.get('v.enddate');
    var objectData = component.get('v.record');
    var recordId = component.get('v.recordId');
    var action = component.get('c.upsertRecord');
    var errorMessage = '';
    if(component.get('v.cloneRecordWithPLI') || component.get('v.cloneRecordWithoutPLI')) {
      objectData.adsalescloud__attributes = {type: 'adsalescloud__Proposal__c'};
      delete objectData.Id;
      delete objectData.adsalescloud__Ad_Server_Id__c;
      delete objectData.adsalescloud__Ad_Server_Order__c;
      //delete objectData.adsalescloud__End_Date_Time__c;
      //delete objectData.adsalescloud__Start_Date_Time__c;  
    }
      if(!objectData['adsalescloud__isProgrammatic__c']){
          objectData['adsalescloud__Programmatic_Type__c'] = null;
          objectData['adsalescloud__Programmatic_Buyer__c'] = null;
          objectData['adsalescloud__Programmatic_Buyer_Details__c'] = null;
      }
        
      
     if(objectData['adsalescloud__isProgrammatic__c'] && objectData['adsalescloud__Programmatic_Type__c'] == undefined)
        objectData['adsalescloud__Programmatic_Type__c'] = 'Guaranteed'; 
      
    if(objectData.adsalescloud__Billing_Source__c === '---None--') {
      objectData['adsalescloud__Caps_and_Rollovers__c'] = null;
      objectData['adsalescloud__Billing_Schedule__c'] = null;
    }
    else if(objectData.adsalescloud__Billing_Source__c === 'Contracted' || objectData.adsalescloud__Billing_Source__c === 'Contracted Flat fee') {
      objectData['adsalescloud__Caps_and_Rollovers__c'] = null;
    }
    else {
      objectData['adsalescloud__Billing_Schedule__c'] = null;
    }
    component.set('v.isButtonDisabled', true);
    action.setParams({
      'sObjectRecord': JSON.stringify(objectData),
      'cloneRecordWithPLI': component.get('v.cloneRecordWithPLI'),
      'recordId': recordId ? recordId : null
    });

    action.setCallback(this, function(response) {
      var state = response.getState();
      if(state === 'SUCCESS') {
        var res = response.getReturnValue();
        if(res.status === 'OK') {
          var recordId = component.get('v.recordId');
          
          if(component.get('v.isLightning') && !component.get('v.cloneRecord')) {
                  $A.get('e.force:refreshView').fire();
                  $A.get('e.force:closeQuickAction').fire();
              } else if(component.get('v.isOppProposalEdit')) {
                  document.location.href = '/' + component.get('v.recordId');
              }
                  else {
                      document.location.href = '/' + res.id;
                  }
        }
        else
          this.showToast(component, 'Error', res.msg, 'error');
          component.set('v.isButtonDisabled', false);
      }
      else {
        
        if(state === 'INCOMPLETE') {
          errorMessage = 'Server could not be reached. Check your internet connection.';
        } else if(state === 'ERROR') {
          var errors = response.getError();
          if(errors) {
            for(var i = 0; i < errors.length; i++) {
              for(var j = 0; errors[i].pageErrors && j < errors[i].pageErrors.length; j++) {
                errorMessage += (errorMessage.length > 0 ? '\n' : '') + errors[i].pageErrors[j].message;
              }
              if(errors[i].fieldErrors) {
                for(var fieldError in errors[i].fieldErrors) {
                  var thisFieldError = errors[i].fieldErrors[fieldError];
                  for(var j = 0; j < thisFieldError.length; j++) {
                    errorMessage += (errorMessage.length > 0 ? '\n' : '') + thisFieldError[j].message;
                  }
                }
              }
              if(errors[i].errorMessage) {
                errorMessage += (errorMessage.length > 0 ? '\n' : '') + errors[i].message;
              }
            }
          } else {
            errorMessage += (errorMessage.length > 0 ? '\n' : '') + 'Unknown error';
          }
        }
        this.showToast(component, 'Error', errorMessage, 'error');
       component.set('v.isButtonDisabled', false);
      }
    });
    $A.enqueueAction(action);
  },
  onError: function(component, errorMessage) {
    this.showToast(component, 'Error', errorMessage, 'error');
  },
  showToast: function(component, title, message, type) {
    component.set('v.toastTitle', title);
    component.set('v.message', message);
    component.set('v.messageType', type);
    component.set('v.showToast', true);
  },
  getObjKeyPrefix: function(component) {
    var actionTogetObjKeyPrefix = component.get('c.getObjKeyPrefix');
    actionTogetObjKeyPrefix.setCallback(this,
      function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
          component.set('v.objKeyPrefix', response.getReturnValue());
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
        }
      }
    );
    $A.enqueueAction(actionTogetObjKeyPrefix);
  },
  getSelectedOppRecord: function(component) {
    var oppRecordId = component.get('v.selectedRecord.Id');
    if(oppRecordId) {
      var getLookUpFieldRecords = component.get('c.getLookUpFieldRecords');
      getLookUpFieldRecords.setParams({
        'lookupRecordId': oppRecordId
      });
      getLookUpFieldRecords.setCallback(this, function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
          var rsp = JSON.parse(response.getReturnValue());
          component.set('v.selectedOppRecord', rsp.oppRecordValue);
          component.set('v.selectedAccount', rsp.accName);
          component.set('v.hasIsSoldProposal', rsp.hasIsSoldProposal);
            if(rsp.hasIsSoldProposal && (component.get('v.newRecord') || component.get('v.cloneRecord'))){
                component.set('v.record.adsalescloud__Primary_Proposal__c', false);
            } 
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
        }
      });
      $A.enqueueAction(getLookUpFieldRecords);
    }
      else{
            component.set('v.hasIsSoldProposal', false);
      }
  },
	getCustomSettingValue: function(component) {
    var actionToGetCustomSettingValues = component.get('c.getCustomSettingValues');
    actionToGetCustomSettingValues.setCallback(this,
      function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
            var resp = JSON.parse(response.getReturnValue());
            var isEnableProgrammaticProposal = false;
            if(resp.adsalescloud__Enable_Programmatic_Proposals__c){
                isEnableProgrammaticProposal = true;
            } 
            component.set('v.isEnableProgrammaticProposal', isEnableProgrammaticProposal ); 
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
        }
      }
    );
    $A.enqueueAction(actionToGetCustomSettingValues);
  },



});