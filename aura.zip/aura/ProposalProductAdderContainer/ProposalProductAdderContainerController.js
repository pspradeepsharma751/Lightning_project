({
  doInit: function(component, event, helper) {
    helper.doInit(component);
  },
  validate: function(component, event, helper) {
    helper.validate(component);
  },
  close: function(component, event, helper) {
    $A.get('e.force:closeQuickAction').fire();
  },
  redirectToOpptunity: function(component, event, helper) {
    if(component.get('v.isClassic')) {
      window.location.href = '/' + component.get('v.record.adsalescloud__Opportunity__r.Id');
    }
    else {
      var urlEvent = $A.get('e.force:navigateToURL');
      urlEvent.setParams({
        'url': '/' + component.get('v.record.adsalescloud__Opportunity__r.Id')
      });
      urlEvent.fire();
    }
  },
  changeCSS: function(component, event, helper) {
    helper.changeCSS(component);
  }
});