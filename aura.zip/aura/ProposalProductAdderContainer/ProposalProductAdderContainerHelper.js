({
  doInit:function(component){
    component.set('v.showSpinner',true);
    this.fetchData(component, 'getRecord', {
      recordId: component.get('v.recordId')
    }, function(response){
      if(response.status === 'OK'){
        component.set('v.record',response.proposal);
        component.set('v.otherRecordId',response.otherRecordId?response.otherRecordId:'');
        component.set('v.showSpinner',false);
      }else{
        component.set('v.validationError',response.msg);
        component.set('v.showSpinner',false);
      }
    },function(error){
      component.set('v.validationError',error);
      component.set('v.showSpinner',false);
    });
  },
  validate: function(component) {
    var proposal = component.get('v.record');
    if(proposal.adsalescloud__Status__c !== 'Draft' && proposal.adsalescloud__Status__c !== 'Draft (sold)') {
      component.set('v.validationError', 'Add Products is not allowed unless the Proposal Status is Draft. Please retract the proposal to continue.');
    }
    else if($A.util.isEmpty(proposal.adsalescloud__Opportunity__r)) {
      component.set('v.validationError', 'Add Products requires the Proposal’s Opportunity is configured. Please set the Opportunity and try again.');
    }
    else if($A.util.isEmpty(proposal.adsalescloud__Opportunity__r.Pricebook2Id)) {
      component.set('v.validationError', 'Add Products requires the Proposal’s Opportunity is first configured with a Price Book. Click OK to navigate to the Opportunity and set its Price Book or click Cancel to return back.');
      component.set('v.showButtonOnError', true);
    }
    else {
      component.set('v.validationError', '');
    }
    this.setStyle(component);
  },
  setStyle: function(component) {
    var style = '';
    if($A.util.isEmpty(component.get('v.validationError'))) {
      style = '.slds-modal__container { margin: 0 auto;width: 70% !important; max-width: 80% !important; min-width: 40rem; height: 92%; } .slds-modal__content{ padding: 0 !important; border-radius: .4em; overflow: auto; } .slds-modal__close { width: 2rem; height: 2rem; top: -1.8rem!important; right: -.5rem;}';
      if(!component.get('v.isClassic')) {
        style = style + ' body{ font-size: .8125rem !important;  font-family: \'Salesforce Sans\',Arial,sans-serif !important; color: #222 !important; } .slds-modal__container { padding-top: 90px !important; }  .slds-modal__header {  left: 0; } .slds-modal__close { top: -5.5rem !important; } .primaryFieldRow{ height: 45px; } .slds-modal__header--empty { padding: 0 !important; } .container{  padding : 0 !important; } .slds-modal__header{ /*height : 57px !important;*/ } h2{  font-size: 1em !important; margin-bottom : 0 !important; } p{ margin: 0 !important; padding: 0 !important; } .cuf-content{padding: 0 !important;}';
      }
    }
    else {
      style = '.slds-modal__content { height: 200px !important; } ';
    }
    style = '<style>' + style + '</style>';
    component.set('v.style', style);
  },
  changeCSS: function(component) {
    if(component.get('v.headerTitle') === 'Add Products') {
      component.set('v.style2', '');
    }
    else {
      component.set('v.style2', '<style>.slds-tabs_default__nav{ display: none !important}</style>');
    }
  }

});