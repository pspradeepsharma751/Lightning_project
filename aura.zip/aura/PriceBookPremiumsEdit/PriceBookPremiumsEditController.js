({
  doInit: function(component, event, helper) {
      component.set("v.pricebookId", JSON.parse(JSON.stringify(component.get("v.recordId")))+" ");
    helper.doInit(component);
      component.set("v.isLightning", document.location.host.indexOf("lightning") > -1 );  // need to check, beacuse this component will always be open in vf page. 
      component.set("v.actionFetchValues", component.get("c.fetchValues"));
  },
    handleRecordIdChange: function(component, event, helper) {
        if($A.util.isEmpty(component.get('v.recordId'))){
            component.set('v.recordId', component.get('v.pricebookId').trim()); 
        }
    },
    fetchValues: function(component, event, helper) {
        //helper.onSave(component);
    },
  onSave: function(component, event, helper) {
    helper.onSave(component);
  },
  onCancel: function(component, event, helper) {
      helper.navigateToReturnPage(component);
  },
  addPremium: function(component, event, helper) {
    var id = event.currentTarget.dataset.id;
    helper.addPremium(component, id === 'null' ? null : id, event.currentTarget.dataset.value);
  },
  addValue: function(component, event, helper) {
    helper.addValue(component, event.currentTarget.dataset.premiumIndex);
  },
  showButtonMenu: function(component, event, helper) {
    helper.showButtonMenu(component);
  },
  hideButtonMenu: function(component, event, helper) {
    helper.hideButtonMenu(component, helper);
  },
  deletePremium: function(component, event, helper) {
    helper.deletePremium(component, event.currentTarget.dataset.premiumIndex);
  },
  deleteValue: function(component, event, helper) {
    var dataset = event.currentTarget.dataset;
    helper.deleteValue(component, dataset.premiumIndex, dataset.valueIndex);
  },
    refreshErrors : function(component, event, helper){
        component.find('currencyField').forEach(function(field){
          if(!field.get("v.required")){
              field.set("v.errors", null);
          }
      });
    }
})