({
    doInit: function(component) {
        component.set('v.status', 'Loading...');
        var action2 = component.get('c.getPricebook');
        action2.setParams({
            'recordId': component.get('v.recordId')
        });
        action2.setCallback(this, function(response) {
            if(response.getState() === 'SUCCESS') {
                var result = JSON.parse(response.getReturnValue());
                if(result.status === "OK"){
                    if(!$A.util.isEmpty(Object.keys(result.keyValueMap))){
                        this.fetchValuesForExistingKeys(component, Object.keys(result.keyValueMap), 1);
                    }
                    component.set("v.keyPaginationInfo", result.keyPaginationInfo);
                    if(result.keyPaginationInfo.currentPage < result.keyPaginationInfo.totalPages){
                        this.fetchKeys(component);
                    }
                    this.setPicklists(component, result.picklistMap);
                    result.premiumList.forEach(function(value, index) {
                        try {
                            value.premiumFeatureId = component.get('v.premiumFeatureMap').get(value.adsalescloud__Premium_Feature__c).Id;
                            //value.valueList = result.keyValueMap[value.premiumFeatureId].values;
                            if($A.util.isEmpty(value.valueList)) {
                                value.valueList = [{'value': 'Any Value', 'label': 'Any Value'}];
                            }
                        }
                        catch(e) {
                            
                        }
                        if($A.util.isEmpty(value.adsalescloud__Premium_Rate_Values__r)) {
                            value.adsalescloud__Premium_Rate_Values__r = {};
                            value.adsalescloud__Premium_Rate_Values__r.records = [];
                            value.adsalescloud__Premium_Rate_Values__r.totalSize = 1;
                            value.adsalescloud__Premium_Rate_Values__r.done = true;
                        } else {
                            for(var i = 0; i < value.adsalescloud__Premium_Rate_Values__r.records.length; i++) {
                                if(value.adsalescloud__Premium_Rate_Values__r.records[i].adsalescloud__Rate_Type__c.includes('CPM'))
                                    value.adsalescloud__Premium_Rate_Values__r.records[i].adsalescloud__Amount__c *= 1000;
                            }
                        }
                    });
                    component.set('v.premiumList', result.premiumList);
                    component.set('v.deletedPremiumList', result.deletedPremiumList);
                    component.set('v.deletedValueList', result.deletedValueList);
                    component.set('v.keyValueMap', {});
                    if($A.util.isEmpty(result.premiumList)) {
                        component.set('v.status', 'Click the Add Premium button to configure Premiums for this Price Book');
                    }
                    else {
                        component.set('v.status', '');
                    }
                    this.filterPremiumList(component, this);
                    
                }
                else{
                    var saveButtons = component.find("saveButton").forEach(function(button){button.set("v.disabled", true);});
                    this.handleServerError(component, result.status);
                }
            }
            else {
                component.set('v.error', 'Error occured! Please refresh page.');
                component.set('v.status', 'couldn\'t load data.');
            }
            component.set('v.showSpinner', false);
        });
        $A.enqueueAction(action2);
    },
    fetchKeys: function(component) {
        var action = component.get("c.getDfpKeys");
        var keyPaginationInfo = component.get("v.keyPaginationInfo");
        action.setParams({"offset" : keyPaginationInfo.currentPage * keyPaginationInfo.pageSize});
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                var result = JSON.parse(response.getReturnValue());
                if(result.status === "OK"){
                    component.set("v.keyPaginationInfo", result.keyPaginationInfo);
                    if(result.keyPaginationInfo.currentPage < result.keyPaginationInfo.totalPages){
                        this.fetchKeyValue(component);
                    }
                    
                    //    to do     
                    var premiumFeatureList = component.get('v.premiumFeatureList');
                    premiumFeatureList = premiumFeatureList.concat(result.picklistMap['premiumFeatureList']);
                    premiumFeatureList = this.sortPremiumFeatureList(premiumFeatureList);
                    component.set('v.premiumFeatureList', premiumFeatureList );
                    var premiumFeatureMap = component.get('v.premiumFeatureMap');
                    premiumFeatureList.forEach(function(value, index) {
                        premiumFeatureMap.set(value.value, value);
                    });
                    component.set('v.premiumFeatureMap', premiumFeatureMap);
                    
                }
                else {
                    this.handleServerError(component, result.status);
                }
            }
            else{
                
            }
        });
        $A.enqueueAction(action);
    },
    
    /*
     *this method fetch values for keys used in existing premiums.
    */
    fetchValuesForExistingKeys: function(component, keyIDs, loadPage) {
        var action = component.get("c.getKeyValues");
        action.setParams({keyIds: keyIDs, loadPage : loadPage});
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                var result = response.getReturnValue();
                var pageInfo;
                Object.keys(result).forEach(function(key){
                    if(result[key].paginationInfo.totalKeysSize>0){
                        pageInfo = result[key].paginationInfo;
                    }
                });
                var keyValueMap = this.concatKeyValueMap(component.get('v.keyValueMap'), response.getReturnValue());
                component.set("v.keyValueMap", keyValueMap)
                if(pageInfo.currentPage < pageInfo.totalPages){
                    this.fetchValuesForExistingKeys(component, keyIDs, pageInfo.currentPage + 1);
                }
                this.refreshValuesOnPremiums(component);                
            }
            else{
                
            }
        });
        $A.enqueueAction(action);
    },
    fetchValues : function(component, premiumFeatureId, premium, premiumIndex, loadPage){
        var action = component.get("c.getKeyValues");
        action.setParams({keyIds: [premiumFeatureId], loadPage : loadPage});
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                var keyValueMap = component.get('v.keyValueMap');  
                var premiumList = component.get("v.premiumList");
                if($A.util.isEmpty(premiumList[premiumIndex])){
                    premiumList.push(premium);
                }
                if($A.util.isEmpty(keyValueMap[premiumFeatureId])){
                    keyValueMap[premiumFeatureId] = response.getReturnValue()[premiumFeatureId];
                }
                else{
                    keyValueMap[premiumFeatureId].values = response.getReturnValue()[premiumFeatureId].values.concat(keyValueMap[premiumFeatureId].values);
                    keyValueMap[premiumFeatureId].paginationInfo = response.getReturnValue()[premiumFeatureId].paginationInfo;
                }
                premiumList[premiumIndex].valueList = keyValueMap[premiumFeatureId].values.sort();
                
                //premiumList.push(premium);
                component.set('v.premiumList', premiumList);
                if(keyValueMap[premiumFeatureId].paginationInfo.currentPage < keyValueMap[premiumFeatureId].paginationInfo.totalPages){
                    this.fetchValues(component, premiumFeatureId, premium, premiumIndex, keyValueMap[premiumFeatureId].paginationInfo.currentPage + 1);
                }
            }
            else{
                
            }
            component.set('v.showSpinner', false);
        });
        $A.enqueueAction(action);
    },
    handleServerError : function(component, error){
        if(error === "AUTH_FAILED"){
            if(confirm("User Authorization failed. Please navigate to Ad Sales User Setup and Authorize user.")){
                window.location.href ="/apex/AdSalesUserSetup";
            }else{
                component.set('v.error', 'User Authorization failed. Please navigate to <a href ="/apex/AdSalesUserSetup">Ad Sales User Setup</a> and Authorize user.');
                component.set('v.status', 'couldn\'t load data.');
            }
        }
        else if(error === "NO_NETWORKS_TO_ACCESS"){
            if(confirm("User Authentication Error: NO_NETWORKS_TO_ACCESS. Please check if network code is accessible and navigate to Ad Sales User Setup and Authorize user again with a registered username.")){
                window.location.href ="/apex/AdSalesUserSetup";
            }else{
                component.set('v.error', 'User Authentication Error: NO_NETWORKS_TO_ACCESS. Please check if network code is accessible <br/>and navigate to <a href ="/apex/AdSalesUserSetup">Ad Sales User Setup</a> and try to Authorize user again with a registered username.');
                component.set('v.status', 'couldn\'t load data.');
            }
        }
            else{
                component.set('v.error', 'Something went wrong.');
                component.set('v.status', 'couldn\'t load data.');
                console.log(error);
            }
    },
    setPicklists: function(component, result) {
        var lists = ['premiumFeatureList', 'pricingMethodList', 'rateTypeList', 'paymentModelList'];
        result['premiumFeatureList'] = this.sortPremiumFeatureList(result['premiumFeatureList']);
        for(var i = 0; i < Object.keys(result).length; i++) {
            component.set('v.' + lists[i], result[lists[i]]);
        }
        var premiumFeatureMap = new Map();
        result['premiumFeatureList'].forEach(function(value, index) {
            premiumFeatureMap.set(value.value, value);
        });
        component.set('v.premiumFeatureMap', premiumFeatureMap);
    },
    sortPremiumFeatureList: function(premiumFeatureList) {
        var strLabels = [];
        premiumFeatureList.forEach(function(value, index) {
            strLabels.push(value.value);
        });
        strLabels.sort();
        var mapPremiums = new Map();
        premiumFeatureList.forEach(function(value, index) {
            mapPremiums.set(value.value, value);
        });
        premiumFeatureList = [];
        strLabels.forEach(function(value, index) {
            premiumFeatureList.push(mapPremiums.get(value));
        });
        return premiumFeatureList;
    },
    filterPremiumList: function(component, helper) {
        var premiumList = component.get('v.premiumList');
        var premiumFeatureList = component.get('v.premiumFeatureList');
        if(!$A.util.isEmpty(premiumList) && !$A.util.isEmpty(premiumFeatureList)) {
            premiumList.forEach(function(value, index) {
                helper.refreshPremiumList(component, value.adsalescloud__Premium_Feature__c);
            });
        }
    },
    refreshPremiumList: function(component, featureValue) {
        var premiumFeatureList = component.get('v.premiumFeatureList');
        var featureValues = [];
        premiumFeatureList.forEach(function(value, index) {
            featureValues.push(value.value);
        });
        var featureIndex = featureValues.indexOf(featureValue);
        if(featureIndex >= 0) {
            premiumFeatureList.splice(featureIndex, 1);
        }
        component.set('v.premiumFeatureList', premiumFeatureList)
    },
    onSave: function(component) {
        if($A.util.isEmpty(component.get('v.premiumList'))  && $A.util.isEmpty(component.get('v.deletedPremiumList'))  &&  $A.util.isEmpty(component.get('v.deletedValueList'))){
            component.set('v.error', 'Nothing to save. Please add at least 1 Premium');
            this.hideError(component);
            return;
        }      
        if(this.validate(component)) {
            component.set('v.showSpinner', true);
            var pricebook = {};
            pricebook.premiumList = component.get('v.premiumList');
            pricebook.deletedPremiumList = component.get('v.deletedPremiumList');
            pricebook.deletedValueList = component.get('v.deletedValueList');
            pricebook.premiumList.forEach(function(premium, index) {
                delete premium.premiumFeatureId;
                delete premium.valueList;
                premium.adsalescloud__Premium_Rate_Values__r.records.forEach(function(value, index) {
                    if(value.adsalescloud__Payment_model__c === 'Amount') {
                        value.adsalescloud__Percent__c = null;
                        if(value.adsalescloud__Rate_Type__c.includes('CPM')){
                            value.adsalescloud__Amount__c /= 1000;
                        }
                    }
                    else {
                        value.adsalescloud__Amount__c = null;
                    }
                });
            });
            var action = component.get('c.savePricebook');
            action.setParams({
                'pricebook': JSON.stringify(pricebook)
            });
            action.setCallback(this, function(response) {
                if(response.getState() === 'SUCCESS') {
                    this.navigateToReturnPage(component);
                }
                else {
                    component.set('v.error', 'Something went wrong!');
                    this.hideError(component);
                }
                component.set('v.showSpinner', false);
            });
            $A.enqueueAction(action);
        }
    },
    validate: function(component) {
        component.set('v.error', '');
        var formFields = component.find('formField');
        formFields = Array.isArray(formFields)? formFields : [formFields];
        var validFieldValues = formFields.reduce(function(validSoFar, inputCmp) {  // validation for lightning components
            // Displays error messages for invalid fields
            try {
                if(inputCmp.get("v.value")  && inputCmp.get("v.value") < 0){
                    inputCmp.set("v.messageWhenTooShort", "Must be greater than or equal to 0.");
                }
                inputCmp.showHelpMessageIfInvalid();
            }
            catch(e) {}
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        component.find('currencyField').forEach(function(field){
            if(field.get("v.required") && !field.get("v.value")){
                validFieldValues = false;
                field.set("v.errors", [{message:"Complete this field."}]);
            }
            else if(field.get("v.required")  &&  field.get("v.value")  && field.get("v.value") <0){
                validFieldValues = false;
                field.set("v.errors", [{message:"Must be greater than or equal to 0."}]);
            }
        });
        /*component.find('formField').forEach(function(field){
          if(field.get("v.required") && !field.get("v.value")){
              validFieldValues = false;
              field.set("v.errors", [{message:"Complete this field."}]);
          }
          else if(field.get("v.required")  &&  field.get("v.value")  && field.get("v.value") <0){
              validFieldValues = false;
              field.set("v.errors", [{message:"Must be greater than or equal to 0."}]);
          }
      });*/
        var uniqueValues = true;
        if(validFieldValues) {
            var self = this;
            var premiumList = component.get('v.premiumList');
            premiumList.forEach(function(premium, premiumIndex) {
                for(var index = 0; index < premium.adsalescloud__Premium_Rate_Values__r.records.length - 1; index++) {
                    var value1 = premium.adsalescloud__Premium_Rate_Values__r.records[index];
                    var obj1 = {};
                    obj1.value = value1.adsalescloud__Value__c;
                    obj1.rateType = value1.adsalescloud__Rate_Type__c;
                    for(var valueIndex = index + 1; valueIndex < premium.adsalescloud__Premium_Rate_Values__r.records.length; valueIndex++) {
                        var obj2 = {};
                        var value2 = premium.adsalescloud__Premium_Rate_Values__r.records[valueIndex];
                        obj2.value = value2.adsalescloud__Value__c;
                        obj2.rateType = value2.adsalescloud__Rate_Type__c;
                        if(Object.is(JSON.stringify(obj1), JSON.stringify(obj2))) {
                            uniqueValues = false;
                            component.set('v.error', 'Error: Duplicate entities configured for Premium Feature: ' + premium.adsalescloud__Premium_Feature__c);
                            self.hideError(component);
                            return;
                        }
                    }
                }
            });
        }
        else {
            component.set('v.error', 'Invalid Data. Please review all fields');
            this.hideError(component);
        }
        return validFieldValues && uniqueValues;    
        
    }, 
    addPremium: function(component, premiumFeatureId, premiumFeatureValue) {
        var premiumList = component.get('v.premiumList');
        var premium = {};
        premium.adsalescloud__Premium_Feature__c = premiumFeatureValue;
        premium.premiumFeatureId = premiumFeatureId;
        premium.adsalescloud__Pricing_Method__c = 'Any value';
        premium.adsalescloud__Price_Book__c = component.get('v.recordId');
        premium.adsalescloud__Premium_Rate_Values__r = {};
        premium.adsalescloud__Premium_Rate_Values__r.totalSize = 1;
        premium.adsalescloud__Premium_Rate_Values__r.done = true;
        premium.adsalescloud__Premium_Rate_Values__r.records = [];
        var value = {
            'adsalescloud__Amount__c': '',
            'adsalescloud__Payment_model__c': 'Amount',
            'adsalescloud__Rate_Type__c': 'CPM',
        }
        if($A.util.isEmpty(premium.premiumFeatureId)) {
            value.adsalescloud__Value__c = 'Any value';
        }
        else {
            value.adsalescloud__Value__c = 'All other values';
        }
        premium.adsalescloud__Premium_Rate_Values__r.records.push(value);
        this.refreshPremiumList(component, premiumFeatureValue);
        $A.util.removeClass(component.find('menuBar'), 'slds-is-open');
        premium.valueList = component.get('v.keyValueMap')[premiumFeatureId] ? component.get('v.keyValueMap')[premiumFeatureId].values : null;
        if(premiumFeatureId && !premium.valueList){
            component.set('v.showSpinner', true);
            this.fetchValues(component, premiumFeatureId, premium, premiumList.length,  1);/*
            var action = component.get("c.getKeyValues");
            action.setParams({keyIds: [premiumFeatureId], loadPage : 1});
            action.setCallback(this, function(response){
                if(response.getState() === "SUCCESS"){
                    var keyValueMap = component.get('v.keyValueMap');  
                    keyValueMap[premiumFeatureId] = response.getReturnValue()[premiumFeatureId];
                    premium.valueList = keyValueMap[premiumFeatureId].values;
                    premiumList.push(premium);
                    component.set('v.premiumList', premiumList);
                }
                else{
                    
                }
                component.set('v.showSpinner', false);
            });
            $A.enqueueAction(action);*/
        }
        else{
            premiumList.push(premium);
            component.set('v.premiumList', premiumList);          
        }
    },
    deletePremium: function(component, premiumIndex) {
        var premiumList = component.get('v.premiumList');
        var premiumFeatureList = component.get('v.premiumFeatureList');
        var premiumValue = premiumList[premiumIndex].adsalescloud__Premium_Feature__c;
        var deletedPremiumList = component.get('v.deletedPremiumList');
        var deletedValueList = component.get('v.deletedValueList');
        if(!$A.util.isEmpty(premiumList[premiumIndex].Id)) {
            delete premiumList[premiumIndex].premiumFeatureId;
            delete premiumList[premiumIndex].valueList;
            deletedPremiumList.push(premiumList[premiumIndex]);
            premiumList[premiumIndex].adsalescloud__Premium_Rate_Values__r.records.forEach(function(value, index) {
                if(!$A.util.isEmpty(value.Id)) {
                    deletedValueList.push(value);
                }
            });
        }
        premiumList.splice(premiumIndex, 1);
        premiumFeatureList.push(component.get('v.premiumFeatureMap').get(premiumValue));
        premiumFeatureList = this.sortPremiumFeatureList(premiumFeatureList);
        component.set('v.premiumFeatureList', premiumFeatureList);
        if($A.util.isEmpty(premiumList)) {
            component.set('v.status', 'Click the Add Premium button to configure Premiums for this Price Book.');
        }
        component.set('v.premiumList', premiumList);
    },
    addValue: function(component, index) {
        var premium = component.get('v.premiumList[' + index + ']');
        premium.adsalescloud__Premium_Rate_Values__r.totalSize++;
        var value = {
            'adsalescloud__Amount__c': '',
            'adsalescloud__Payment_model__c': 'Amount',
            'adsalescloud__Rate_Type__c': 'CPM',
        }
        if($A.util.isEmpty(premium.premiumFeatureId)) {
            value.adsalescloud__Value__c = 'Any value';
        }
        else {
            value.adsalescloud__Value__c = 'All other values';
        }
        if(!$A.util.isEmpty(premium.Id)) {
            value.adsalescloud__Premium__c = premium.Id;
        }
        premium.adsalescloud__Premium_Rate_Values__r.records.push(value);
        component.set('v.premiumList[' + index + ']', JSON.parse(JSON.stringify(premium)));
    },
    deleteValue: function(component, premiumIndex, valueIndex) {
        var premium = component.get('v.premiumList[' + premiumIndex + ']');
        premium.adsalescloud__Premium_Rate_Values__r.totalSize--;
        var valueList = premium.adsalescloud__Premium_Rate_Values__r.records;
        var deletedValueList = component.get('v.deletedValueList');
        if(!$A.util.isEmpty(valueList[valueIndex].Id)) {
            deletedValueList.push(valueList[valueIndex]);
        }
        valueList.splice(valueIndex, 1);
        premium.adsalescloud__Premium_Rate_Values__r.records = valueList;
        component.set('v.premiumList[' + premiumIndex + ']', premium);
    },
    showButtonMenu: function(component) {
        $A.util.toggleClass(component.find('menuBar'), 'slds-is-open');
        if($A.util.hasClass(component.find('menuBar'), 'slds-is-open')) {
            window.setTimeout(
                $A.getCallback(function() {
                    document.getElementById('menuItem0').focus();
                }), 1
            );
        }
    },
    hideButtonMenu: function(component) {
        window.setTimeout(
            $A.getCallback(function() {
                try {
                    if(!((document.activeElement.className === 'menuItem')))
                        $A.util.removeClass(component.find('menuBar'), 'slds-is-open');
                }
                catch(e) {
                    $A.util.removeClass(component.find('menuBar'), 'slds-is-open');
                }
            }), 5
        );
    },
    hideError: function(component) {
        window.setTimeout(
            $A.getCallback(function() {
                component.set('v.error', '');
            }), 4000
        );
    },
    navigateToReturnPage: function(component) {
        if(component.get("v.isLightning")){
            var navEvt = $A.get("e.force:navigateToSObject");
            if(navEvt){
                navEvt.setParams({
                    "recordId": component.get('v.recordId'),
                    "slideDevName": "related"
                });
                navEvt.fire();
            }
            else{
                sforce.one.navigateToSObject(component.get('v.recordId'), 'related');
            }
        }
        else{
            document.location.href = '/' + component.get('v.recordId');
        }
    },
    refreshValuesOnPremiums : function(component){
        var premiumList = component.get("v.premiumList");
        var keyValueMap = component.get("v.keyValueMap");
        premiumList.forEach(function(premium){
            premium.valueList = keyValueMap[premium.premiumFeatureId] ? keyValueMap[premium.premiumFeatureId].values : null;
        });
        component.set("v.premiumList", premiumList);
    },
    concatKeyValueMap : function(map1, map2){
        if($A.util.isEmpty(map1))
            return map2;
        if($A.util.isEmpty(map2))
            return map1;
        Object.keys(map2).forEach(function(key){
            map1[key].values = map1[key].values.concat(map2[key].values);
            map1[key].paginationInfo = map2[key].paginationInfo;
        });
        return map1;
    },
})