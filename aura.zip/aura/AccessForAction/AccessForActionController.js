({
	doInit : function(component, event, helper) {
        var action = component.get("c.getAccessForAction");
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                component.set("v.objAction", response.getReturnValue());
            }
            else{
                component.set('v.message','ERROR occured while getting access for action setting.');
                component.set('v.messageType', $A.get("$Label.c.ERROR"));
            }
        });
        $A.enqueueAction(action);
	
	},
	saveDFPActionJS : function(component, event, helper) {
	   
        var action = component.get("c.saveDFPAction");
        action.setParams({"objAction" : component.get("v.objAction")});
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                component.set('v.message','Access for action setting updated successfully');
                component.set('v.messageType', $A.get("$Label.c.SUCCESS"));
            }
            else{
                component.set('v.message','ERROR occured while updating Access for action setting.');
                component.set('v.messageType', $A.get("$Label.c.ERROR"));
            }
        });
        $A.enqueueAction(action);
	}
})