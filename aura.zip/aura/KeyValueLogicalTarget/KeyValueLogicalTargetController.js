({
  doInit: function(component, event, helper) {
    var targets = component.get('v.targets');
    var setIndex = component.get('v.setIndex');
    if(targets) {
      var setRows = targets[setIndex];
      var rows = [];
      if(setRows){
        component.set('v.setRows', setRows);
        for(var i=0;i<setRows.length;i++){
          rows.push(i);
        }
      }else{
        rows.push(0);
      }
      component.set('v.rows', rows);
    }
  },
  addNewRowHandler: function(component, event, helper) {
    var rows = component.get('v.rows');
    rows.push(rows[rows.length - 1] + 1);
    component.set('v.rows', rows);
  },
  removeKeyValueHandler: function(component, event, helper) {
    var ind = event.getParam('index');
    var keyId = event.getParam('keyId');
    var rows = Array.from(component.get('v.rows'));
    var setRows = component.get('v.setRows');
    if(setRows){
      setRows.splice(ind,1);
    }
    var selectedKeys = component.get('v.selectedKeys');
    rows.splice(ind, 1);
    if(keyId) {
      var indx = selectedKeys.indexOf(keyId);
      if(indx !== -1) {
        selectedKeys.splice(indx, 1);
        component.set('v.selectedKeys', selectedKeys);
      }
    }
    if(rows.length === 0) {
      var evt = component.getEvent('removeKeyValueSet');
      evt.setParams({
        'index': component.get('v.setIndex')
      });
      evt.fire();
      return;
    }
    component.set('v.setRows', setRows);
    component.set('v.rows', rows);
  },
  setRowsChangeHandler: function(component,event,helper){
    var targets = component.get('v.targets');
    var setIndex = component.get('v.setIndex');
    var setRows = component.get('v.setRows');
    if(!targets[setIndex]) targets[setIndex] = [];
    targets[setIndex] = setRows;
    component.set('v.targets',targets);
  }
});