({
  timeout: null,
  init: function(component) {
    if(component.get('v.segments'))
      this.selectedKeysHandler(component);
    else
      this.populateKeys(component);

    var selectedKey = component.get('v.selectedKey');
    if(selectedKey) {
      var selectedOptions = [selectedKey.value];
      component.set('v.selectedOptions', selectedOptions);
    }
  },
  selectedKeysHandler: function(component) {
    var selectedKeys = JSON.parse(JSON.stringify(component.get('v.selectedKeys')));
    var selectedKey = component.get('v.selectedKey');
    var keys = component.get('v.searchEnabled') ? JSON.parse(JSON.stringify(component.get('v.searchedKeys'))) : JSON.parse(JSON.stringify(component.get('v.keys')));

    if(selectedKeys) {
      if(selectedKey) {
        var ind = selectedKeys.indexOf(selectedKey.value);
        if(ind !== -1) {
          selectedKeys.splice(ind, 1);
        }
      }
      for(var key = 0; key < selectedKeys.length; key++) {
        delete keys[selectedKeys[key]];
      }
    }
    var keyList = Object.values(keys);
    component.set('v.options', keyList);
  },
  compare: function(a, b) {
    if(a.value < b.value)
      return -1;
    if(a.value > b.value)
      return 1;
    return 0;
  },
  populateKeys: function(component) {
    var keys = component.get('v.searchEnabled') ? JSON.parse(JSON.stringify(component.get('v.searchedKeys'))) : JSON.parse(JSON.stringify(component.get('v.keys')));
    var keyList = Object.values(keys);
    var selectedKey = component.get('v.selectedKey');
    keyList.sort(this.compare);
    if(selectedKey && !keys[selectedKey.value]) {
      keyList.push(selectedKey);
    }
    component.set('v.options', keyList);
  },
  searchKeysHandler: function(component) {
    var term = component.get('v.searchTerm');
    var self = this;
    if(term && term.trim()) {
      // component.set('v.options', []);
      component.set('v.searchEnabled', true);
      clearTimeout(self.timeout);
      self.timeout = setTimeout($A.getCallback(function() {
        self.getSearchResults(component);
      }), 500);
    } else if(component.get('v.searchEnabled')) {
      component.set('v.searchEnabled',false);
      if(component.get('v.segments'))
        this.selectedKeysHandler(component);
      else
        this.populateKeys(component);
    }
  },
  getSearchResults: function(component) {
    var self = this;
    var searchTerm = component.get('v.searchTerm');
    this.fetchData(component, 'getCustomKeyTargets', {
      'searchTerm': searchTerm.trim(),
    }, function(res) {
      if(res.status === 'OK') {
        var searchedKeys = res.targets;
        component.set('v.searchedKeys', searchedKeys);
        if(component.get('v.segments'))
          self.selectedKeysHandler(component);
        else
          self.populateKeys(component);
      }
    });

  }
});