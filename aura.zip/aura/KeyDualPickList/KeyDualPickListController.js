({
  doInit: function(component, event, helper) {
    helper.init(component);
  },
  selectedKeysChangeHandler: function(component, event, helper) {
    if(component.get('v.segments'))
      helper.selectedKeysHandler(component);
  },
  showModalHandler: function(component, event, helper) {
    console.log('show modal  ',JSON.stringify(component.get('v.selectedKey')));
    if(component.get('v.isCustomizable'))
      component.set('v.showModal', true);
  },
  hideModalHandler: function(component, event, helper) {
    console.log('hide modal ',JSON.stringify(component.get('v.selectedKey')));

    component.set('v.showModal', false);
  },
  handleChange: function(component, event, helper) {
    var selected = event.getParam('value');
    var selectedKey = component.get('v.selectedKey');
    var selectedKeys = component.get('v.selectedKeys');
    var keys = component.get('v.searchEnabled') ? JSON.parse(JSON.stringify(component.get('v.searchedKeys'))) : JSON.parse(JSON.stringify(component.get('v.keys')));

    if((!selected || selected.length === 0) && selectedKey) {
      var ind = selectedKeys.indexOf(selectedKey.value);
      if(ind !== -1) {
        selectedKeys.splice(ind, 1);
      }
      selectedKey = {};
    } else {
      for(var i = 0; i < selected.length; i++) {
        selectedKey = keys[selected[i]];
      }
      selectedKeys.push(selectedKey.value);
    }
    if(component.get('v.searchEnabled')){
      var defaultKeys = component.get('v.keys');
      defaultKeys[selectedKey.value] = selectedKey;
      component.set('v.keys',defaultKeys);
    }
    component.set('v.selectedKey', selectedKey);
    component.set('v.selectedKeys', selectedKeys);
  },
  search: function(component,event,helper){
    helper.searchKeysHandler(component);
  }
});