({
	doInit: function(component) {
        var action = component.get("c.checkPrimaryProposalRecord");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                var record = response.getReturnValue();
                component.set('v.hasPrimaryProposal', record);
                component.set('v.initiliazed', true);
            }
            else if(state === 'ERROR') {
                var errorMessage = response.getError()[0].message;
            }
      });
      $A.enqueueAction(action);
    },
    
    cloneOpportunity: function(component) {
        component.set("v.loading",true);
        component.set('v.isButtonDisabled', true);
        var action = component.get("c.cloneOpportunityRecord");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            component.set("v.loading",false);
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                var cloneOppRecordId = response.getReturnValue();
                var navEvt = $A.get("e.force:navigateToSObject");
                navEvt.setParams({
                    "recordId": cloneOppRecordId,
                    "slideDevName": "detail"
                });
                navEvt.fire();
            }
            else if(state === 'ERROR') {
              component.set("v.showToast",true);  
              var errorMessage = response.getError()[0].pageErrors[0].message;
                 component.set("v.status",$A.get("$Label.c.ERROR"));
                 if (errorMessage) {
                     component.set("v.message",errorMessage);
                 } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
                component.set('v.isButtonDisabled', false);
            }
      });
      $A.enqueueAction(action);
    },
})