({
    doInit: function(component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 50rem; transform: inherit !important;}.panel .closeIcon{display:none} .slds-modal__content{max-height: calc(50vh - 210px);}</style>');
        helper.doInit(component);
    },
	cloneOpportunity : function (component, event, helper) {
        helper.cloneOpportunity(component);
    },
    
    closeModal : function (component) {
        $A.get("e.force:closeQuickAction").fire();
    },
})