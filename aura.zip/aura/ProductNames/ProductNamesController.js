({
  doInit: function(component, event, helper) {
    var textAreaRef = component.find('idProductNameTextArea');
    var selectedOptionsMap = component.get('v.selectedOptionValues');

    helper.productNames = [];
    helper.products = [];
    helper.combine(selectedOptionsMap, [], 0,component);
    var names = helper.productNames;
    var strName = names.join('\n');
    component.set('v.products',helper.products);
    textAreaRef.set('v.value', strName ? strName : 'Product Template Name missing');
    component.set('v.textAreaData', helper.productNames);

  },
  openModel: function(component, event, helper) {
    component.set('v.isOpen', true);
  }

});