({
  products: [],
  productNames: [],
  productFieldMap: {
    'Type': 'adsalescloud__Line_Item_Type__c',
    'Rate Type': 'adsalescloud__Rate_Type__c',
    'Frequency Cap': 'adsalescloud__Frequency_Caps_per_User_Details__c',
    'Inventory Sizes': 'adsalescloud__Inventory_Sizes__c',
    'Priority': 'adsalescloud__Line_Item_Priority__c'
  },
  productSegmentFieldMap: {
    'Ad units': 'adsalescloud__Ad_Units_Segments__c',
    'Key-Values': 'adsalescloud__Key_value_Segments__c',
    'Placements': 'adsalescloud__Placements_Segments__c',
    'Geography': 'adsalescloud__Geo_Segments__c',
    'Bandwidth': 'adsalescloud__Bandwidth_Group_Segments__c',
    'Mobile carrier': 'adsalescloud__Mobile_Carrier_Segments__c',
    'User domains': 'adsalescloud__User_Domain_Segments__c',
    'Device Capability': 'adsalescloud__Device_Capability_Segments__c',
    'Device Category': 'adsalescloud__Device_Category_Segments__c',
    'Device Manufacturer': 'adsalescloud__Device_Manufacturer_Segments__c',
    'Mobile devices': 'adsalescloud__Mobile_Devices_Segments__c',
    'Mobile devices submodels': 'adsalescloud__Mobile_Device_Submodels_Segments__c',
    'Operating System': 'adsalescloud__Operating_System_Segments__c',
    'Operating System Versions': 'adsalescloud__Operating_System_Version_Segments__c',
    'Browser': 'adsalescloud__Browser_Segments__c',
    'Browser Language': 'adsalescloud__Browser_Language_Segments__c',
    'Content': 'adsalescloud__Video_Content_Segments__c',
    'Content Bundle': 'adsalescloud__Video_Content_Segments__c',
    'Video Position': 'adsalescloud__Video_Position_Segments__c'
  },
  productTargetingFieldMap: {
    'Ad units': 'adsalescloud__Ad_Units_Targeting__c',
    'Key-Values': 'adsalescloud__Key_value_Targeting__c',
    'Placements': 'adsalescloud__Placements_Targeting__c',
    'Geography': 'adsalescloud__Geo_Targeting__c',
    'Bandwidth': 'adsalescloud__Bandwidth_Group_Targeting__c',
    'Mobile carrier': 'adsalescloud__Mobile_Carrier_Targeting__c',
    'User domains': 'adsalescloud__User_Domain_Targeting__c',
    'Device Capability': 'adsalescloud__Device_Capability_Targeting__c',
    'Device Category': 'adsalescloud__Device_Category_Targeting__c',
    'Device Manufacturer': 'adsalescloud__Device_Manufacturer_Targeting__c',
    'Mobile devices': 'adsalescloud__Mobile_Devices_Targeting__c',
    'Mobile devices submodels': 'adsalescloud__Mobile_Device_Submodels_Targeting__c',
    'Operating System': 'adsalescloud__Operating_System_Targeting__c',
    'Operating System Versions': 'adsalescloud__Operating_System_Version_Targeting__c',
    'Browser': 'adsalescloud__Browser_Targeting__c',
    'Browser Language': 'adsalescloud__Browser_Language_Targeting__c',
    'Mobile Application Targeting': 'adsalescloud__Mobile_Application_Targeting__c',
    'Content': 'adsalescloud__Video_Content_Targeting__c',
    'Content Bundle': 'adsalescloud__Video_Content_Targeting__c',
    'Video Position': 'adsalescloud__Video_Position_Targeting__c'
  },
  combine: function(input, current, k, component) {
    if(k === input.length) {
      var name = '';
      var macros = [];
      for(var i = 0; i < k; i++) {
        name += current[i].name + ' ';
        macros.push(current[i]);
      }
      this.productNames.push(name);
      this.populateProductFields(component, name, macros);
    } else {
      for(var j = 0; j < input[k].length; j++) {
        current[k] = input[k][j];
        this.combine(input, current, k + 1, component);
      }
    }
  },
  populateProductFields: function(component, name, nameOptions) {
    var productTemplate = component.get('v.record');
    var videoContentSubcategries = ['Content', 'Content Bundle'];
    var keyValueObj = null;
    var videoCntSegments = {};
    var videoCntTargets = {};
    var product = {'sobjectType': 'Product2', 'Name': name, 'adsalescloud__Ad_Sales_Product_Template__c': productTemplate.Id};
    for(var i = 0; i < nameOptions.length; i++) {
      var macro = JSON.parse(JSON.stringify(nameOptions[i]));
      switch(macro.type) {
        case 'Type':
        case 'Priority':
        case 'Rate Type':
        case 'Frequency Cap':
          product[this.productFieldMap[macro.type]] = productTemplate[this.productFieldMap[macro.type]];
          break;
        case 'Key-Values':
          if(keyValueObj) {
            keyValueObj.children[0].children.push(Object.assign({}, macro.obj.children[0].children[0]));
          } else {
            keyValueObj = JSON.parse(JSON.stringify(macro.obj)); // just to copy value not refrence i.e deep cloning
          }
          break;
        case 'Standard':
        case 'Master/Companion':
        case 'Video VAST':
          product['adsalescloud__Inventory_Size_Segment__c'] = JSON.stringify([macro.obj]);
          break;
        case 'Video Position':
          product[this.productSegmentFieldMap[macro.type]] = JSON.stringify([macro.obj]);
          product[this.productTargetingFieldMap[macro.type]] = JSON.stringify([macro.obj]);
          break;
        default:
          if(this.productTargetingFieldMap[macro.type]) {
            var included = [], excluded = [];
            if(macro.action === 'include')
              included.push(macro.id);
            else
              excluded.push(macro.id);

            if(videoContentSubcategries.includes(macro.type)) {
              videoCntSegments[macro.type] = {'included': included, 'excluded': excluded};
              videoCntTargets[macro.type === 'Content Bundle' ? 'Bundles' : macro.type] = {'included': included, 'excluded': excluded};
            } else {
              product[this.productSegmentFieldMap[macro.type]] = JSON.stringify({'included': included, 'excluded': excluded});
              product[this.productTargetingFieldMap[macro.type]] = JSON.stringify({'included': included, 'excluded': excluded});
            }
          }
      }
    }
    if(keyValueObj) {
      product[this.productSegmentFieldMap['Key-Values']] = JSON.stringify(keyValueObj);
      product[this.productTargetingFieldMap['Key-Values']] = JSON.stringify(keyValueObj);
    }
    if(Object.keys(videoCntSegments).length > 0 && Object.keys(videoCntTargets).length > 0) {
      product[this.productSegmentFieldMap['Content']] = JSON.stringify(videoCntSegments);
      product[this.productTargetingFieldMap['Content']] = JSON.stringify(videoCntTargets);
    }

    for(var key in this.productTargetingFieldMap) {
      if(this.productTargetingFieldMap.hasOwnProperty(key) && !product[this.productTargetingFieldMap[key]]) {
        product[this.productTargetingFieldMap[key]] = productTemplate[this.productTargetingFieldMap[key]];
      }
    }
    product['adsalescloud__Product_Name_Details__c'] = JSON.stringify(nameOptions);
    product['adsalescloud__Customizable_Attributes_Details__c'] = productTemplate['adsalescloud__Customizable_Attributes_Details__c'];
    product['adsalescloud__Day_and_Time_Details__c'] = productTemplate['adsalescloud__Day_and_Time_Details__c'];
    product['adsalescloud__Inventory_Sizes__c'] = product['adsalescloud__Inventory_Size_Segment__c'] ? product['adsalescloud__Inventory_Size_Segment__c'] : productTemplate['adsalescloud__Inventory_Sizes__c'];
    this.products.push(product);
  }
});