({
    getPackageProductsList : function(component, event, helper) {
        helper.getPackageProductsList(component);
    },

    toggleFilterBar : function(component, event, helper){
        var showFilterBar = component.get("v.showFilterBar");
        if(showFilterBar){
	        $A.util.removeClass(component.find("productFilterBar"),"slds-hide")
        }else{
            $A.util.addClass(component.find("productFilterBar"),"slds-hide")
        }
    },

    applyFilter : function(component, event, helper){
        helper.applyFilter(component);
    },

    filterProductIds : function(component, event, helper){
        helper.filterProductIds(component);
    },

    filterProductRecords : function(component, event, helper){
        helper.filterProductRecords(component);
    },
    
    destroyComponent:function(component,event){
        component.destroy();
    }
})