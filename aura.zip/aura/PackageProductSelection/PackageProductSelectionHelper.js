({
  getPackageProductsList: function(component) {
    var self = this;
    this.fetchData(component,
      'getProductsList',
      {},
      function(allProductList) {
        if(allProductList) {
          component.set('v.allProductList', allProductList);
          self.filterProductIds(component);
          component.set('v.showSpinner', false);

        }
      });
  },

  applyFilter: function(component) {
    component.set('v.showSpinner', true);
    var self = this;
    var filterInfo = component.get('v._filter');
    var orderBy = component.get('v.orderBy');
    filterInfo = filterInfo ? filterInfo : {};
    filterInfo.orderBy = orderBy;
    this.fetchData(component,
      'applyFilterSearch',
      {
        'filterInfoStr': JSON.stringify(filterInfo)
      },
      function(response) {
        component.set('v.showSpinner', false);
        if(response.status === 'OK') {
          component.set('v.allProductList', response.data);
          self.filterProductIds(component);
        }else{
          component.set('v.errorMsg',response.msg);
        }
      },function(errors){
        component.set('v.errorMsg',errors[0]);
      });
  },

  filterProductIds: function(component) {
    var packageProductList = component.get('v.packageProductList');
    var existingProdctIdList = [];
    for(var index in packageProductList) {
      existingProdctIdList.push(packageProductList[index].productId);
    }
    component.set('v.existingProdctIdList', existingProdctIdList);
  },

  filterProductRecords: function(component) {
    var existingProdctIdList = component.get('v.existingProdctIdList');
    var allProductList = component.get('v.allProductList');
    var productListToShow = [];
    for(var index in allProductList) {
      if(existingProdctIdList.indexOf(allProductList[index].productId) === -1) {
        productListToShow.push(allProductList[index]);
      }
    }
    component.set('v.productList', productListToShow);
  },
});