({
  doInit: function(component) {
    var availablePricebooks = component.get('v.availablePriceBookObjectsFromServer');
    var selectedPriceBooks = component.get('v.selectedPriceBookObjects');
    var rateType = component.get('v.rateType');
    var availablePricebookList = [];
    var selectedPriceBookList = [];
    for(var key in selectedPriceBooks) {
      if(rateType.includes('CPM')) {
        selectedPriceBooks[key]['adsalescloud__Product_Rate__c'] = (selectedPriceBooks[key]['adsalescloud__Product_Rate__c'] || 0) * 1000;
      }
      selectedPriceBookList.push(selectedPriceBooks[key].adsalescloud__Price_Book__c);
    }

    availablePricebooks.forEach(function(obj, index) {
      var newObj = {};
      newObj.value = obj.Id;
      newObj.label = obj.Name;
      availablePricebookList.push(newObj);
    });
    component.set('v.availablePriceBookList', availablePricebookList);
    this.setPricebookMap(component);
    component.set('v.selectedPriceBookList', selectedPriceBookList);
  },
  setPricebookMap: function(component) {
    var availablePricebooks = component.get('v.availablePriceBookObjectsFromServer');
    var pricebookMap = {};
    availablePricebooks.forEach(function(obj, index) {
      pricebookMap[obj.Id] = obj;
    });
    component.set('v.allPriceBookMap', pricebookMap);
  },
  refreshSelectedList: function(component) {
    var selectedPriceBookList = JSON.parse(JSON.stringify(component.get('v.selectedPriceBookList')));
    var selectedPriceBooks = component.get('v.selectedPriceBookObjects');
    var pricebookMap = component.get('v.allPriceBookMap');

    if(selectedPriceBooks.length > 0) {
      selectedPriceBooks.forEach(function(value, index) {
        selectedPriceBookList.splice(selectedPriceBookList.indexOf(value.adsalescloud__Price_Book__c), 1);
      });
    }
    if(selectedPriceBookList && selectedPriceBookList.length > 0) {
      selectedPriceBookList.forEach(function(value, index) {
        if(value) {
          selectedPriceBooks.push({
            'adsalescloud__Price_Book__r': {'Name': pricebookMap[value].Name},
            'adsalescloud__Price_Book_Status__c': pricebookMap[value].IsActive,
            'adsalescloud__Product_Rate__c': 0,
            'adsalescloud__Price_Book__c': value,
          });
        }
      });
      //console.log('selectedPriceBooks:: ',JSON.stringify(selectedPriceBooks));
      component.set('v.selectedPriceBookObjects', selectedPriceBooks);
    }
  },
  removePricebook: function(component, event) {
    var index = event.getSource().get('v.name');
    var selectedPriceBooks = component.get('v.selectedPriceBookObjects');
    var deletedPriceBookList = component.get('v.deletedPriceBookList');
    var selectedPriceBookList = component.get('v.selectedPriceBookList');
    if(selectedPriceBooks[index].Id) {
      deletedPriceBookList.push(selectedPriceBooks[index]);
    }
    selectedPriceBookList.splice(selectedPriceBookList.indexOf(selectedPriceBooks[index].adsalescloud__Price_Book__c), 1);
    selectedPriceBooks.splice(index, 1);
    component.set('v.selectedPriceBookObjects', selectedPriceBooks);
    component.set('v.deletedPriceBookList', deletedPriceBookList);
    component.set('v.selectedPriceBookList', selectedPriceBookList);
  },
});