({
  doInit: function(component, event, helper) {
    helper.doInit(component);
  },

  removePricebook: function(component, event, helper) {
    helper.removePricebook(component, event);
  },

  showModal: function(component) {
    var modalContainer = component.find('modalContainer');
    $A.util.removeClass(modalContainer, 'slds-hide');
  },

  closeModal: function(component, event, helper) {
    var modalContainer = component.find('modalContainer');
    $A.util.addClass(modalContainer, 'slds-hide');
  },
  refreshSelectedList: function(component, event, helper) {
    helper.refreshSelectedList(component);
  },
  validate: function(component, event, helper) {
      if(event.currentTarget.get("v.value") < 0){
          alert("product rate nigative nahi ho sakta.");
          alert("product rate can not be negative");
      }
  },
    rateChangeHandler: function(component, event, helper) {

  }

})