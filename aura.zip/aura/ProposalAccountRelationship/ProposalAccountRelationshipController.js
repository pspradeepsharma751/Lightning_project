({
	 doInit : function(component, event, helper){
        helper.doInit(component,event);
    },
    saveProposalAccount : function(component, event, helper){
        var accountDFPFieldValue = component.get('v.accountDFPFieldValue');
        if($A.util.isEmpty(accountDFPFieldValue)) {
            var accDfpErrMsg = 'Please enter account DFP company id field name';
            helper.onError(component, accDfpErrMsg);
        }
        else{
            helper.saveProposalAccount(component,event);
        }
        
    },
    onPicklistChange: function(component, event, helper) {
        // get the value of select option
        component.set('v.proposalAccFieldValue', event.getSource().get("v.value"));
    },
    
    
})