({
    doInit : function(component, event){
        var action = component.get("c.populateProposalAccountLookupList");
        var optionList = [];
        action.setCallback(this, function(response){
            var rsp = JSON.parse(response.getReturnValue());
            var allValues = rsp.selectOptionlist;
            if(response.getState() === "SUCCESS"){
                if (allValues != undefined && allValues.length > 0) {
                    for (var i = 0; i < allValues.length; i++) {
                        optionList.push({
                            class: "optionClass",
                            label: allValues[i].optionLabel,
                            value: allValues[i].optionValue,
                            selected: allValues[i].selected
                        });
                    }
                }
               component.find('accIndustry').set("v.options", optionList);
                component.set('v.accountDFPFieldValue', rsp.accDoubleFieldValue);
            }
        });
        $A.enqueueAction(action);
    },
    saveProposalAccount : function(component, event){
        var action = component.get("c.saveProposalAccRelation");
        var optionList = [];
        action.setParams({
            'relationShipFieldName': component.get('v.proposalAccFieldValue'),
            'accDoubleClickField': component.get('v.accountDFPFieldValue')
        });
        action.setCallback(this, function(response){
           // var allValues = response.getReturnValue();
            if(response.getState() === "SUCCESS"){
                component.set('v.message', response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    onError: function(component, errorMessage) {
        this.showToast(component, 'Error', errorMessage, 'error');
    },
    showToast: function(component, title, message, type) {
        component.set('v.toastTitle', title);
        component.set('v.message', message);
        component.set('v.messageType', type);
        component.set('v.showToast', true);
    },
})