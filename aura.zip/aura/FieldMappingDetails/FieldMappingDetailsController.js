({
    saveRecord : function(component, event, helper) {
        helper.checkValidation(component);
    },
    
    init : function(component, event, helper) {
		helper.init(component,event);
    },
    
    loadData : function(component, event, helper) {
        helper.getData(component,event,component.get("v.fieldMapId"));        
    },
    
    cancelEditSave : function(component, event, helper){
    	helper.showHideDelete(component, event, true);
        helper.getData(component,event,component.get("v.fieldMapIdToLoadData"));
	},
	
    deleteRecord : function(component, event, helper){
        helper.deleteRecord(component,event);
	},
    
    showModal : function(component, event, helper){
        helper.showModal(component);
	},
    
    closeModal : function(component, event, helper){
        helper.closeModal(component);
	},
    
    editMode : function(component, event, helper){
        helper.editMode(component);
	},
    
    refreshView : function(component, event, helper){
        helper.refreshView(component, event);
    }
})