({
    init : function(component, event) {        
        var fieldId = event.getParam("fieldMapId");
        var objectId = event.getParam("objectMapId");
        var isEdit = event.getParam("isEdit");

        component.set("v.isEdit", isEdit);
        component.set("v.objectMapId", objectId);
        component.set("v.fieldMapId", fieldId);
        
        if(fieldId !== undefined) {
            this.getData(component,event,fieldId);
        } else {
            this.clearFieldMappingRecord(component, event);
        }
    },
    
    showModal : function(component) {
        var modalContainer = component.find("modalContainer");
        $A.util.removeClass(modalContainer, "slds-hide");
    },
    
    closeModal : function(component) {
        var modalContainer = component.find("modalContainer");
        $A.util.addClass(modalContainer, "slds-hide");
    },
    
    getData : function(component, event, fieldId) {
        component.set("v.showSpinner",true);
        
        var action = component.get("c.getFieldMappings");
        action.setParams({ "fieldMappingId" : fieldId});
        action.setCallback(this, function(response) {
            component.set("v.showSpinner",false);
            var state = response.getState();
            if (state === "SUCCESS") {
                var fieldMappingNames = response.getReturnValue();
                if(Object.keys(fieldMappingNames).length > 0) {
                    component.set("v.fieldMappingNames",fieldMappingNames);
                } else {
                    this.clearFieldMappingRecord(component, event);
                }
                
            } else {
                this.clearFieldMappingRecord(component, event);
            }
        });
        $A.enqueueAction(action);
    },
    
    /*
    	@description : This Method will show the "Delete" button if user clicks on the "Save" Button
    */
    showHideDelete : function(component, event, isShow) {
        component.set("v.isEdit", isShow);
    },
    
    saveRecord : function(component, event, rec) {
        var action = component.get("c.saveFieldMapping");
        action.setParams({ "fieldMappingObj" : rec});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                this.refreshView(component, event, component.get("v.objectMapId"));
                this.showToastMessage(component, "success", $A.get("$Label.c.FIELDMAPPING_SUCCESS_MSG"));
            }
        });
        $A.enqueueAction(action);
    },
    
    isDuplicate : function(component, event) {
        var rec = component.get("v.fieldMappingNames");
        var recId = component.get("v.fieldMapId");
        var isInsert = false;
        
        if(recId === undefined || recId === "") {
            isInsert = true;
            recId = "";
        }
        
        var action = component.get("c.isDuplicateRecord");
        action.setParams({"strName" : rec.Name,
                          "strId" : recId,
                          "objId" : rec.adsalescloud__Object_Mapping__c,
                          "isInsert" : isInsert});
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if(!response.getReturnValue()) {
                    this.saveRecord(component, event, rec);
                    this.showHideDelete(component, event, true);
                } else {
                    this.showToastMessage(component, "error", $A.get("$Label.c.DUPLICATE_FIELD_MAPPING_NAME"));
                }
            }
            scrollTo(0,0);
        });
        $A.enqueueAction(action);
    },
    
    deleteRecord : function(component, event){
        var action = component.get("c.deleteFieldMappingRecord");
        var fieldMappingRecordId = component.get("v.fieldMapId");
        
        action.setParams({ "fieldMappingRecordId" : fieldMappingRecordId});
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                component.set("v.fieldMapId","");
                this.refreshView(component, event, component.get("v.objectMapId"));
                this.clearFieldMappingRecord(component,event);
                this.closeModal(component);
                this.showToastMessage(component, "success", $A.get("$Label.c.FIELDMAPPING_DELETE_MSG"));
            }
        });
        $A.enqueueAction(action);
    },
    
    clearFieldMappingRecord : function(component, event){
        component.set("v.fieldMappingNames",{	"sobjectType": "adsalescloud__Field_Mapping__c",
                                             "Name": "",
                                             "adsalescloud__Proposal_Status_Field_Editability__c": "",
                                             "adsalescloud__SyncDirection__c": "",
                                             "adsalescloud__SalesforceFieldName__c": "",
                                             "adsalescloud__SalesforceFieldMaxLength__c": "",
                                             "adsalescloud__DoubleClickFieldName__c":"",
                                             "adsalescloud__DoubleClickFieldMaxLength__c":"",
                                             "adsalescloud__DoubleClickCustomFieldID__c":"",
                                             "adsalescloud__SalesforceDefaultValue__c":"",
                                             "adsalescloud__DoubleClickDefaultValue__c":"",
                                             "adsalescloud__Enabled__c":true,
                                             "adsalescloud__Object_Mapping__c":component.get("v.objectMapId")
                                            });
    },
    
    refreshView : function(component, event, objectId){
        var compEvent = $A.get("e.c:FieldMappingDetailsEvent");    
        compEvent.setParams({"objectMapId" : objectId});
        compEvent.fire();
    },
    
    showToastMessage : function(component, messageType, message){
        window.scrollTo(0,0);
        component.set("v.messageType", messageType);
        component.set("v.message", message);
    },
    
    checkValidation : function(component){
        var fieldName = component.get("v.fieldMappingNames.Name");
        if(fieldName.trim() !== "") {
            this.isDuplicate(component, event);
        } else {
         	this.showToastMessage(component, "error", $A.get("$Label.c.REQUIRED_FIELD_NAME_MSG"));   
            component.set("v.fieldMappingNames.Name","");
        }
    },
    
    editMode : function(component){
        component.set("v.isEdit", false);
        component.set("v.fieldMappingNames.adsalescloud__Object_Mapping__c", component.get("v.objectMapId"));
    }
    
})