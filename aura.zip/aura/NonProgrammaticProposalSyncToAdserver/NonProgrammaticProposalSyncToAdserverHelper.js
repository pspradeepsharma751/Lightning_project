({
	doInit : function (component) {
        component.set("v.showSpinner", true);
        component.set("v.readyForDFPError",$A.get("$Label.c.Not_Ready_for_Ad_Server"));
        var action = component.get("c.getReadyForDFPInformation");
        action.setParams({
            'recordId':component.get("v.recordId"),
            'action':'SyncToAdServer'
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                var response = JSON.parse(response.getReturnValue());
                var callOutException = response.callOutException;
                if(response.callOutException){
                    if(callOutException.indexOf("AUTH_FAILED") > -1){
                        if(confirm("User authentication failed while syncing with the Ad Server.\nPlease navigate to Ad Sales User Setup, authorize your Salesforce User with the Ad Server, and try again.")){
                            window.location.href ="/apex/AdSalesUserSetup";
                        } else {
                            $A.get('e.force:closeQuickAction').fire();
                            $A.get('e.force:refreshView').fire();
                        }
                    }
                    else if(callOutException.indexOf("NO_NETWORKS_TO_ACCESS") > -1){
                        if(confirm("Please make sure user is authorized with authenticated account and try again.")){
                            window.location.href ="/apex/AdSalesUserSetup";
                        } else {
                            $A.get('e.force:closeQuickAction').fire();
                            $A.get('e.force:refreshView').fire();
                        }
                    }
                } else {
                    component.set("v.readyForDFPInfo", response); 
                    component.set("v.showSpinner", false);
                    component.set("v.islightningCheckVald", false);
                    component.set("v.proposalRecord", response.proposalRecordObject);
                    if((response.countTotalPliError == 0 || response.containPliWarningMsg)  && 
                       (response.countTotalProposalError == 0 || response.containProposalWarningMsg || response.proposalErrorList.indexOf("Prompt to link") > -1 )){
                        var displayOkButton = component.find("displayOkButton");
                        $A.util.addClass(displayOkButton, 'slds-hide');
                        var dispBtn = component.find("displayButton");
                        $A.util.removeClass(dispBtn, 'slds-hide');
                        component.set("v.isStartSync", true);
                    }
                }   
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    syncProposal : function (component) {
        var readyForDFPInfo = component.get("v.readyForDFPInfo");
        var actionSyncingProposal = component.get("c.syncingProposal");
        var msg = '';
        actionSyncingProposal.setParams({
            recordId:component.get("v.recordId"),
            isLinkProposal: readyForDFPInfo.proposalErrorList.indexOf("Prompt to link") > -1?true:false
        });
        actionSyncingProposal.setCallback(this,function (response) {
            var state = response.getReturnValue().status;
            if(state === "Success") {
                msg = response.getReturnValue().message;
                if(readyForDFPInfo.unarchievedPliList.length > 0){
                    this.unArchievePLI(component);
                }
                
                var pliBatchNo = component.get("v.pliBatchNo"); 
                
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getReturnValue().message;
                if (errors) {
                    msg = errors;
                } else {
                    msg = $A.get("$Label.c.UNKNOWN_ERROR");
                }
            }
            
            component.set("v.proposalSyncMsg", msg);
            component.set("v.proposalStatus", state);
            component.set("v.isProposalSynced", true); 
            
            if(readyForDFPInfo.lineItemRecordList.length == 0){
                var displayFinalOkButton = component.find("displayFinalOkButton");
                $A.util.removeClass(displayFinalOkButton, 'slds-hide');
            }
            
            
        });
        $A.enqueueAction(actionSyncingProposal);
    },
    
    setPliIdsListHandler : function (component,helper) {
        if(component.get('v.proposalStatus') == 'Success'){
            var readyForDFPInfo = component.get('v.readyForDFPInfo');
            var pliBatchNo = component.get('v.pliBatchNo');
            var startIdx = component.get('v.startIdx'); 
            var pliCompletionStatus = false;
            var totalNoOfPLIBatches = readyForDFPInfo.lineItemRecordList.length/component.get('v.pliPerExecution');
       		var readyForDFPPLIList = readyForDFPInfo.lineItemRecordList;
            totalNoOfPLIBatches = Math.ceil(totalNoOfPLIBatches)
            if(totalNoOfPLIBatches ==1)
                var endIdx = readyForDFPInfo.lineItemRecordList.length;
            else
            	var endIdx = component.get('v.endIdx');
            
            if (pliBatchNo <= totalNoOfPLIBatches) {
                var pliIdList = [];
                var pliList = [];
                var errMsgObj = {};
                
                for(var idx = startIdx; idx < endIdx; idx++){
                    pliIdList.push(readyForDFPPLIList[idx].pliRecord.Id);
                    pliList.push({name : readyForDFPPLIList[idx].pliRecord.Name, id : readyForDFPPLIList[idx].pliRecord.Id});
                    
                }
                component.set('v.startIdx', endIdx);
                pliBatchNo = pliBatchNo+1;
                if(pliBatchNo == totalNoOfPLIBatches){
                    endIdx = readyForDFPInfo.lineItemRecordList.length;
                   // pliCompletionStatus = true;
                }
                else{
                    endIdx = endIdx + component.get('v.pliPerExecution');
                }
                
                component.set('v.endIdx', endIdx);
                component.set('v.pliBatchNo', pliBatchNo);
                this.syncPLI(component, pliIdList, pliList, totalNoOfPLIBatches,helper);
            }
        }
    },
    
    syncPLI : function (component, pliIdList, pliList, totalNoOfPLIBatches,helper) {
        var actionSyncingPLI = component.get("c.syncingPLI");
        var readyForDFPInfo = component.get('v.readyForDFPInfo');
        var proposalRecord = component.get("v.proposalRecord");
        var msg = '';
        var errMsgObj = {plisList : pliList , pliErrorList : ''};
        var errMsg = component.get("v.pliSyncErrMsg");
        var self = helper;
        var pliBatchNo = component.get('v.pliBatchNo');
        actionSyncingPLI.setParams({
            pliIds: pliIdList,
            proposalId:component.get("v.recordId")
        });
        actionSyncingPLI.setCallback(this,function (response) {
            var state = response.getReturnValue().status;
            if(state === "Success") {
                msg = response.getReturnValue().message;
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getReturnValue().message;
                if (errors) {
                    errMsgObj.pliErrorList = errors;
                } else {
                    errMsgObj.pliErrorList = $A.get("$Label.c.UNKNOWN_ERROR");
                }
                errMsg.push(errMsgObj);
                component.set("v.pliSyncErrMsg", errMsg); 
            }
            if(pliBatchNo > totalNoOfPLIBatches){
                if((readyForDFPInfo.containProposalWarningMsg && !readyForDFPInfo.unarchievedProposal) || proposalRecord.adsalescloud__isArchived__c){
                    this.archieveProposal(component);
                } else if(readyForDFPInfo.archievedPliList.length > 0){
                    this.archievePLI(component);
                }
                if(errMsg.length == 0){
                    this.approveAdserverOrder(component);
                }
                this.updatePLIAdserverStatus(component, helper);
               // this.updateProposalAdserverStatus(component);
                component.set("v.pliSyncMsg", msg);
                component.set("v.isPliSynced", true);
                component.set("v.pliStatus", state);
                var displayFinalOkButton = component.find("displayFinalOkButton");
                $A.util.removeClass(displayFinalOkButton, 'slds-hide');
                if(errMsg.length > 0)
                    component.set("v.hasError", true);
            }
            if (pliBatchNo <= totalNoOfPLIBatches) {
            	self.setPliIdsListHandler(component,helper);
            } 
        });
        $A.enqueueAction(actionSyncingPLI);
    },
    
    unarchieveProposal : function (component) {
        var readyForDFPInfo = component.get("v.readyForDFPInfo");
        var actionUnArchieveOrder = component.get("c.unArchieveOrder");
        var msg = '';
        actionUnArchieveOrder.setParams({
            orderId: readyForDFPInfo.OrderDfpId,
        });
        actionUnArchieveOrder.setCallback(this,function (response) {
            var state = response.getReturnValue().status;
            if(state === "Success") {
                msg = response.getReturnValue().message;
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getReturnValue().message;
                if (errors) {
                    msg = errors;
                } else {
                    msg = $A.get("$Label.c.UNKNOWN_ERROR");
                }
            }
        });
        $A.enqueueAction(actionUnArchieveOrder);
    },
    
    archieveProposal : function (component) {
        var readyForDFPInfo = component.get("v.readyForDFPInfo");
        var actionArchieveOrder = component.get("c.archieveOrder");
        var msg = '';
        actionArchieveOrder.setParams({
            orderId: readyForDFPInfo.OrderDfpId,
            proposalId:component.get("v.recordId")
        });
        actionArchieveOrder.setCallback(this,function (response) {
            var state = response.getReturnValue().status;
            if(state === "Success") {
                msg = response.getReturnValue().message;
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getReturnValue().message;
                if (errors) {
                    msg = errors;
                } else {
                    msg = $A.get("$Label.c.UNKNOWN_ERROR");
                }
            }
        });
        $A.enqueueAction(actionArchieveOrder);
    },
    
    unArchievePLI : function (component) {
        var readyForDFPInfo = component.get("v.readyForDFPInfo");
        var actionUnArchieveOLI = component.get("c.unArchieveOLI");
        var msg = '';
        actionUnArchieveOLI.setParams({
            unarchievedPliList: readyForDFPInfo.unarchievedPliList,
        });
        actionUnArchieveOLI.setCallback(this,function (response) {
            var state = response.getReturnValue().status;
            if(state === "Success") {
                msg = response.getReturnValue().message;
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getReturnValue().message;
                if (errors) {
                    msg = errors;
                } else {
                    msg = $A.get("$Label.c.UNKNOWN_ERROR");
                }
            }
        });
        $A.enqueueAction(actionUnArchieveOLI);
    },
    
    archievePLI : function (component) {
        var readyForDFPInfo = component.get("v.readyForDFPInfo");
        var actionArchieveOLI = component.get("c.archieveOLI");
        var msg = '';
        actionArchieveOLI.setParams({
            archievedPliList: readyForDFPInfo.archievedPliList,
        });
        actionArchieveOLI.setCallback(this,function (response) {
            var state = response.getReturnValue().status;
            if(state === "Success") {
                msg = response.getReturnValue().message;
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getReturnValue().message;
                if (errors) {
                    msg = errors;
                } else {
                    msg = $A.get("$Label.c.UNKNOWN_ERROR");
                }
            }
        });
        $A.enqueueAction(actionArchieveOLI);
    },
	updatePLIAdserverStatus : function (component, helper) {
         var updatePliAdserverOliStatus = component.get("c.updatePliAdserverOliStatus");
         var msg = '';
         updatePliAdserverOliStatus.setParams({
             proposalId:component.get("v.recordId"),
             'action':'SyncToAdServer'
         });
         updatePliAdserverOliStatus.setCallback(this,function (response) {
             var state = response.getReturnValue().status;
             if(state === "Success") {
                 msg = response.getReturnValue().message;
             } else if(state === "ERROR") {
                 component.set("v.status",$A.get("$Label.c.ERROR"));
                 var errors = response.getReturnValue().message;
                 if (errors) {
                     msg = errors;
                 } else {
                     msg = $A.get("$Label.c.UNKNOWN_ERROR");
                 }
             }
             this.updateProposalAdserverStatus(component);
         });
         $A.enqueueAction(updatePliAdserverOliStatus);
    },    
    updateProposalAdserverStatus : function (component) {
         var updateProposalAdserverOrderStatus = component.get("c.updateProposalAdserverOrderStatus");
         var msg = '';
         updateProposalAdserverOrderStatus.setParams({
             proposalId:component.get("v.recordId")
         });
         updateProposalAdserverOrderStatus.setCallback(this,function (response) {
             var state = response.getState();
         });
         $A.enqueueAction(updateProposalAdserverOrderStatus);
    },
    
    approveAdserverOrder : function (component) {
         var approveOrder = component.get("c.approveOrder");
         var msg = '';
         approveOrder.setParams({
             proposalId:component.get("v.recordId")
         });
         approveOrder.setCallback(this,function (response) {
             var state = response.getReturnValue().status;
             if(state === "Success") {
                 msg = response.getReturnValue().message;
             } else if(state === "ERROR") {
                 component.set("v.status",$A.get("$Label.c.ERROR"));
                 var errors = response.getReturnValue().message;
                 if (errors) {
                     msg = errors;
                 } else {
                     msg = $A.get("$Label.c.UNKNOWN_ERROR");
                 }
             }
         });
         $A.enqueueAction(approveOrder);
    },
})