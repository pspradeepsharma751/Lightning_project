({
  doInit: function(component, event, helper) {
    helper.getAdUnits(component);
  },
  hidePlacementChangeHandler: function(component,event,helper){
    helper.hidePlacementChangeHandler(component);
  }
});