({
  getAdUnits: function(component) {
    this.fetchData(component, 'getTargets', {
      'parentId': '',
      'offset': 0,
      'page_size': component.get('v.page_size'),
      'subCategory': 'Ad units'
    }, function(res) {
      if(res.status === 'OK') {
        var targets = res.targets;
        if(targets && targets.length > 0) component.set('v.defaultInventoryAdunit',targets[0]);
        if(!component.get('v.hidePlacement'))
          targets.push({'id':'','name':'Placements','hasChildren':true,'parentId':'0000','sub_category':'Placements'});
        component.set('v.targets', targets);
      }
      else{
        component.set('v.error', res.msg);
      }
      component.set('v.showSpinner', false);
    },function(error){
      component.set('v.showSpinner', false);
      component.set('v.error', error);
    });
  },
  hidePlacementChangeHandler: function(component){
    var hidePlacement =component.get('v.hidePlacement');
    var targets = component.get('v.targets');
    if(targets && targets.length > 0){
      if(hidePlacement && targets.length === 2){
        targets.splice(1,1);
      }
      if(!hidePlacement && targets.length === 1){
        targets.push({'id':'','name':'Placements','hasChildren':true,'parentId':'0000','sub_category':'Placements'});
      }
      component.set('v.targets',targets);
    }
  }
});