({
    doInit : function(component, event, helper) {        
        if($A.util.isEmpty(component.get("v.availableOptions")))
            helper.doInit(component);
        else{
            helper.initialize(component);
        }
    },
    updateSelectedOptions : function(component, event, helper) {
        helper.updateSelectedOptions(component);
    },
    showModal : function(component, event, helper) {
        component.set("v.showModal",true);
        if(!$A.util.isEmpty(component.get("v.onclickAction"))){
            $A.enqueueAction(component.get("v.onclickAction"));
        }
    },
    closeModal : function(component, event, helper) {
        component.set("v.showModal",false);
    },
    updateSelectedOptionValue : function(component, event, helper) {
        helper.updateSelectedOptionValue(component);
    },
})