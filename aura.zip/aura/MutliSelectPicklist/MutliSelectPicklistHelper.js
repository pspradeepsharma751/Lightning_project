({
    doInit : function(component) {
		var action=component.get("c.getRecords");
        action.setParams({
      		'modaltype': component.get('v.modaltype')
    	});
		action.setCallback(this, function(response){
			if(response.getState()==='SUCCESS'){
				var result=JSON.parse(response.getReturnValue());
				var optionList = [];
				var allOptions = new Map();
				result.forEach(function(value, index){
					optionList.push({"value" : value.name, "label" : value.name});
					allOptions.set(value.name,value);
				});
				component.set("v.allOptions",allOptions);
				component.set("v.availableOptions",optionList);
				this.initialize(component);
				this.updateSelectedOptionValue(component);
			}
            else{
                console.log('ERROR:\nCallout to fetch list of labels has been failed.');
            }
		});
		$A.enqueueAction(action);
	},
	initialize : function(component) {
        var object = component.get("v.record");
		var jsonData = {};
		var jsonDataMap = new Map();
        var richTextDataFieldName = component.get('v.richTextDataFieldName');
        if(!$A.util.isEmpty(richTextDataFieldName)){
            if(!$A.util.isEmpty(object[richTextDataFieldName])){
                jsonData = JSON.parse(object[richTextDataFieldName].replace(/<br>|\s\s|{\s|\s}|\[\s|\s\]/g,"").replace(/&quot;|“|”/g,"\""));
                jsonData.forEach(function(value,index){		// creating map of json objects
                    jsonDataMap.set(value.labelId, value);
                });
            }
            component.set("v.jsonData", jsonDataMap);
        }
        this.updateSelectedOptions(component);
	},
    updateSelectedOptions : function(component){
        var object = component.get("v.record");
        var selectedOptions = [];
        var textDataFieldName = component.get('v.textDataFieldName');
        if(object && !$A.util.isEmpty(object[textDataFieldName])){
            object[textDataFieldName] = object[textDataFieldName].replace(/,\s/g,',');
            selectedOptions = object[textDataFieldName].split(",");
        }
        component.set("v.selectedOptions",selectedOptions);
    },
	updateSelectedOptionValue : function(component){
		var recordObject = component.get("v.record");
		var selectedOptions = component.get("v.selectedOptions");
        var textDataFieldName = component.get('v.textDataFieldName');
        var richTextDataFieldName = component.get('v.richTextDataFieldName');
        var modalType = component.get('v.modaltype');
		if(!$A.util.isEmpty(selectedOptions)){	// setting for textfield on recordObject
			recordObject[textDataFieldName] = selectedOptions.join(', ');
		}
        if(!$A.util.isEmpty(richTextDataFieldName)){
            if(modalType === 'Label'){
                this.setLabelData(component);
            }
        }
        component.set("v.record."+textDataFieldName, recordObject[textDataFieldName]);
        var compEvent = component.getEvent("updateStatus");
        compEvent.fire();
    },
    setLabelData : function(component){
        var recordObject = component.get("v.record");
        var selectedOptions = component.get("v.selectedOptions");
        var richTextDataFieldName = component.get('v.richTextDataFieldName');

        var allOptions = component.get("v.allOptions");
        var recorddetail = [];
        selectedOptions.forEach(function(value, index){  // setting json for richTextarea field
            var option = allOptions.get(value);
            recorddetail.push({"labelId" : option.labelId,
                               "isNageted" : !option.isActive,
                               "name" : option.name});
        });
         recordObject[richTextDataFieldName] = JSON.stringify(recorddetail);
        component.set("v.record", recordObject);
    }
})