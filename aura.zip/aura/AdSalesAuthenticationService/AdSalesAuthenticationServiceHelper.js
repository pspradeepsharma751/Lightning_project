({
    /**
	* Shows the message on the on the authentication page.
	* @param messageType Type type of the message like - confirm, info, warning, error.
	* @param messageTitle  Message that will show to the user.
    */
    showMessage : function(component, messageType, message){
        component.set('v.messageType',messageType);
        component.set('v.message', message);
    },
    /**
	* Save/Update the Ad Sales Authentication Service
    */
    saveAdSalesAuthenticationSetting : function(component, event) {
        component.set('v.loading',true);																	// Setting the Spinner to visible
        var action = component.get("c.saveAdSalesAuthenticationSettingServerSide");							// Getting the server side controller
        action.setParams({ adSalesAuthentication : component.get("v.adSalesAuthenticationService") });		// Setting the parameters of the server side controller
        action.setCallback(this, function(response) {														// Calling the server side controller
            component.set('v.loading',false);
            component.set('v.message',"");
            var state = response.getState();
            if (state === "SUCCESS") {
                this.showMessage(component,'success', $A.get("$Label.c.AUTHENTICATION_SERVICE_SUCCESS_MSG"));   						// Shows the record if the record updated succesfully
                window.scrollTo(0,0);
            }
        });
        $A.enqueueAction(action);
	},
    /**
    * Get the data from the server side controller and setting it to the 'adSalesAuthenticationService' component.
    */
    getAdSalesAuthenticationSetting : function(component, event) {  
        component.set('v.loading',true);
        this.fetchData(component, 'getAdSalesAuthenticationSettingServerSide',{},
                       function(response) {
                           component.set('v.loading',false);
                           if(response) {
                               component.set("v.adSalesAuthenticationService", response);
                           }
                       });
        
/*        component.set('v.loading',true);																	// Setting the Spinner to visible
        var action = component.get("c.getAdSalesAuthenticationSettingServerSide");							// Getting the server side controller
        action.setCallback(this, function(response) {		
            component.set('v.loading',false);																// Calling the server side controller
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue() != null) {
					component.set("v.adSalesAuthenticationService", response.getReturnValue());				// Setting the data to the component which is returned by the apex controller
                }
            }
        });
        $A.enqueueAction(action); */
	}
})