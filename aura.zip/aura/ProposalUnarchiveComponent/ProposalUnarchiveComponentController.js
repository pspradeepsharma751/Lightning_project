({
    doInit: function(component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 50rem; transform: inherit !important;}.panel .closeIcon{display:none} .slds-modal__content{max-height: calc(50vh - 210px);}</style>');
        var sObjectName = component.get("v.sObjectName");
        var feildArray = ["adsalescloud__isArchived__c", "adsalescloud__Status__c"];
        if(sObjectName === "adsalescloud__Proposal_Line_Item__c"){
            feildArray.push("adsalescloud__Proposal__r.adsalescloud__Status__c");
        }
        component.set("v.queryFields",feildArray);
    },
    validate: function(component, event, helper) {
        helper.validate(component);
    },
	unarchiveRecord : function (component, event, helper) {
        helper.unarchiveRecord(component);
    },
    
    closeModal : function (component) {
        $A.get("e.force:closeQuickAction").fire();
    },
})