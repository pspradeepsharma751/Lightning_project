({
    validate: function(component) {
        var isArchived = component.get("v.record.adsalescloud__isArchived__c");
        var status = component.get("v.record.adsalescloud__Status__c");
        var sObjectName = component.get("v.sObjectName") === "adsalescloud__Proposal__c" ? "proposal" : "proposal line item";
            if(!isArchived ){
                component.set("v.errorMessage","This "+sObjectName+" is already unarchived.");
            }
        else if(sObjectName === "proposal"){
                if(status.indexOf("Draft")== -1  ||  status.indexOf("Approval")>-1  ||  status.indexOf("Finalized")> -1){
                component.set("v.errorMessage","Please retract the proposal to Draft status before unarchiving.");
            }
            else{
                 component.set("v.confirmationMessage","Are you sure you want to unarchive this proposal and its line items?");
            }
        }
            else{
                if(component.get("v.record.adsalescloud__Proposal__r.adsalescloud__Status__c").indexOf("Draft") == -1){
                    component.set("v.errorMessage","Please retract the related proposal to Draft status before unarchiving.");
                }
                else{
                    component.set("v.confirmationMessage","Are you sure you want to unarchive this proposal line item?");
                }
                
            }
    },
    
    unarchiveRecord:function (component) {
        component.set("v.loading",true);
        component.set("v.showToast",true);
        var sObjectName = component.get("v.sObjectName") === "adsalescloud__Proposal__c" ? "Proposal" : "Proposal line item";
        var action = component.get("c.unarchiveObjRecord");
        action.setParams({
            recordId: component.get("v.record.Id")
        });
        
        action.setCallback(this,function (response) {
            component.set("v.loading",false);
            var state = response.getState();
            if(state === "SUCCESS") {
                var toastEvent = $A.get('e.force:showToast');
				toastEvent.setParams({
					'title': 'Success!',
					'type': 'success',
					'message': sObjectName+' unarchived succesfully.'
				});
				toastEvent.fire();
                $A.get('e.force:refreshView').fire();
                $A.get("e.force:closeQuickAction").fire();                
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
})