({

    checkAssociatedAccount : function (component, event, helper) {
        if(component.get("v.sObjectName") == "Contact") { 
        	helper.checkAssociatedAccount(component);
        }
    },
    
    /*checkProposalSync : function (component, event, helper) {
        if(component.get("v.sObjectName") == "adsalescloud__Proposal__c") { 
        	helper.checkProposalSync(component);
        }
    },*/
 
    synAccount : function (component, event, helper) {
        helper.synAccount(component);
    },
    closeModal : function (component) {
        $A.get("e.force:closeQuickAction").fire();
        $A.get('e.force:refreshView').fire();
    },
    
    redirectToAccount : function (component, event, helper) {
        var accountId = component.get("v.simpleRecord.AccountId")
        helper.redirectToRecord(component, event, accountId);
    },
    
    doInit : function (component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 50rem; transform: inherit !important;}.panel .closeIcon{display:none} .slds-modal__content{max-height: calc(50vh - 210px);}</style>');
        console.log('==do init==>');
        component.set("v.readyForDFPError",$A.get("$Label.c.Not_Ready_for_Ad_Server"));
        var action = component.get("c.getReadyForDFPInformation");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                console.log('==init success==>'+JSON.stringify(response.getReturnValue()));
                component.set("v.readyForDFPInfo", response.getReturnValue());
                if((component.get("v.readyForDFPInfo.isCustomReadyForDFP") && !component.get("v.readyForDFPInfo.isReadyForDFP")))
                {
                    component.set("v.status",$A.get("$Label.c.ERROR"));
                    component.set("v.message",component.get("v.readyForDFPError"));
                    component.set("v.hideUserPrompt", true);
                    component.set("v.showToast",true);
                }
                    
            } else if(state === "ERROR") {
                console.log('==init error==>'+JSON.stringify(response.getReturnValue()) + JSON.stringify(response.getError()));
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    /*linkProposal : function (component, event, helper) {
        helper.linkProposal(component);
    },*/
})