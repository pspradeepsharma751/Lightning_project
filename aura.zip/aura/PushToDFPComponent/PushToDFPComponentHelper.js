({
    checkAssociatedAccount : function (component) {
        var accountId = component.get("v.simpleRecord.AccountId");
        var accountDoubleClickId = component.get("v.simpleRecord.adsalescloud__Ad_Server_Account_Id__c");
        
        if(accountId == undefined || accountId == null) {
            component.set("v.isAccountAssociated",false);
            //component.set("v.hideUserPrompt", true);
            component.set("v.showToast",true);
            component.set("v.message", $A.get("$Label.c.CONTACT_NOT_ASSOCIATED"));
            component.set("v.status",$A.get("$Label.c.ERROR"));
        } else if(accountDoubleClickId == undefined || accountDoubleClickId == null) {
            component.set("v.isAccountInDFP",false);
            component.set("v.isAccountAssociated",false);
            //component.set("v.hideUserPrompt", true);
            component.set("v.showToast",true);
            component.set("v.message", $A.get("$Label.c.CONTACT_RELATED_ACCOUNT_NOT_IN_DFP"));
            component.set("v.status",$A.get("$Label.c.ERROR"));
        }
    },
    
    synAccount:function (component) {
        component.set("v.loading",true);
        var action = component.get("c.syncAccount");
        action.setParams({
            recordId:component.get("v.recordId"),
            apiName:component.get("v.sObjectName")
        });
        
        action.setCallback(this,function (response) {
            component.set("v.loading",false);
            var state = response.getState();
            var objectName = component.get("v.sObjectName");
            var res = response.getReturnValue();
            console.log(res);
            if(state === "SUCCESS") {
                //component.set("v.message",res.message);
                //component.set("v.status",res.status=="OK"?$A.get("$Label.c.SUCCESS"): $A.get("$Label.c.ERROR"));
                var recid = component.get("v.recordId");
                if(res.status == "OK") {
                    var toastEvent = $A.get('e.force:showToast');
                    toastEvent.setParams({
                        'title': 'Success!',
                        'type': 'success',
                        'message': objectName + ' synced to Ad Server successfully.'
                    });
                    toastEvent.fire();
                    $A.get('e.force:refreshView').fire();
                    $A.get('e.force:closeQuickAction').fire();
                    /*window.setTimeout(
                        $A.getCallback(function() {
                            var navigateEvent = $A.get("e.force:navigateToSObject");
                            navigateEvent.setParams({
                                "recordId": recid,
                                "slideDevName": "detail"
                            });
                            navigateEvent.fire();
                        }), 1000
                    ); */
                } else if(res.status === "ERROR"){
                    component.set("v.message",res.message);
                    //component.set("v.linkProposal", true);
                    component.set("v.showToast",true);
                }
                    else if(res.status === 'AUTH_FAILED'){
                        if(confirm('User authentication failed while syncing with the Ad Server.\nPlease navigate to Ad Sales User Setup, authorize your Salesforce User with the Ad Server, and try again.')){
                            window.location.href ="/apex/AdSalesUserSetup";
                        }
                    }
                
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    component.set("v.showToast",true);
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.showToast",true);
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    /*linkProposal:function (component) {
        component.set("v.loading",true);
        component.set("v.showToast",true);
        var action = component.get("c.linkAccount");
        action.setParams({
            recordId:component.get("v.recordId"),
            apiName:component.get("v.sObjectName")
        });
        action.setCallback(this,function (response) {
            component.set("v.loading",false);
          	var state = response.getState();
            component.set("v.status",state=="SUCCESS"?this.redirectToRecord(component, event, component.get("v.recordId")): $A.get("$Label.c.ERROR"));
        });
        $A.enqueueAction(action);
    },*/
    
    redirectToRecord : function (component, event, recordId) {
        var navigateEvent = $A.get("e.force:navigateToSObject");
        navigateEvent.setParams({
            "recordId": recordId,
            "slideDevName": "detail"
        });
        navigateEvent.fire();
    }
})