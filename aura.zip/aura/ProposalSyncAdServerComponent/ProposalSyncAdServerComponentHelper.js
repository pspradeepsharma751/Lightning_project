({
    doInit : function (component) {
        var action = component.get("c.getReadyForDFPInformation");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                 var readyForDFPInfo = response.getReturnValue();
                component.set("v.readyForDFPInfo", readyForDFPInfo);
                if(readyForDFPInfo['isAccCreditStatusEnabled'] && readyForDFPInfo['accountCreditStatus'] != 'Active') {
                    component.set("v.showToast",true);
                    component.set("v.message",'The related account does not have an active credit status. Update the account\'s credit status to active to continue.');
                    component.set("v.status",$A.get("$Label.c.ERROR")); 
                } 
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
    
	checkProposalSync : function (component, event, helper) {
        var isMasterProposal = component.get("v.proposalRecordFields.adsalescloud__Primary_Proposal__c");
        var associatedAccoundDoubleClickId = component.get("v.proposalRecordFields.adsalescloud__Ad_Server_Account_Id__c");
        var isProgrammatic = component.get("v.proposalRecordFields.adsalescloud__isProgrammatic__c");
        //var readyForDFPInfo = component.get('v.readyForDFPInfo');
        component.set("v.sObjectName", "Proposal");
         if(isMasterProposal == undefined || isMasterProposal == null) {
            component.set("v.showToast",true);
            component.set("v.message", $A.get("$Label.c.ONLY_MASTER_PROPOSAL_SYNC_TO_AD_SERVER"));
            component.set("v.status",$A.get("$Label.c.ERROR"));
        } else if(associatedAccoundDoubleClickId == undefined || associatedAccoundDoubleClickId == null) {
            component.set("v.showToast",true);
            component.set("v.message",$A.get("$Label.c.RELATED_ACCOUNT_NOT_IN_AD_SERVER"));
            component.set("v.status",$A.get("$Label.c.ERROR"));
        }
        else if(component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Finalized") {
            component.set("v.showToast",true);
            component.set("v.message",'Sync to Ad Server requires the status field set to Finalized.');
            component.set("v.status",$A.get("$Label.c.ERROR")); 
        } 
        /*else if((component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Pre-Approved" && component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Pre-Approved (sold)") && isProgrammatic) {
            component.set("v.showToast",true);
            component.set("v.message",'Sync to Ad Server requires the status field set to Pre-Approved/Pre-Approved (sold).');
            component.set("v.status",$A.get("$Label.c.ERROR")); 
        } */
        
    },
})