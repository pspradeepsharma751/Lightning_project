({
    checkProposalSync : function (component, event, helper) {
        	helper.checkProposalSync(component);
    },
    
    doInit : function (component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 50rem;}.panel .closeIcon{display:none} .slds-modal__content{max-height: calc(100vh - 210px); overflow-y: auto;}</style>');
        component.set("v.readyForDFPError",$A.get("$Label.c.Not_Ready_for_Ad_Server"));
        helper.doInit(component);
    },
   
})