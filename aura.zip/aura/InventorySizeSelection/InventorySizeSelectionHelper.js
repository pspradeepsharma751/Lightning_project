({
  showModal: function(component, event) {
    component.set('v.showModal', true);
  },

  converObjToList: function(component, event) {
    var inventoryType = component.get('v.inventoryType');
    var available = component.get('v.availabelInventorySizesList');
    var availabelVideoSizesList = component.get('v.availabelVideoSizesList');
    var selectedList = [];

    if(inventoryType !== 'Standard') {
      var selected = component.get('v.selected');
      var idLabel;
      if(selected && selected.companions) {
        for(var index = 0; index < selected.companions.length; index++) {
          if(selected.companions[index].fullDisplayString) {
            idLabel = selected.companions[index].fullDisplayString;
            selectedList.push(idLabel);   
          }
        }
        component.set('v.selectedMasterValue', selected.fullDisplayString);
      } else if(selected && selected.fullDisplayString) {
        component.set('v.selectedMasterValue', selected.fullDisplayString);
      } else{
            if(inventoryType === 'Master/Companions Roadblock' && available[0]){
              		component.set('v.selectedMasterValue', available[0].label);
            } else if (inventoryType === 'Video VAST' && availabelVideoSizesList[0]) {
              		component.set('v.selectedMasterValue', availabelVideoSizesList[0].label);
          }
      }
    }
    else if(inventoryType === 'Standard') {
      var selectedSize = component.get('v.selectedInventory');
      if(selectedSize) {
        for(var index = 0; index < selectedSize.length; index++) {
          if(selectedSize[index].fullDisplayString) {
            idLabel = selectedSize[index].fullDisplayString;
            selectedList.push(idLabel);
          }
        }
      } else {
          component.set('v.selectedList', null);
      }
    }
    if(selectedList.length > 0) {
      component.set('v.selectedList', selectedList);
    }
      if(inventoryType === 'Standard'){
          component.set("v.availabelInventorySizesList2", available);
      }
      else{
          var availabelInventorySizesList2 = [];
          available.forEach(function(value){
              if(!(value.label.includes("Native") || value.label.includes("native"))){
                  availabelInventorySizesList2.push(value);
              }
          });
          component.set("v.availabelInventorySizesList2", availabelInventorySizesList2);
      }
  },

  selectionChange: function(component, event) {
    if(component.get('v.isGetSizes')) {
      var selectedList = component.get('v.selectedList');
      var masterVal = component.get('v.selectedMasterValue');
      var index = component.get('v.index');
      var compEvent = $A.get('e.c:InventorySizeEvent');
      compEvent.setParams({
        'selectedList': selectedList,
        'index': index,
        'masterVal': masterVal
      });

      compEvent.fire();
    }
  }
})