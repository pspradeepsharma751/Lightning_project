({
    showModal: function(component, event, helper) {
        helper.showModal(component, event);
    },
    
    converObjToList: function(component, event, helper) {
        helper.converObjToList(component, event);
    },
    selectionChange: function(component, event, helper) {
        helper.selectionChange(component, event);
    },
    changeMasterSize: function(component, event, helper) {
        var selectedMasterValue = event.getSource().get('v.value');
        component.set('v.selectedMasterValue', selectedMasterValue);
        component.set('v.isGetSizes', true);
        helper.selectionChange(component, event);
    }
});