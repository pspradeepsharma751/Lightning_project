({
  doInit: function(component, event, helper) {
    helper.getTargets(component);
  },
  loadMore: function(component, event, helper) {
    helper.getTargets(component);
  }
});