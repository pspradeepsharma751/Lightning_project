({
  getTargets: function(component) {
    var self = this;
    var page_size =component.get('v.page_size');
    var offset = component.get('v.offset');
    this.fetchData(component, 'getMobileApplicationTargets', {
      'offset': offset,
      'page_size': page_size
    }, function(res) {
      console.log(res);
      if(res.status === 'OK') {
        var targets = component.get('v.targets');
        component.set('v.targets', targets.concat(res.targets));
        var end_offset = component.get('v.end_offset');
        if(end_offset === 0) {
          end_offset = Math.ceil((parseInt(res.totalSize) / page_size));
          component.set('v.end_offset', end_offset);
        }
        if(offset < end_offset)
          component.set('v.offset', ++offset);
      }
      else
        component.set('v.error', res.msg);
      component.set('v.showSpinner', false);
    });
  }
});