({
    afterScriptsLoaded: function(component,event,helper){
        var events = [
                        {
                            title  : '525a United States',
                            start  : '2018-07-06',
                            url    : '/a0I1I0000040StSUAU',
                            color  : 'red'
                        },
                        {
                            title  : 'event2',
                            start  : '2018-07-06',
                            end    : '2018-07-18'
                        },
                        {
                            title  : 'event3',
                            start  : '2018-07-09T12:30:00',
                            allDay : false // will make the time show
                        }
                    ];
        component.set("v.events", events);
        console.log(events);
        if(!events.length)
        {
            // helper.fetchEvents(cmp);
        }
        $('#calendar').fullCalendar({
            events: events,
            eventClick: function(event) {
                if (event.url) {
                    window.open(event.url);
                    return false;
                }
            }
        });
    },
    test : function(component, event, helper){
        var  events = [
                            {
                                title  : '525a United States',
                                start  : '2018-07-06',
                                url    : '/a0I1I0000040StSUAU',
                                color  : 'red'
                            }
                        ];
        component.set("v.events", events);
        $('#calendar').fullCalendar( 'removeEvents');
        $('#calendar').fullCalendar( 'addEventSource', events);
        $('#calendar').fullCalendar( 'rerenderEvents' );
    },
    
})