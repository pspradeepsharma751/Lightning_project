({
  handleRecordUpdated: function(component, event, helper) {
      helper.initializeUtilsHelper(component);
    var result = Object.assign({},component.get('v.recordFields'));

    if(result.adsalescloud__Line_Item_Type__c === 'Price Priority' && result.adsalescloud__Limit_Type__c === 'Daily') {
      var startDate = result.adsalescloud__Start_Date__c;
      var endDate = result.adsalescloud__End_Date__c;
      if(startDate && endDate) {
        var d1 =  helper.getDateObjectInSpecificTimezone(startDate, result.adsalescloud__Time_Zone__c); d1.setHours(0);
      var d2 = helper.getDateObjectInSpecificTimezone(endDate, result.adsalescloud__Time_Zone__c); d2.setHours(23);
        component.set('v.errorMessage', '');
        if(d2.getTime() > d1.getTime()) {
          var days= Math.ceil((d2 - d1)  / (1000 * 60 * 60 * 24));
          result.adsalescloud__Net_Cost__c = result.adsalescloud__Net_Rate__c * result.adsalescloud__Quantity__c * days;
          result.adsalescloud__Gross_Cost__c = result.adsalescloud__Gross_Rate__c * result.adsalescloud__Quantity__c * days;
        }
      }
    }else{
      result.adsalescloud__Net_Cost__c = result.adsalescloud__Net_Rate__c * result.adsalescloud__Quantity__c;
      result.adsalescloud__Gross_Cost__c = result.adsalescloud__Gross_Rate__c * result.adsalescloud__Quantity__c;
    }

    if(result.adsalescloud__Rate_Type__c.includes('CPM')){
      result.adsalescloud__List_Price__c *= 1000;
      result.adsalescloud__Listing_Rate__c *= 1000;
      result.adsalescloud__Net_Rate__c *= 1000;
      result.adsalescloud__Gross_Rate__c *= 1000;
      result.adsalescloud__Product_Adjustment__c = (result.adsalescloud__Product_Adjustment__c / 100 || 0)	;
    }
    component.set('v.result',result);
  }
});