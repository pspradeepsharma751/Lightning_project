({
    doInit: function(component) {
        var action = component.get("c.getPLIRecord");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                if(!$A.util.isEmpty(response.getReturnValue())){
                    var record = JSON.parse(response.getReturnValue());
                    component.set('v.proposalLineItemRecord', record);
                }
            }
            else if(state === 'ERROR') {
                var errorMessage = response.getError()[0].message;
            }
        });
        $A.enqueueAction(action);
    },
    
    validatePLIRecord: function(component){
        var proposalStatus = component.get('v.proposalLineItemRecord.adsalescloud__Proposal_Status__c');
        if(!$A.util.isEmpty(proposalStatus) && (proposalStatus != 'Draft' || proposalStatus === 'Draft (sold)')){
            component.set("v.toast", {"message": "Proposal Line Items can only be cloned for Proposals with status of Draft or Draft (sold).", "type" : "error", "closable" : true, "autoHide" : false});
            component.set("v.hasErrors", true);
        }
        else
            component.set("v.hasErrors", false);
    }
})