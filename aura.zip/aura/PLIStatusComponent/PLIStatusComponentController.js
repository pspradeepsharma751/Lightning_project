({
    doInit: function(component, event, helper) {
        helper.doInit(component);
    },
	changeQuantity : function (component, event, helper) {
        helper.changeQuantity(component);
    },
    
    closeModal : function (component) {
        $A.get("e.force:closeQuickAction").fire();
    },
})