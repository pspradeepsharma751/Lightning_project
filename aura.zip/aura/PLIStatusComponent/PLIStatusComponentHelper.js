({
    doInit: function(component) {
        var action = component.get("c.getPLIProposalRecord");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                var record = JSON.parse(response.getReturnValue());
                component.set('v.record', record.pliRecord);
                component.set('v.proposalRecord', record.proposalRecord.adsalescloud__Proposal__r.adsalescloud__Status__c);
            }
            else if(state === 'ERROR') {
              var errorMessage = response.getError()[0].message;
            }
      });
      $A.enqueueAction(action);
    },
    
    changeQuantity:function (component) {
        component.set("v.loading",true);
        component.set("v.showToast",true);
        var record = component.get("v.record");
        record['adsalescloud__Quantity__c'] =  Math.ceil(parseInt(record['adsalescloud__Impressions_Delivered__c']) / (1 + parseInt(record['adsalescloud__Buffer__c'])));
        record['adsalescloud__End_Date__c'] = new Date();
        var action = component.get("c.upsertRecord");
        action.setParams({
            sObjectRecord: JSON.stringify(record)
        });
        
        action.setCallback(this,function (response) {
            component.set("v.loading",false);
            var state = response.getState();
            if(state === "SUCCESS") {
                var recid = component.get("v.recordId");
                window.location.href = "/"+recid;
                
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
})