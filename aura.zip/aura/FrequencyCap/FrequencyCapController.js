({
  doInit: function(component, event, helper) {
    helper.doInit(component, event);
  },
  onChange: function(component, event, helper) {
    helper.updateRecord(component, event);
  },
  removeAtrribute: function(component, event, helper) {
    helper.removeAtrribute(component, event);
  },
  addRow: function(component, event, helper) {
    helper.addRow(component, event);
  },
    handleChange : function(component, event, helper) {
        if($A.util.isEmpty(component.get("v.selectedFrequencyCaps"))){
            component.set("v.isVisible", false);
        }
  },
})