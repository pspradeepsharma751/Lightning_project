({
    doInit: function(component, event) {
        var frequencyValue = component.get('v.record.adsalescloud__Frequency_Caps_per_User_Details__c');
        if(frequencyValue) {
            frequencyValue = JSON.parse(frequencyValue.replace(/&quot;/g, '\"'));  
            component.set('v.isVisible', true);  
        } else {
            frequencyValue=[{"numTimeUnits":1,"maxImpressions":1,"timeUnit":"MINUTE"}];
        }    
            component.set('v.selectedFrequencyCaps', frequencyValue);
    },
    updateRecord: function(component, event) {
        this.checkValidation(component, event);
        if(component.get('v.isValid')) {
            var selectedFrequencyCaps = component.get('v.selectedFrequencyCaps');
            component.set('v.record.adsalescloud__Frequency_Caps_per_User_Details__c', selectedFrequencyCaps.length>0?JSON.stringify(selectedFrequencyCaps):' ');
            var updateRecordEvent = $A.get('e.c:ProductTemplateRecordUpdateEvent');
            updateRecordEvent.fire();
        }
    },
  checkValidation: function(component, event) {
    var selectedFrequecyCap = component.get('v.selectedFrequencyCaps');
    var errorMessage = '';
    var isValid = true;

    for(var row = 0; row < selectedFrequecyCap.length; row++) {
      for(var col = 0; col < selectedFrequecyCap.length; col++) {
        if(row === col) {
          break;
        }
        if(selectedFrequecyCap[row].timeUnit == selectedFrequecyCap[col].timeUnit) {
          errorMessage = 'Duplicate time range found in frequency cap.';
          isValid = false;
          break;
        }
      }

      if(!selectedFrequecyCap[row].numTimeUnits) {
        isValid = false;
        errorMessage = 'Please enter a range of time in frequency cap.';
        break;
      } else if(!selectedFrequecyCap[row].maxImpressions) {
        isValid = false;
        errorMessage = '0 impressions are not allowed in frequency cap.';
        break;
      }
    }
    component.set('v.frequencyCapErrorMessage', errorMessage)
    component.set('v.isValid', isValid);
  },
  removeAtrribute: function(component, event) {
    var index = event.getSource().get('v.name');
    var selectedFrequecyCap = component.get('v.selectedFrequencyCaps');
    selectedFrequecyCap.splice(index, 1);
    component.set('v.selectedFrequencyCaps', selectedFrequecyCap);
    this.updateRecord(component, event);
  },
  addRow: function(component, event) {
    var selectedFrequecyCap = component.get('v.selectedFrequencyCaps');
    var frequentObj = {};

    frequentObj['numTimeUnits'] = 1;
    frequentObj['maxImpressions'] = 1;
    frequentObj['timeUnit'] = 'MINUTE';
    
    selectedFrequecyCap.push(frequentObj);
    component.set('v.selectedFrequencyCaps', selectedFrequecyCap);
    this.updateRecord(component, event);
  }
})