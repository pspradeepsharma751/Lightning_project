({
    doInit: function(component, event, helper) {
       component.set("v.filteredInventorySizes", component.get("v.options"));
    },
  handleChange: function(component, event, helper) {
    // var selectedOptionValue = event.getParam('value');
  },
  hideModalHandler: function(component){
    component.set('v.showModal',false);
  },
    filterOptions : function(component, event, helper) {
        component.set("v.timestamp", new Date().getTime());
        setTimeout(function(){
            if(new Date().getTime() - component.get("v.timestamp") > 499)
                helper.filterOptions(component);
        }, 500);
    }
});