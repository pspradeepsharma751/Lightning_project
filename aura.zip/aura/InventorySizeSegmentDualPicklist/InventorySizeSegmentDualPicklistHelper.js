({
  filterOptions : function(component) {
        var allOptions = component.get("v.options");
        var selecetedOptions = component.get("v.selectedOptions");
        var filterKeyword = component.get("v.filterKeyword");
        var filteredOptions = [];
        if($A.util.isEmpty(filterKeyword)){
            filteredOptions = allOptions;
        }
        else{
            allOptions.forEach(function(value){
                if(value.label.includes(filterKeyword) || selecetedOptions.includes(value.label)){
                    filteredOptions.push(value);
                }
            });
        }
        component.set("v.filteredInventorySizes", filteredOptions);
    }
});