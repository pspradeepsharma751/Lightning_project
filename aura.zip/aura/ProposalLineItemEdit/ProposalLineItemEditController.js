({
  doInit: function(component, event, helper) {
    component.set('v.cval', '<style>.slds-modal__container{min-width: 60rem;}.panel .closeIcon{display:none}</style>');
    helper.initializeUtilsHelper(component);
    helper.doInit(component);
    helper.createTimezoneSelectComponent(component);
    helper.getPriorityRatingValue(component);
  },

  updateLineItemPriority: function(component, event, helper) {
    if(component.get('v.record.adsalescloud__Line_Item_Priority__c') !== component.get('v.lineItemPriorityInitialeValue')) {
      helper.updateLineItemPriority(component);
    }
  },

  onSave: function(component, event, helper) {
    var errorMessage = component.get('v.frequencyCapErrorMessage');
    var errorMiscMessage = component.get('v.errorMessage');
    var inventorySizeError = component.get('v.InventorySizeErrorMessage');
    var objectData = component.get('v.record');
    var timezone = $A.get('$Locale.timezone');
    var currentDate = new Date().getTime();//.toLocaleString('en-US', {timeZone: timezone});
    var startDate = Date.parse(new Date(objectData.adsalescloud__Start_Date__c).toLocaleString('en-US', {timeZone: timezone}));
    var endDate = Date.parse(new Date(objectData.adsalescloud__End_Date__c).toLocaleString('en-US', {timeZone: timezone}));

    if(!$A.util.isEmpty(errorMessage)) {
      helper.onError(component, errorMessage);
    }
    else if(!$A.util.isEmpty(errorMiscMessage)) {
      helper.onError(component, errorMiscMessage);
    }
    else if(!$A.util.isEmpty(inventorySizeError)) {
      helper.onError(component, inventorySizeError);
    }
    else if(!objectData.adsalescloud__Proposal__c) {
      var proposalReqError = 'Please select the Proposal for this Line Item.';
      helper.onError(component, proposalReqError);
    }
    else if(!objectData.adsalescloud__Product__c) {
      var productReqError = 'Please select the Product for this Line Item.';
      helper.onError(component, productReqError);
    }
    else if(parseInt(component.get('v.PLIRevenueEntry.netRate')) < 0) {
      helper.onError(component, 'Net rate must be greater than or equal to 0');
    }
    else if((parseInt(component.get('v.PLIRevenueEntry.quantity')) < 1) &&
      (objectData.adsalescloud__Limit_Type__c && objectData.adsalescloud__Line_Item_Type__c != 'Price Priority')) {
      helper.onError(component, 'Quantity must be greater than 0');
    }
    else if(!objectData.adsalescloud__Unlimited_End_Date_Time__c) {
      if(endDate < startDate) {
        helper.onError(component, 'End Date must be greater than Start Date.');
      } else if(!objectData.adsalescloud__Ad_Server_Id__c && (startDate < currentDate || endDate < currentDate)) {
        helper.onError(component, 'Start Date or End Date cannot be in the past.');
      } else {
        helper.onSave(component, helper);
      }
    }
    else {
      helper.onSave(component, helper);
    }
  },
  onCancel: function(component, event, helper) {
    if(component.get('v.isPLISync')) {
      component.set('v.isPliRecordUpdated', true);
    } else {
      helper.redirect(component);
    }
  },
  netRateChangeHandler: function(component, event, helper) {
    var item = component.get('v.PLIRevenueEntry');
    item.grossRate = item.netRate / (1 - item.agencyCommission);
    item.productRateAdjustment = (item.netRate * (1 / (1 - item.proposalDiscount))) - ((item.listPrice + item.premiumRate) - item.advertiserRateDiscount);
    item.productAdjustment = item.productRateAdjustment / ((item.listPrice + item.premiumRate) * (1 - item.advertiserDiscount));
    item.proposalRateDiscount = ((item.listPrice + item.premiumRate) - item.advertiserRateDiscount + item.productRateAdjustment) * (item.proposalDiscount);
    helper.quantityChangeHandler(component, item);
  },
  netCostChangeHandler: function(component) {
    var item = component.get('v.PLIRevenueEntry');
    item.netRate = item.netCost / item.quantity;
    item.grossRate = item.netRate / (1 - item.agencyCommission);
    item.productRateAdjustment = (item.netRate * (1 / (1 - item.proposalDiscount))) - ((item.listPrice + item.premiumRate) - item.advertiserRateDiscount);
    item.productAdjustment = item.productRateAdjustment / ((item.listPrice + item.premiumRate) * (1 - item.advertiserDiscount));
    item.proposalRateDiscount = ((item.listPrice + item.premiumRate) - item.advertiserRateDiscount + item.productRateAdjustment) * (item.proposalDiscount);
    item.grossCost = item.grossRate * item.quantity;
    if(item.rateType.includes('CPM')) {
      item.netRate = item.netRate * 1000;
      // Net Cost = net rate / 1000 * quantity
      item.grossCost = item.grossCost / 1000;
    }
    component.set('v.PLIRevenueEntry', item);

  },
  grossRateChangeHandler: function(component, event, helper) {
    var item = component.get('v.PLIRevenueEntry');
    item.netRate = item.grossRate * (1 - item.agencyCommission);
    item.productRateAdjustment = (item.netRate * (1 / (1 - item.proposalDiscount))) - ((item.listPrice + item.premiumRate) - item.advertiserRateDiscount);
    item.productAdjustment = item.productRateAdjustment / ((item.listPrice + item.premiumRate) * (1 - item.advertiserDiscount));
    item.proposalRateDiscount = ((item.listPrice + item.premiumRate) - item.advertiserRateDiscount + item.productRateAdjustment) * (item.proposalDiscount);
    helper.quantityChangeHandler(component, item);
  },
  grossCostChangeHandler: function(component) {
    var item = component.get('v.PLIRevenueEntry');
    item.grossRate = item.grossCost / item.quantity;
    item.netRate = item.grossRate * (1 - item.agencyCommission);
    item.productRateAdjustment = (item.netRate * (1 / (1 - item.proposalDiscount))) - ((item.listPrice + item.premiumRate) - item.advertiserRateDiscount);
    item.productAdjustment = item.productRateAdjustment / ((item.listPrice + item.premiumRate) * (1 - item.advertiserDiscount));
    item.proposalRateDiscount = ((item.listPrice + item.premiumRate) - item.advertiserRateDiscount + item.productRateAdjustment) * (item.proposalDiscount);
    item.netCost = item.netRate * item.quantity;
    if(item.rateType.includes('CPM')) {
      item.netRate = item.netRate * 1000;
      item.netCost = item.netCost / 1000;
      item.grossCost = item.grossCost / 1000;
    }
    component.set('v.PLIRevenueEntry', item);
  },
  quantityChangeHandler: function(component, event, helper) {
    helper.quantityChangeHandler(component, null);
  },
  bufferChangeHandler: function(component) {
    var item = component.get('v.PLIRevenueEntry');
    if(item.lineItemType === 'Standard' || item.lineItemType === 'Preferred Deal') {
      item.scheduledQuantity = item.quantity * (1 + item.buffer / 100);
    }
    component.set('v.PLIRevenueEntry', item);
  },
  productAdjustmentChangeHandler: function(component, event, helper) {
    var item = component.get('v.PLIRevenueEntry');
    item.productRateAdjustment = (item.listRate - item.advertiserRateDiscount) * item.productAdjustment;
    item.proposalRateDiscount = (item.listRate - item.advertiserRateDiscount + item.productRateAdjustment) * item.proposalDiscount;
    item.netRate = item.listPrice + item.premiumRate - (item.advertiserRateDiscount + item.proposalRateDiscount) + item.productRateAdjustment;
    item.grossRate = item.netRate / (1 - item.agencyCommission);
    helper.quantityChangeHandler(component, item);
  },
  listRateChangeHandler: function(component, event, helper) {
    var item = component.get('v.PLIRevenueEntry');
    if(!item) {return;}
    var listRate = component.get('v.record.adsalescloud__Listing_Rate__c');
    item.productRateAdjustment = (listRate - item.advertiserRateDiscount) * item.productAdjustment;
    item.proposalRateDiscount = (listRate - item.advertiserRateDiscount + item.productRateAdjustment) * item.proposalDiscount;
    item.netRate = listRate - (item.advertiserRateDiscount + item.proposalRateDiscount) + item.productRateAdjustment;
    item.grossRate = item.netRate / (1 - item.agencyCommission);
    item.listRate = listRate;
    helper.quantityChangeHandler(component, item);
  },
  getSelectedProductRecord: function(component, event, helper) {
    helper.getSelectedProductRecord(component);
  },
  getSelectedProposalRecord: function(component, event, helper) {
    helper.getSelectedProposalRecord(component);
  },
  mapBilligFieldstoProposal: function(component, event, helper) {
    helper.mapBilligFieldstoProposal(component);
  },
  limitTypeChangeHandler: function(component, event, helper) {
    helper.quantityChangeHandler(component, null);
  },
  dateChangeHandler: function(component, event, helper) {
    helper.updateTimezoneOffsetMinutes(component);
    helper.dateChangeHandler(component);
  },
  navigateToRecord: function(component, event, helper) {
    window.open(component.get('v.record.adsalescloud__Ad_Server_Line_Item__c').split('"')[1]);
  },
  updateCostValue: function(component, event, helper) {
    var costAdjustValue = event.getSource().get('v.value');
    var objectData = component.get('v.record');
    if(costAdjustValue === '---None---') {
      component.set('v.PLIRevenueEntry.netCost', objectData.adsalescloud__Quantity__c * objectData.adsalescloud__Net_Rate__c);
      component.set('v.PLIRevenueEntry.grossCost', objectData.adsalescloud__Quantity__c * objectData.adsalescloud__Gross_Rate__c);
    } else {
      component.set('v.PLIRevenueEntry.netCost', 0);
      component.set('v.PLIRevenueEntry.grossCost', 0);
    }
  },
  refreshDateTimeComponents: function(component, event, helper) {
    component.set('v.refreshDateTimeComponents', true);
    component.set('v.refreshDateTimeComponents', false);
  },

  toggleEndDateDisplay: function(component, event, helper) {
    if(component.get('v.record.adsalescloud__Unlimited_End_Date_Time__c')) {
      component.set('v.displayEndDateField', false);
    } else {
      component.set('v.displayEndDateField', true);
    }
    helper.quantityChangeHandler(component, null);
  },

  onCheckAvailability: function(component, event, helper) {
    var objectData = JSON.parse(JSON.stringify(component.get('v.record')));
    var endDateTime = helper.getDateObjectInSpecificTimezone(objectData.adsalescloud__End_Date__c, objectData.adsalescloud__Time_Zone__c);
    var currentTime = new Date();
    if(endDateTime < currentTime) {
      component.set("v.messageType", "error");
      component.set("v.message", "End Date must be in the future to Check Availability");
      component.set('v.showModal', false);
    }
    else
      component.set('v.showModal', true);
  },


});