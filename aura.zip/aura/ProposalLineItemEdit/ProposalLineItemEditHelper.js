({
  checkboxDetailFields: {
    'allowGeoTargetingCustomization': true,
    'allowAdUnitTargetingCustomization': true,
    'allowPlacementTargetingCustomization': true,
    'allowUserDomainTargetingCustomization': true,
    'allowBandwidthGroupTargetingCustomization': true,
    'allowBrowserTargetingCustomization': true,
    'allowBrowserLanguageTargetingCustomization': true,
    'allowOperatingSystemTargetingCustomization': true,
    'allowDeviceCapabilityTargetingCustomization': true,
    'allowDeviceCategoryTargetingCustomization': true,
    'allowMobileApplicationTargetingCustomization': true,
    'allowMobileCarrierTargetingCustomization': true,
    'allowMobileDeviceAndManufacturerTargetingCustomization': true,
    'allowAudienceSegmentTargetingCustomization': true,
    'isAllCustomTargetingKeysCustomizable': true,
    'allowDaypartTargetingCustomization': true,
    'allowFrequencyCapsCustomization': true,
    'allowDeliverySettingsCustomization': true,
    'allowCreativePlaceholdersCustomization': true
  },
  doInit: function(component) {
    var actionToFetchPackageFields = component.get('c.getProposalLineItemRecord');
    actionToFetchPackageFields.setParams({
      'recordId': component.get('v.recordId') ? component.get('v.recordId') : null
    });
    actionToFetchPackageFields.setCallback(this,
      function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
          var result = JSON.parse(response.getReturnValue());
          component.set('v.selectedProposalRecord', result.adsalescloud__Proposal__r);
          if(component.get('v.cloneRecord')) {
            result.Name = 'Copy of ' + result.Name;
            result.adsalescloud__Ad_Server_Id__c = null;
          }
          if(result.adsalescloud__Rate_Type__c.includes('CPM')) {
            result.adsalescloud__List_Price__c *= 1000;
            result.adsalescloud__Net_Rate__c *= 1000;
          }
          // validation for StartDate field, if in past make readonly
          if(result.adsalescloud__Ad_Server_Line_Item__c && (Date.parse(result.adsalescloud__Start_Date__c) < Date.now())) {
            component.set('v.isStartInPast', true);
          }

          if(result.adsalescloud__Line_Item_Type__c === 'Sponsorship' ||
            result.adsalescloud__Line_Item_Type__c === 'Network' ||
            result.adsalescloud__Line_Item_Type__c === 'Price Priority' ||
            result.adsalescloud__Line_Item_Type__c === 'House' ||
            result.adsalescloud__Line_Item_Type__c === 'Click Tracking Only') {

            component.set('v.displayUnlmtdEndDate', true);
          }
          if(result.adsalescloud__Unlimited_End_Date_Time__c) {
            component.set('v.displayEndDateField', false);
          }
          component.set('v.lineItemPriorityInitialeValue', result.adsalescloud__Line_Item_Priority__c);
          component.set('v.record', result);
          this.updateTimezoneOffsetMinutes(component);
          this.getObjKeyPrefix(component);
          this.createPLIRevenueEntry(component);
          this.setBillingData(component);
          this.setCheckAvailButtonVisibility(component);
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
        }
      }
    );
    $A.enqueueAction(actionToFetchPackageFields);
  },
  updateTimezoneOffsetMinutes: function(component) {
    var timezoneOffset = {
      startDate: this.getTimezoneOffset(component.get('v.record.adsalescloud__Start_Date__c'), component.get('v.record.adsalescloud__Time_Zone__c')),
      endDate: this.getTimezoneOffset(component.get('v.record.adsalescloud__End_Date__c'), component.get('v.record.adsalescloud__Time_Zone__c'))
    };
    component.set('v.timezoneOffsetMinutes', timezoneOffset);
  },
  dateChangeHandler: function(component) {
    var item = component.get('v.PLIRevenueEntry');
    var record = component.get('v.record');
    var startDate = record.adsalescloud__Start_Date__c;
    var endDate = record.adsalescloud__End_Date__c;
    var days = 0;

    if(startDate && endDate) {
      var d1 = this.getDateObjectInSpecificTimezone(startDate, record.adsalescloud__Time_Zone__c); d1.setHours(0);
      var d2 = this.getDateObjectInSpecificTimezone(endDate, record.adsalescloud__Time_Zone__c); d2.setHours(23);
      component.set('v.errorMessage', '');
      if(d2.getTime() > d1.getTime()) {
        /*var start = d1.toTimeString();
        d1.setHours(0); d1.setMinutes(0);
        var startTime = start.substring(0, start.indexOf(' '));
        var startTimeThreshold = '23:59:00';
        var end = d2.toTimeString();
        d2.setHours(0); d2.setMinutes(0);
        var endTime = end.substring(0, end.indexOf(' '));
        var endTimeThreshold = '00:01:00';

        var startDateAdjust = (startTime < startTimeThreshold) ? 1 : 0;
        var endDateAdjust = (endTime > endTimeThreshold) ? 0 : -1;

        days = (Math.ceil((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24)) + startDateAdjust + endDateAdjust);*/
        days = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
      } else {
        component.set('v.errorMessage', 'Start Date cannot be greater than End Date!');
        return;
      }
    }
    if(item.lineItemType === 'Price Priority' && item.limitType === 'Daily') {
      item.grossCost = item.grossRate * item.quantity * days;
      item.netCost = item.netRate * item.quantity * days;
    }
    else if(item.rateType === 'CPD') {
      item.quantity = days;
      item.grossCost = item.grossRate * item.quantity;
      item.netCost = item.netRate * item.quantity;
      if(item.lineItemType === 'Standard') {
        item.scheduledQuantity = item.quantity * (1 + record.adsalescloud__Buffer__c / 100);
        item.scheduleQtyDisable = false;
      }
    }
    component.set('v.PLIRevenueEntry', item);
  },
  onSave: function(component) {
    this.updateRecordWithPLIRevenueEntry(component);
    var objectData = component.get('v.record');
    var selectedProposalRecord = component.get('v.selectedProposalRecord');
    //objectData['adsalescloud__Pricebook_Entry__c'] = selectedProposalRecord.adsalescloud__Opportunity__r.Pricebook2Id;
    if(component.get('v.cloneRecord')) {
      objectData.Id = null;
    }
    if(objectData.adsalescloud__Cost_Adjustment__c === '---None---') {
      objectData.adsalescloud__Cost_Adjustment__c = null;
    }
    if(objectData.Billing_Source__c === '---None--') {
      objectData.adsalescloud__Caps_and_Rollovers__c = null;
      objectData.adsalescloud__Billing_Schedule__c = null;
    }
    else if(objectData.adsalescloud__Billing_Source__c === 'Contracted' ||
      objectData.adsalescloud__Billing_Source__c === 'Contracted Flat fee') {
      objectData.adsalescloud__Caps_and_Rollovers__c = null;
    }
    else {
      objectData.adsalescloud__Billing_Schedule__c = null;
    }
    // set Delivery fields value
    if(objectData.adsalescloud__Deliver_Impressions__c === '---None--') {objectData.adsalescloud__Deliver_Impressions__c = null;}
    if(objectData.adsalescloud__Display_Creatives__c === '---None--') {objectData.adsalescloud__Display_Creatives__c = null;}
    if(objectData.adsalescloud__Rotate_Creatives__c === '---None--') {objectData.adsalescloud__Rotate_Creatives__c = null;}
    if(objectData.adsalescloud__Limit_Type__c === 'None') {objectData.adsalescloud__Limit_Type__c = null;}
    if(!objectData.adsalescloud__Limit_Type__c &&
      (objectData.adsalescloud__Line_Item_Type__c === 'Price Priority' || objectData.adsalescloud__Line_Item_Type__c === 'Click Tracking Only')) {
      objectData.adsalescloud__Limit_Quantity__c = null;
      objectData.adsalescloud__Quantity__c = null;
      //delete objectData['adsalescloud__Quantity__c'];
    }
    if(objectData.adsalescloud__Line_Item_Type__c === 'Click Tracking Only' || objectData.adsalescloud__Line_Item_Type__c === 'Preferred Deal') {
      objectData.adsalescloud__Deliver_Impressions__c = null;
      objectData.adsalescloud__Display_Creatives__c = null;
    }

    if(objectData.adsalescloud__Line_Item_Type__c === 'Preferred Deal') {
      objectData.adsalescloud__Rotate_Creatives__c = null;
      objectData.adsalescloud__Frequency_Caps_per_User_Details__c = null;
    }

    /* if(objectData.adsalescloud__Line_Item_Type__c != 'Preferred Deal'){
         objectData.adsalescloud__Ad_Exchange_Environment__c = null;
     } */

    if(!selectedProposalRecord.adsalescloud__isProgrammatic__c &&
      (objectData.adsalescloud__Line_Item_Type__c != 'Preferred Deal' &&
        objectData.adsalescloud__Line_Item_Type__c != 'Preferred Deal')) {
      objectData.adsalescloud__Programmatic_Creative_Source__c = null;
    }

    if(objectData.adsalescloud__Unlimited_End_Date_Time__c) {
      objectData.adsalescloud__Rotate_Creatives__c = null;
      objectData.adsalescloud__End_Date_Time__c = null;
    }
    var action = component.get('c.upsertRecord');
    var errorMessage = '';
    action.setParams({
      'sObjectRecord': JSON.stringify(objectData)
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if(state === 'SUCCESS') {
        if(component.get('v.isLightning') && !component.get('v.cloneRecord')) {
          $A.get('e.force:refreshView').fire();
          $A.get('e.force:closeQuickAction').fire();
        } else if(component.get('v.isProposalPliEdit')) {
          document.location.href = '/' + component.get('v.recordId');
        }
        else {
          document.location.href = '/' + response.getReturnValue();
        }
      }
      else {
        if(response.getState() === 'INCOMPLETE') {
          errorMessage = 'Server could not be reached. Check your internet connection.';
        } else if(response.getState() === 'ERROR') {
          var errors = response.getError();
          if(errors) {
            for(var i = 0; i < errors.length; i++) {
              for(var j = 0; errors[i].pageErrors && j < errors[i].pageErrors.length; j++) {
                errorMessage += (errorMessage.length > 0 ? '\n' : '') + errors[i].pageErrors[j].message;
              }
              if(errors[i].fieldErrors) {
                for(var fieldError in errors[i].fieldErrors) {
                  var thisFieldError = errors[i].fieldErrors[fieldError];
                  for(var j = 0; j < thisFieldError.length; j++) {
                    errorMessage += (errorMessage.length > 0 ? '\n' : '') + thisFieldError[j].message;
                  }
                }
              }
              if(errors[i].errorMessage) {
                errorMessage += (errorMessage.length > 0 ? '\n' : '') + errors[i].message;
              }
            }
          } else {
            errorMessage += (errorMessage.length > 0 ? '\n' : '') + 'Unknown error';
          }
        }
        this.showToast(component, 'Error', errorMessage, 'error');
      }
    });
    $A.enqueueAction(action);
  },
  createTimezoneSelectComponent: function(component) {
    var action = component.get('c.fetchPicklistValues');
    action.setParams({
      'pickListFieldName': component.get('v.timeZoneAPIName')

    });
    action.setCallback(this,
      function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
          // create a empty array var for store dependent picklist values for controller field)
          var dependentFields = [];
          /*dependentFields.push({
            class: 'optionClass',
            label: '--- None ---',
            value: '--- None ---'
          });*/
          var listPicklistValues = response.getReturnValue();
          for(var i = 0; i < listPicklistValues.length; i++) {
            dependentFields.push({
              class: 'optionClass',
              label: listPicklistValues[i].label,
              value: listPicklistValues[i].value,
              selected: component.get('v.record').adsalescloud__Time_Zone__c !== undefined && listPicklistValues[i] === component.get('v.record').adsalescloud__Time_Zone__c
            });
          }
          component.set('v.options', dependentFields);
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
          component.set('v.errorMessage', errorMessage);
        }
      }
    );
    $A.enqueueAction(action);
  },
  onError: function(component, errorMessage) {
    this.showToast(component, 'Error', errorMessage, 'error');
  },
  showToast: function(component, title, message, type) {
    component.set('v.toastTitle', title);
    component.set('v.message', message);
    component.set('v.messageType', type);
    component.set('v.showToast', true);
  },
  createPLIRevenueEntry: function(component) {
    var pli = component.get('v.record');
    var objPLIRevenueEntry = {};
    if(pli.adsalescloud__Rate_Type__c === 'Flat Fee') {
      objPLIRevenueEntry.quantity = 1;
      objPLIRevenueEntry.quantityDisable = true;
    } else if(pli.adsalescloud__Rate_Type__c === 'CPD') {
      var d1 = this.getDateObjectInSpecificTimezone(pli.adsalescloud__Start_Date__c, pli.adsalescloud__Time_Zone__c); d1.setHours(0);
      var d2 = this.getDateObjectInSpecificTimezone(pli.adsalescloud__End_Date__c, pli.adsalescloud__Time_Zone__c); d2.setHours(23);
      var days = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
      objPLIRevenueEntry.quantity = days;
      objPLIRevenueEntry.quantityDisable = true;
    } else {
      objPLIRevenueEntry.quantity = pli.adsalescloud__Quantity__c;
      objPLIRevenueEntry.quantityDisable = false;
    }

    if((pli.adsalescloud__Line_Item_Type__c === 'Standard' &&
      pli.adsalescloud__Rate_Type__c === 'Viewable CPM') ||
      pli.adsalescloud__Line_Item_Type__c === 'Price Priority') {
      component.set('v.limiTypes', ['None', 'Lifetime', 'Daily']);
      objPLIRevenueEntry.limitTypeDisable = false;
    }
    else if(pli.adsalescloud__Line_Item_Type__c === 'Click Tracking Only') {
      component.set('v.limiTypes', ['None', 'Lifetime']);
      objPLIRevenueEntry.limitTypeDisable = false;
    } else {
      objPLIRevenueEntry.limitTypeDisable = true;
    }

    if(pli.adsalescloud__Line_Item_Type__c === 'Standard' || pli.adsalescloud__Line_Item_Type__c === 'Preferred Deal') {
      objPLIRevenueEntry.scheduledQuantity = objPLIRevenueEntry.quantity * (1 + pli.adsalescloud__Buffer__c / 100);
      objPLIRevenueEntry.scheduleQtyDisable = true;
    } else {
      objPLIRevenueEntry.scheduledQuantity = pli.adsalescloud__Scheduled_Quantity__c;
      objPLIRevenueEntry.scheduleQtyDisable = false;
    }
    if(pli.adsalescloud__Line_Item_Type__c === 'Standard' &&
      pli.adsalescloud__Rate_Type__c === 'Viewable CPM' && pli.adsalescloud__Limit_Type__c !== 'None') {
      objPLIRevenueEntry.limitQtyShow = true;
    } else {
      objPLIRevenueEntry.limitQtyShow = false;
    }

    objPLIRevenueEntry.limitType = pli.adsalescloud__Limit_Type__c;
    objPLIRevenueEntry.rateType = pli.adsalescloud__Rate_Type__c;
    objPLIRevenueEntry.buffer = pli.adsalescloud__Buffer__c;
    objPLIRevenueEntry.lineItemType = pli.adsalescloud__Line_Item_Type__c;
    objPLIRevenueEntry.listPrice = pli.adsalescloud__List_Price__c;
    objPLIRevenueEntry.listRate = pli.adsalescloud__Listing_Rate__c;
    //objPLIRevenueEntry.quantity = pli.Quantity__c;
    objPLIRevenueEntry.premiumRate = pli.adsalescloud__Premium_Rate__c;
    objPLIRevenueEntry.netRate = pli.adsalescloud__Net_Rate__c;
    objPLIRevenueEntry.netCost = pli.adsalescloud__Net_Cost__c;
    objPLIRevenueEntry.grossRate = pli.adsalescloud__Gross_Rate__c;
    objPLIRevenueEntry.grossCost = pli.adsalescloud__Gross_Cost__c;
    objPLIRevenueEntry.proposalRateDiscount = pli.adsalescloud__Proposal_Rate_Discount__c;
    objPLIRevenueEntry.productRateAdjustment = pli.adsalescloud__Product_Rate_Adjustment__c;
    objPLIRevenueEntry.advertiserRateDiscount = pli.adsalescloud__Advertiser_Rate_Discount__c;
    if(!component.get('v.newRecord')) {
      objPLIRevenueEntry.advertiserDiscount = (pli.adsalescloud__Advertiser_Discount__c / 100 || 0);
      objPLIRevenueEntry.proposalDiscount = (pli.adsalescloud__Proposal__r.adsalescloud__Proposal_Discount__c / 100 || 0);
      objPLIRevenueEntry.agencyCommission = (pli.adsalescloud__Proposal__r.adsalescloud__Agency_Commission_Percentage__c / 100 || 0);
      objPLIRevenueEntry.productAdjustment = (pli.adsalescloud__Product_Adjustment__c / 100 || 0);
    }
    component.set('v.PLIRevenueEntry', objPLIRevenueEntry);

  },
  updateRecordWithPLIRevenueEntry: function(component) {
    var pli = component.get('v.record');
    var objPLIEntry = component.get('v.PLIRevenueEntry');
    component.set('v.record.adsalescloud__Net_Rate__c', objPLIEntry.netRate);
    component.set('v.record.adsalescloud__Gross_Rate__c', objPLIEntry.grossRate);
    component.set('v.record.adsalescloud__Quantity__c', objPLIEntry.quantity);
    component.set('v.record.adsalescloud__Limit_Type__c', objPLIEntry.limitType);
    if(pli.adsalescloud__Rate_Type__c.includes('CPM')) {
      component.set('v.record.adsalescloud__Net_Rate__c', pli.adsalescloud__Net_Rate__c /= 1000);
      component.set('v.record.adsalescloud__Gross_Rate__c', pli.adsalescloud__Gross_Rate__c /= 1000);
      component.set('v.record.adsalescloud__List_Price__c', pli.adsalescloud__List_Price__c /= 1000);
    }
    //component.set('v.record', pli);
  },
  redirect: function(component) {
    if(component.get('v.newRecord')) {
      var objKeyPrefix = component.get('v.objKeyPrefix');
      document.location.href = '/' + objKeyPrefix;
    }
    else {
      if(component.get('v.isProposalPliEdit')) {
        var record = component.get('v.record');
        document.location.href = '/' + record.adsalescloud__Proposal__c;
      }
      else {$A.get('e.force:closeQuickAction').fire();}
    }
  },
  getObjKeyPrefix: function(component) {
    var actionTogetObjKeyPrefix = component.get('c.getObjKeyPrefix');
    actionTogetObjKeyPrefix.setCallback(this,
      function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
          component.set('v.objKeyPrefix', response.getReturnValue());
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
        }
      }
    );
    $A.enqueueAction(actionTogetObjKeyPrefix);
  },
  getSelectedProductRecord: function(component) {
    var productRecordId = component.get('v.selectedProductLookUpRecord.Id');
    var record = component.get('v.record');
    if(!$A.util.isEmpty(productRecordId)) {
      var getProductRecords = component.get('c.getLookUpFieldRecords');
      getProductRecords.setParams({
        'lookupRecordId': productRecordId
      });
      getProductRecords.setCallback(this,
        function(response) {
          var state = response.getState();
          if(component.isValid() && state === 'SUCCESS') {
            component.set('v.selectedProductRecord', response.getReturnValue());
            if(record.adsalescloud__Link_Status__c === 'Unlinked') {component.set('v.productCustomAttrDetails', this.checkboxDetailFields);}
            else {
              if(!JSON.parse(response.getReturnValue().adsalescloud__Ad_Sales_Product_Template__r.adsalescloud__Customizable_Attributes_Details__c.replace(/&quot;/g, '"'))) {component.set('v.productCustomAttrDetails', this.checkboxDetailFields);}
              else {component.set('v.productCustomAttrDetails', JSON.parse(response.getReturnValue().adsalescloud__Ad_Sales_Product_Template__r.adsalescloud__Customizable_Attributes_Details__c.replace(/&quot;/g, '"')));}
            }
            //component.set('v.showSpinner', false);
          }
          else if(state === 'ERROR') {
            var errorMessage = response.getError()[0].message;
          }
        }
      );
      $A.enqueueAction(getProductRecords);
    } else {
      component.set('v.record.adsalescloud__Product__c', null);
    }
  },
  getSelectedProposalRecord: function(component) {
    var ProposalRecordId = component.get('v.selectedProposalLookUpRecord.Id');
    if(!$A.util.isEmpty(ProposalRecordId)) {
      var getLookUpFieldRecords = component.get('c.getSelectedProposalRecords');
      getLookUpFieldRecords.setParams({
        'lookupRecordId': ProposalRecordId
      });
      getLookUpFieldRecords.setCallback(this,
        function(response) {
          var state = response.getState();
          if(component.isValid() && state === 'SUCCESS') {
            var proposalRecord = response.getReturnValue();
            component.set('v.selectedProposalRecord', proposalRecord);
            //this.mapBilligFieldstoProposal(component);
          }
          else if(state === 'ERROR') {
            var errorMessage = response.getError()[0].message;
          }
        }
      );
      $A.enqueueAction(getLookUpFieldRecords);
    } else {
      component.set('v.record.adsalescloud__Proposal__c', null);
    }

  },
  setBillingData: function(component) {
    var record = component.get('v.record');
    var billingData = {};
    billingData.adsalescloud__Billing_Cycle__c = record.adsalescloud__Billing_Cycle__c;
    billingData.adsalescloud__Billing_Source__c = record.adsalescloud__Billing_Source__c;
    billingData.adsalescloud__Third_Party_Ad_Server__c = record.adsalescloud__Third_Party_Ad_Server__c;
    billingData.adsalescloud__Caps_and_Rollovers__c = record.adsalescloud__Caps_and_Rollovers__c;
    billingData.adsalescloud__Billing_Schedule__c = record.adsalescloud__Billing_Schedule__c;
    component.set('v.billingData', billingData);
  },
  mapBilligFieldstoProposal: function(component) {
    var proposalRecord;
    if(component.get('v.record.adsalescloud__Override_Billing__c')) {
      proposalRecord = component.get('v.billingData');  // updated on 17th Oct 2018 by Rahul
    }
    else {
      proposalRecord = component.get('v.selectedProposalRecord');
    }
    var record = component.get('v.record');
    record.adsalescloud__Billing_Cycle__c = proposalRecord.adsalescloud__Billing_Cycle__c;
    record.adsalescloud__Billing_Source__c = proposalRecord.adsalescloud__Billing_Source__c;
    record.adsalescloud__Third_Party_Ad_Server__c = $A.util.isEmpty(proposalRecord.adsalescloud__Third_Party_Ad_Server__c) ? '' : proposalRecord.adsalescloud__Third_Party_Ad_Server__c;
    record.adsalescloud__Caps_and_Rollovers__c = $A.util.isEmpty(proposalRecord.adsalescloud__Caps_and_Rollovers__c) ? '' : proposalRecord.adsalescloud__Caps_and_Rollovers__c;
    record.adsalescloud__Billing_Schedule__c = $A.util.isEmpty(proposalRecord.adsalescloud__Billing_Schedule__c) ? '' : proposalRecord.adsalescloud__Billing_Schedule__c;
    component.set('v.record', record);
  },
  quantityChangeHandler: function(component, updatedItem) {
    var item = updatedItem ? updatedItem : component.get('v.PLIRevenueEntry');
    var record = component.get('v.record');
    if((item.lineItemType === 'Standard' || item.lineItemType === 'Preferred Deal') && item.rateType === 'Viewable CPM' && item.limitType !== 'None') {
      item.limitQtyShow = true;
    } else {
      item.limitQtyShow = false;
    }
    if(item.limitType === 'None') {
      component.set('v.record.adsalescloud__Limit_Quantity__c', null);
      item.quantity = 0;
    }
    if(item.lineItemType === 'Price Priority' && item.limitType === 'Daily') {
      var startDate = record.adsalescloud__Start_Date__c;
      var endDate = record.adsalescloud__End_Date__c;
      if(startDate && endDate) {
        var d1 = this.getDateObjectInSpecificTimezone(startDate, record.adsalescloud__Time_Zone__c); d1.setHours(0);
        var d2 = this.getDateObjectInSpecificTimezone(endDate, record.adsalescloud__Time_Zone__c); d2.setHours(23);
        component.set('v.errorMessage', '');
        if(d2.getTime() > d1.getTime()) {
          /* var start = d1.toTimeString();
           d1.setHours(0); d1.setMinutes(0);
           var startTime = start.substring(0, start.indexOf(' '));
           var startTimeThreshold = '23:59:00';
           var end = d2.toTimeString();
           d2.setHours(0); d2.setMinutes(0);
           var endTime = end.substring(0, end.indexOf(' '));
           var endTimeThreshold = '00:01:00';

           var startDateAdjust = (startTime < startTimeThreshold) ? 1 : 0;
           var endDateAdjust = (endTime > endTimeThreshold) ? 0 : -1;*/

          var days = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
          item.netCost = item.netRate * item.quantity * days;
          item.grossCost = item.grossRate * item.quantity * days;
        }
      }
    }
    else {
      item.netCost = item.netRate * item.quantity;
      item.grossCost = item.grossRate * item.quantity;
    }
    if(item.rateType.includes('CPM')) {
      item.netCost = item.netCost / 1000;
      item.grossCost = item.grossCost / 1000;
    }
    if(item.lineItemType === 'Standard' || item.lineItemType === 'Preferred Deal') {
      item.scheduledQuantity = item.quantity * (1 + item.buffer / 100);
    }
    component.set('v.PLIRevenueEntry', item);
  },
  getPriorityRatingValue: function(component) {
    var action = component.get('c.fetchPicklistOptionsValues');
    action.setParams({
      'pickListFieldName': 'lineItemPriority'
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if(component.isValid() && state === 'SUCCESS') {
        // create a empty array var for store dependent picklist values for controller field)
        var dependentFields = [];
        var result = JSON.parse(response.getReturnValue());
        var listPicklistValues = result.pickListValues;
        for(var i = 0; i < listPicklistValues.length; i++) {
          dependentFields.push({
            class: 'optionClass',
            label: listPicklistValues[i].label,
            value: listPicklistValues[i].value,
            selected: component.get('v.record').adsalescloud__Line_Item_Priority_Rating__c !== undefined && listPicklistValues[i] === component.get('v.record').adsalescloud__Line_Item_Priority_Rating__c
          });
        }
        component.set('v.lineItemRatingOptions', dependentFields);
        component.set('v.lineItemRatingIsEditable', result.isEditable);
      }
      else if(state === 'ERROR') {
        var errorMessage = response.getError()[0].message;
        component.set('v.errorMessage', errorMessage);
      }
    });
    $A.enqueueAction(action);
  },
  updateLineItemPriority: function(component, event, helper) {
    var lineitemPriority = $A.util.isEmpty(component.get('v.record.adsalescloud__Line_Item_Priority__c')) ? '' : component.get('v.record.adsalescloud__Line_Item_Priority__c');
    var lineitemPriorityRate = component.get('v.record.adsalescloud__Line_Item_Priority_Rating__c');
    var lineitemType = component.get('v.record.adsalescloud__Line_Item_Type__c');
    var dependentFields = [];
    switch(lineitemType) {
      case 'Standard':
        if(lineitemPriority === 'Normal') {
          lineitemPriorityRate = 8;
        }
        else if(lineitemPriority === 'Low') {
          lineitemPriorityRate = 10;
        }
        else if(lineitemPriority === 'High') {
          lineitemPriorityRate = 6;
        }
        else {
          lineitemPriorityRate = 0;
        }
        break;
      case 'Sponsorship': lineitemPriorityRate = 4; break;
      case 'Network': lineitemPriorityRate = 12; break;
      case 'Bulk': lineitemPriorityRate = 12; break;
      case 'Price Priority': lineitemPriorityRate = 12; break;
      case 'House': lineitemPriorityRate = 16; break;
      case 'Preferred Deal': lineitemPriorityRate = 12; break;
      default: lineitemPriorityRate = 2;
    }
    component.set('v.record.adsalescloud__Line_Item_Priority_Rating__c', lineitemPriorityRate);
  },

  setCheckAvailButtonVisibility: function(component) {
    var objectData = JSON.parse(JSON.stringify(component.get('v.record')));
    var lineItemType = component.get('v.record.adsalescloud__Line_Item_Type__c');
    var rateType = component.get('v.record.adsalescloud__Rate_Type__c');
    var productType = component.get('v.record.adsalescloud__Product_Type__c');

    if((lineItemType != 'Standard' && lineItemType != 'Sponsorship') || (rateType != 'CPM' && rateType != 'CPC' && rateType != 'Viewable CPM') || (productType != 'DFP Ads'))
      component.set('v.showCheckAvailButton', false);
    else
      component.set('v.showCheckAvailButton', true);
  },
});