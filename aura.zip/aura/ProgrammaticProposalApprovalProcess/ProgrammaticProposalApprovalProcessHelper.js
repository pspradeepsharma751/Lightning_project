({
    // This doInit method has different code as comparision to SynctoAdServer.cmp
    
    doInit : function (component) {
        component.set("v.showSpinner", true);
        component.set("v.readyForDFPError",$A.get("$Label.c.Not_Ready_for_Ad_Server"));
        var action = component.get("c.getReadyForDFPInformation");
        action.setParams({
            'recordId':component.get("v.recordId"),
            'action':'ApprovalProcess'
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                var response = JSON.parse(response.getReturnValue());
                var callOutException = response.callOutException;
                if(response.callOutException){
                    if(callOutException.indexOf("AUTH_FAILED") > -1){
                        if(confirm("User authentication failed while syncing with the Ad Server.\nPlease navigate to Ad Sales User Setup, authorize your Salesforce User with the Ad Server, and try again.")){
                            window.location.href ="/apex/AdSalesUserSetup";
                        } else {
                            $A.get('e.force:closeQuickAction').fire();
                            $A.get('e.force:refreshView').fire();
                        }
                    }
                    else if(callOutException.indexOf("NO_NETWORKS_TO_ACCESS") > -1){
                        if(confirm("Please make sure user is authorized with authenticated account and try again.")){
                            window.location.href ="/apex/AdSalesUserSetup";
                        } else {
                            $A.get('e.force:closeQuickAction').fire();
                            $A.get('e.force:refreshView').fire();
                        }
                    }
                } else {
                    component.set("v.readyForDFPInfo", response);
                    component.set("v.showSpinner", false);
                    component.set("v.islightningCheckVald", false);
                    component.set("v.proposalRecord", response.proposalRecordObject);
                    if((response.countTotalPliError == 0 || response.containPliWarningMsg) && 
                       (response.countTotalProposalError == 0 || response.containProposalWarningMsg || 
                        response.proposalErrorList.indexOf("Prompt to link") > -1 ||
                        response.proposalErrorList.indexOf("archived") > -1 ||
                        response.proposalErrorList.indexOf("unarchived") > -1 ||
                        response.proposalErrorList.indexOf("Non-DFP Ad") > -1 )){
                       
                            var displayOkButton = component.find("displayRetryButton");
                            $A.util.addClass(displayOkButton, 'slds-hide');
                            var dispBtn = component.find("displayButton");
                            $A.util.removeClass(dispBtn, 'slds-hide');
                    }
                }
                
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    submitForApproval: function(component) {
        var action = component.get('c.submitForApprovalProcess');
        action.setParams({
            'recordId':component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                if(component.get("v.isLightning")){
                    $A.get("e.force:closeQuickAction").fire();
                    $A.get('e.force:refreshView').fire();
                } else{
                    window.location.href = "/"+component.get("v.recordId");
                }
                
            }
            else if(state === 'ERROR') {
                var errorMessage = response.getError()[0].message;
            }
        });
        $A.enqueueAction(action);
    },
})