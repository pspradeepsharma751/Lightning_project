({
  checkIfPriceBookExists: function(component) {
    var proposal = component.get('v.proposal');
    var showPriceBookSelection = true;
    $A.util.addClass(component.find('pricebookSelection'), 'slds-hide');
    $A.util.addClass(component.find('productSelection'), 'slds-hide');

    if(proposal && proposal.adsalescloud__Opportunity__r) {
      if(proposal.adsalescloud__Opportunity__r.Pricebook2Id) {
        console.log(proposal.adsalescloud__Opportunity__r);
        $A.util.removeClass(component.find('productSelection'), 'slds-hide');
        showPriceBookSelection = false;
      }
      else {
        $A.util.removeClass(component.find('pricebookSelection'), 'slds-hide');
        showPriceBookSelection = true;
      }
    }
    return showPriceBookSelection;
  },
  retrieveProductCandidates: function(component) {
    var proposal = component.get('v.proposal');

    var getProductCandidate = component.get('c.getProductCandidate');
    getProductCandidate.setParams({
      'pricebook2Id': proposal.adsalescloud__Opportunity__r.Pricebook2Id,
      'isProgrammatic': proposal.adsalescloud__isProgrammatic__c,
      'programmaticType': proposal.adsalescloud__Programmatic_Type__c
    });

    getProductCandidate.setCallback(this, function(response) {
      var state = response.getState();
      if(component.isValid() && state === 'SUCCESS') {
        console.log(response.getReturnValue());
        var productCandidateArray = response.getReturnValue();
        this.filterProducts(component, productCandidateArray, false);
      } else {
        console.log('Failed with state: ' + state);
      }
    });

    $A.enqueueAction(getProductCandidate);
  },
    search: function(component) {
        var proposal = component.get('v.proposal');
        var filterInfo = component.get('v._filter');
        var orderBy = 'Name'; //component.get("v.orderBy"); // concflicting with sorting, need to be fixed.
        filterInfo = filterInfo ? filterInfo : {};
        filterInfo.orderBy = orderBy;
        var applyFilter = component.get('c.applyFilterSearch');
        applyFilter.setParams({
            'pricebook2Id': proposal.adsalescloud__Opportunity__r.Pricebook2Id,
            'filterInfoStr': JSON.stringify(filterInfo),
            'isProgrammatic': proposal.adsalescloud__isProgrammatic__c,
            'programmaticType': proposal.adsalescloud__Programmatic_Type__c
        });
        
        applyFilter.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
               // component.set('v.productCandidates', response.getReturnValue());
                console.log(response.getReturnValue());
                var productCandidateArray = response.getReturnValue();
                this.filterProducts(component, productCandidateArray, true);
            } else {
                console.log('Failed with state: ' + state);
            }
        });
        
        $A.enqueueAction(applyFilter);
    },
    
    filterProducts: function(component, productCandidateArray, isFilter) {
        var proposal = component.get('v.proposal');
        var productCandidate = [];
        if(proposal.adsalescloud__isProgrammatic__c && proposal.adsalescloud__Programmatic_Type__c == 'Guaranteed') {
            productCandidateArray.forEach(function(productCandidateItem) {
                if(productCandidateItem.hasProducts) {
                    var pkgProductCandidateItem = productCandidateItem.packageProductList;
                    for(var i = 0; i < pkgProductCandidateItem.length; i++) {
                        if(pkgProductCandidateItem[i].inventorySize) {
                            var inventorySize = JSON.parse(pkgProductCandidateItem[i].inventorySize.replace(/&quot;/g, '\"'));
                            if(inventorySize[0] && inventorySize[0].environmentType === 'BROWSER' && inventorySize[0].companions) {
                                pkgProductCandidateItem.splice(i, 1);
                            }
                        }
                    }
                    productCandidate.push(productCandidateItem);
                    
                } else {
                    if(productCandidateItem.inventorySize) {
                        var inventorySize = JSON.parse(productCandidateItem.inventorySize.replace(/&quot;/g, '\"'));
                        if(!(inventorySize[0] && (inventorySize[0].environmentType === 'BROWSER' && inventorySize[0].companions))) {
                            productCandidate.push(productCandidateItem);
                        }
                    }
                }
            });
        }
        if(productCandidate.length == 0 /*&& !isFilter*/) {
            productCandidate = productCandidateArray;
        }
        
        component.set('v.productCandidates', productCandidate);
    },
})