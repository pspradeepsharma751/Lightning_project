({
  //Get the Product Candidates from the search
  getProductCandidates: function(component, event, helper) {
    if(!helper.checkIfPriceBookExists(component)) {
      helper.retrieveProductCandidates(component);
    }
  },
  toggleFilterBar: function(component) {
    var showFilterBar = component.get('v.showFilterBar');
    if(showFilterBar) {
      $A.util.removeClass(component.find('productFilterBar'), 'slds-hide');
    } else {
      $A.util.addClass(component.find('productFilterBar'), 'slds-hide');
    }
  },
  applyFilter: function(component, event, helper) {
    helper.search(component);
  },
  gotToOpportunity: function(component) {
    var navEvt = $A.get('e.force:navigateToSObject');
    var proposal = component.get('v.proposal');
    navEvt.setParams({
      'recordId': proposal.adsalescloud__Opportunity__c,
      'slideDevName': 'detail'
    });
    navEvt.fire();
  }

});