({
    doInit : function(component, event, helper) {
		//helper.doInit(component);
	},
     save : function(component, event, helper) {
		
	},
     addValue : function(component, event, helper) {
		helper.addValue(component);
	},
     cancel : function(component, event, helper) {
		
	},
    deleteValue : function(component, event, helper) {
		helper.deleteValue(component, event.currentTarget.dataset.valueIndex);
	},
	myAction : function(component, event, helper) {
		component.set("v.pricebookId", JSON.parse(JSON.stringify(component.get("v.premium.adsalescloud__Price_Book__c"))));
	}
})