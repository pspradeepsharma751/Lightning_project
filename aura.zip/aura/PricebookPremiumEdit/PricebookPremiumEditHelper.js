({
    /*
    doInit : function(component) {
        var action = component.get("c.getPremium");
        action.setParams({"recordId" : component.get("v.recordId")});
        action.setCallback(this, function(response){
            component.set("v.showSpinner", false);
            if(response.getState() === "SUCCESS"){
                var result = JSON.parse(response.getReturnValue());
                component.set("v.premium", result.premiumList[0]);
                component.set("v.pricingMethodList", result.picklistMap.pricingMethodList);
                component.set("v.paymentModelList", result.picklistMap.paymentModelList);
                component.set("v.rateTypeList", result.picklistMap.rateTypeList);
            }
        });
        $A.enqueueAction(action);
    },
    save : function(component) {
        
    },
    onSave: function(component) {
        if($A.util.isEmpty(component.get('v.premiumList'))  && $A.util.isEmpty(component.get('v.deletedPremiumList'))  &&  $A.util.isEmpty(component.get('v.deletedValueList'))){
            component.set('v.error', 'Nothing to save. Please add at least 1 Premium');
            this.hideError(component);
            return;
        }      
        if(this.validate(component)) {
            component.set('v.showSpinner', true);
            var pricebook = {};
            pricebook.premiumList = [component.get('v.premium')];
            pricebook.deletedValueList = component.get('v.deletedValueList');
            pricebook.premiumList.forEach(function(premium, index) {
                delete premium.premiumFeatureId;
                delete premium.valueList;
                premium.adsalescloud__Premium_Rate_Values__r.records.forEach(function(value, index) {
                    if(value.adsalescloud__Payment_model__c === 'Amount') {
                        value.adsalescloud__Percent__c = null;
                        if(value.adsalescloud__Rate_Type__c.includes('CPM')){
                            value.adsalescloud__Amount__c /= 1000;
                        }
                    }
                    else {
                        value.adsalescloud__Amount__c = null;
                    }
                });
            });
            var action = component.get('c.savePricebook');
            action.setParams({
                'pricebook': JSON.stringify(pricebook)
            });
            action.setCallback(this, function(response) {
                if(response.getState() === 'SUCCESS') {
                    document.location.href = '/' + component.get('v.recordId');
                }
                else {
                    component.set('v.error', 'Something went wrong!');
                    this.hideError(component);
                }
                component.set('v.showSpinner', false);
            });
            $A.enqueueAction(action);
        }
    },
    validate: function(component) {
        component.set('v.error', '');
        var validFieldValues = component.find('formField').reduce(function(validSoFar, inputCmp) {  // validation for lightning components
            // Displays error messages for invalid fields
            try {
                inputCmp.showHelpMessageIfInvalid();
            }
            catch(e) {}
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        component.find('currencyField').forEach(function(field){
            if(field.get("v.required") && !field.get("v.value")){
                validFieldValues = false;
                field.set("v.errors", [{message:"Complete this field."}]);
            }
        });
        var uniqueValues = true;
        if(validFieldValues) {
            var self = this;
            var premiumList = component.get('v.premiumList');
            premiumList.forEach(function(premium, premiumIndex) {
                for(var index = 0; index < premium.adsalescloud__Premium_Rate_Values__r.records.length - 1; index++) {
                    var value1 = premium.adsalescloud__Premium_Rate_Values__r.records[index];
                    var obj1 = {};
                    obj1.value = value1.adsalescloud__Value__c;
                    obj1.rateType = value1.adsalescloud__Rate_Type__c;
                    for(var valueIndex = index + 1; valueIndex < premium.adsalescloud__Premium_Rate_Values__r.records.length; valueIndex++) {
                        var obj2 = {};
                        var value2 = premium.adsalescloud__Premium_Rate_Values__r.records[valueIndex];
                        obj2.value = value2.adsalescloud__Value__c;
                        obj2.rateType = value2.adsalescloud__Rate_Type__c;
                        if(Object.is(JSON.stringify(obj1), JSON.stringify(obj2))) {
                            uniqueValues = false;
                            component.set('v.error', 'Error: Duplicate entities configured for Premium Feature: ' + premium.adsalescloud__Premium_Feature__c);
                            self.hideError(component);
                            return;
                        }
                    }
                }
            });
        }
        else {
            component.set('v.error', 'Invalid Data. Please review all fields');
            this.hideError(component);
        }
        return validFieldValues && uniqueValues;    
        
    }, 
    addValue: function(component) {
        var premium = component.get('v.premium');
        premium.adsalescloud__Premium_Rate_Values__r.totalSize++;
        var value = {
            'adsalescloud__Amount__c': 0,
            'adsalescloud__Payment_model__c': 'Amount',
            'adsalescloud__Rate_Type__c': 'CPM',
        }
        if($A.util.isEmpty(premium.premiumFeatureId)) {
            value.adsalescloud__Value__c = 'Any value';
        }
        else {
            value.adsalescloud__Value__c = 'All other values';
        }
        if(!$A.util.isEmpty(premium.Id)) {
            value.adsalescloud__Premium__c = premium.Id;
        }
        premium.adsalescloud__Premium_Rate_Values__r.records.push(value);
        component.set('v.premium', JSON.parse(JSON.stringify(premium)));
    },
    deleteValue: function(component, valueIndex) {
        var premium = component.get('v.premium');
        premium.adsalescloud__Premium_Rate_Values__r.totalSize--;
        var valueList = premium.adsalescloud__Premium_Rate_Values__r.records;
        var deletedValueList = component.get('v.deletedValueList');
        if(!$A.util.isEmpty(valueList[valueIndex].Id)) {
            deletedValueList.push(valueList[valueIndex]);
        }
        valueList.splice(valueIndex, 1);
        premium.adsalescloud__Premium_Rate_Values__r.records = valueList;
        component.set('v.premium', premium);
    },*/
})