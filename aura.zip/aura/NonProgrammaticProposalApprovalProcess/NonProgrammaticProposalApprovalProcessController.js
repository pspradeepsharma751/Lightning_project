({
	doInit : function (component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 50rem;}.panel .closeIcon{display:none} .slds-modal__content{max-height: calc(100vh - 210px); overflow-y: auto;}</style>');
        helper.doInit(component);
    },
    
    redirectToPrevPage : function (component, event, helper) {
        /*if(component.get("v.isLightning")){
           $A.get('e.force:closeQuickAction').fire();
        } else{
        	window.location.href = "/"+component.get("v.recordId");
        }*/
         $A.get('e.force:closeQuickAction').fire();
    },
    
   
    
    skipValidation : function (component, event, helper) { 
        var readyForDFPInfo = component.get("v.readyForDFPInfo");
        if(component.get("v.isSkipValidation") ||
           ((readyForDFPInfo.countTotalPliError == 0 || response.containPliWarningMsg) && (readyForDFPInfo.countTotalProposalError == 0 || readyForDFPInfo.proposalErrorList.indexOf("Prompt to link") > -1))){
            var displayRetryButton = component.find("displayRetryButton");
            $A.util.addClass(displayRetryButton, 'slds-hide');
            var dispBtn = component.find("displayButton");
            $A.util.removeClass(dispBtn, 'slds-hide');
        } else {
            var dispBtn = component.find("displayButton");
            $A.util.addClass(dispBtn, 'slds-hide');
            var displayRetryButton = component.find("displayRetryButton");
            $A.util.removeClass(displayRetryButton, 'slds-hide');
            
        }
        
    },
    
    redirectToProposalDetailPage : function (component, event, helper) { 
       // if(component.get("v.isLightning")){
            $A.get('e.force:closeQuickAction').fire();
            $A.get('e.force:refreshView').fire();
       // } else{
            //window.location.href = "/"+component.get("v.recordId");
       // }
        
    },
    
    editPliRecord : function (component, event, helper) {
        component.set("v.selectedId", event.currentTarget.dataset.id); //id retrieved earlier
        /*setTimeout(function()
        { 
            var ec = component.find("editDiv");
            $A.util.removeClass(ec, 'slds-hide');
        }, 800);*/
       window.open("/"+event.currentTarget.dataset.id);
    },
    
    editProposalRecord : function (component, event, helper) {
        window.open("/"+event.currentTarget.dataset.id);
    },
    
    reloadPage : function (component, event, helper) {
        if(component.get("v.isPliRecordUpdated")){
           var ec = component.find("editDiv");
            $A.util.addClass(ec, 'slds-hide');
           // helper.doInit(component)
            component.set("v.selectedId", null);
            component.set("v.isPliRecordUpdated", false);
        }
           
        
    },
    
    checkValidation : function (component, event, helper) {
        if(component.get("v.islightningCheckVald"))
            helper.doInit(component);
    },
    
    submitForApproval : function (component, event, helper) {
        helper.submitForApproval(component);
    },
})