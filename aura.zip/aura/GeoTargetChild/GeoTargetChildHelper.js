({
  fetchGeoTargets: function(component) {
    var adunit = component.get('v.adunit');
    var limit = component.get('v.limit');
    var offset = component.get('v.offset');
    var helper = this;
    this.fetchData(component, 'getGeoTargets', {
      'page_size': limit,
      'offset': (offset * limit),
      'parentId': adunit.id,
      'searchTerm': null,
      'showPopularCountries': false
    }, function(res) {
      if(res.status === 'OK') {
        var oldTargets = component.get('v.targets');
        var newTargets = res.geoTargets;
        if(newTargets.length > 0) {
          component.set('v.targets', oldTargets.concat(newTargets));
          if(newTargets.length === limit) {
            component.set('v.offset', ++offset);
            component.set('v.showMore', true);
          }
          else
            component.set('v.showMore', false);
          component.set('v.hasChildren', true);
        }

        if(oldTargets.length === 0)
          helper.expandNodes(component);

      } else {
        //console.log(res.msg);
        //component.set('v.error',res.msg);
      }
    });
  },
  expandNodes: function(component) {
    var flag = component.get('v.expand');
    component.set('v.expand', !flag);
  },
  fireEvent: function(component, action) {
    var includeExcludeEvent = $A.get('e.c:TargetingEvent');
    includeExcludeEvent.setParams({
      'adunit': component.get('v.adunit'),
      'action': action,
      'segments':component.get('v.segments'),
      'category': component.get('v.category'),
      'sub_category': component.get('v.sub_category')
    });
    includeExcludeEvent.fire();
  }
})