({
  doInit: function(component, event, helper) {
    var targets = component.get('v.selectedMap');
    var adunit = component.get('v.adunit');
    if(targets) {
      var parentId = (adunit.parentId) ? adunit.parentId : '0000';
      var category = component.get('v.category');
      var items = targets[category];
      if(items && items[parentId]) {
        var adunits = items[parentId];
        for(var i = 0; i < adunits.length; i++) {
          if(adunits[i].adunit.id === adunit.id) {
            if(adunits[i].action === 'include') {
              component.set('v.included', true);
              component.set('v.showInclude', true);
            }
            else {
              component.set('v.excluded', true);
              component.set('v.showExclude', true);
            }
            break;
          }
        }
      }
    }
  },
  getTargets: function(component, event, helper) {
    var hasChildren = component.get('v.hasChildren');
    if(hasChildren)
      helper.expandNodes(component);
    else
      helper.fetchGeoTargets(component);
  },
  collapseNodes: function(component, event, helper) {
    var flag = component.get('v.expand');
    component.set('v.expand', !flag);
  },
  loadMore: function(component, event, helper) {
    helper.fetchGeoTargets(component);
  },
  handleMenuSelect: function(component, event, helper) {
    var action = event.getParam('value');
    if(action === 'include') {
      component.set('v.showInclude', true);
      component.set('v.included', true);
    }
    else {
      component.set('v.showExclude', true);
      component.set('v.excluded', true);
    }
    helper.fireEvent(component, action);
  },
  handleRemovedTarget: function(component, event, helper) {
    var segments = component.get('v.segments');
    var eventSegments = event.getParam('segments');
    if(eventSegments !== segments) return;
    var targets = component.get('v.selectedMap');
    var item = event.getParam('item');
    var parentCategory = event.getParam('parentCategory');
    var current = component.get('v.adunit');

    if(item.adunit.id === current.id) {
      if(item.action === 'include') {
        component.set('v.included', false);
      } else {
        component.set('v.excluded', false);
      }
    }
    if(!targets || !targets[parentCategory]) {
      component.set('v.showInclude', false);
      component.set('v.showExclude', false);
    }
  },
  handleValueAction: function(component, event) {
    component.set('v.included', false);
    component.set('v.excluded', false);
  }
});