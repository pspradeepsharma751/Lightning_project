({
    doInit : function(component) {  
        var self = this;
        if($A.util.isEmpty(component.get("v.record"))){
            window.setTimeout(function(){
                self.doInit(component);            
            },40);
        }
        else{
            component.set("v.showSpinner", false);
            if(component.get("v.record.adsalescloud__Status__c") != "Inactive"){
                component.set("v.hideUserPrompt", true);
            }
        }
    },
    archive : function(component){
        var action = component.get("c.performAction");
        action.setParams({
            "productTemplateIDs" : [component.get("v.recordId")],
            "action" : "archive"
        });
        action.setCallback(this, function(response){
            component.set("v.showSpinner", false);
            if(response.getState() === "SUCCESS"){
                var toastEvent = $A.get('e.force:showToast');
                toastEvent.setParams({
                    'title': 'Success!',
                    'type': 'success',
                    'message': 'Product Template archived successfully.'
                });
                toastEvent.fire();
                $A.get('e.force:refreshView').fire();
                $A.get('e.force:closeQuickAction').fire();
            }else{
                component.set("v.showToast",true);
                component.set("v.message", "An error occured while archiving the Product Template.");
                component.set("v.messageType", "error");
            }
        });
        $A.enqueueAction(action);
    },
})