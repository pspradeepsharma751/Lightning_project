({
  updateRecordView: function(component, event, helper) {
    helper.updateRecordView(component);
  },
  initiatePaginationInfo: function(component, event, helper) {
    helper.initiatePaginationInfo(component);
  }
})