({
  getSelectedTargets: function(component, event) {
    var recordId = component.get('v.recordId');
    var self = this;
    if(recordId) {
      self.fetchData(component, 'getAllSelectedTargets',
        {
          recordId: recordId,
          segments: true
        }, function(res) {
          try {
            if(res.status === 'OK') {
              component.set('v.selectedTargets', res.selected);
              var keys = Object.keys(res.selected);
              if(res.lineItems && res.lineItems > 0) {
                if(keys.length === 0) {
                  component.set('v.hideMainCmp', true);
                  return;
                }
                component.set('v.lineItems', res.lineItems);
                self.populateWidgets(component, keys);
              } else {
                self.populateWidgets(component, []);
              }
              self.nonDfpTemplateHandler(component, event, true);
            } else {
            }
          } catch(e) {
            console.log(e.message);
          }
        });
    } else {
      component.set('v.selectedTargets', {});
      self.populateWidgets(component, []);
      self.createDynamicComponent(component, event);
    }
  },
  populateWidgets: function(component, activeWidgets) {
    var widgets = component.get('v.widgets');
    if(!widgets || widgets.length < 1) {
      widgets = {
        'Video Content': {'name': 'Video Content', 'active': false, 'cmpName': 'VideoContentTarget', 'enable': true, show: false},
        'Video Position': {'name': 'Video Position', 'active': false, 'cmpName': 'VideoPositionTarget', 'enable': true, show: false},
        'Inventory': {'name': 'Inventory', 'active': true, 'cmpName': 'InventoryTarget', 'enable': true, show: true},
        'Key-Values': {'name': 'Key-Values', 'active': false, 'cmpName': 'KeyValueTarget', 'enable': true, show: true},
        'Geography': {'name': 'Geography', 'active': false, 'cmpName': 'GeoTarget', 'enable': true, show: true},
        'Devices': {'name': 'Devices', 'active': false, 'cmpName': 'DeviceTarget', 'enable': true, show: true},
        'Connection': {'name': 'Connection', 'active': false, 'cmpName': 'ConnectionTargets', 'enable': true, show: true},
        'Inventory Sizes': {'name': 'Inventory Sizes', 'active': false, 'cmpName': 'InventorySizeSegment', 'enable': true, show: true}
      };
    }
    var default_cmpName = '';
    var currentIndex = 0;
    if(activeWidgets.length > 0) {
      var keys = Object.keys(widgets);
      for(var ind = 0; ind < keys.length; ind++) {
        if(activeWidgets.indexOf(keys[ind]) === -1) {
          widgets[keys[ind]].enable = false;
          widgets[keys[ind]].active = false;
        } else if(default_cmpName === '') {
          widgets[keys[ind]].active = true;
          default_cmpName = widgets[keys[ind]].cmpName;
          currentIndex = ind;
          component.set('v.default_cmpName', default_cmpName);
        }
      }
    }
    component.set('v.widgets', Object.values(widgets));
    component.set('v.currentIndex', currentIndex);
  },
  createDynamicComponent: function(component, event) {
    component.set('v.showSpinner', true);
    var cmpName = (event && event.getParam('cmp_name')) ? event.getParam('cmp_name') : '';
    if(!cmpName || cmpName === '')
      cmpName = component.get('v.default_cmpName');

    $A.createComponent(
      'adsalescloud:' + cmpName,
      {
        'aura:id': 'newComponentId',
        'recordId': component.get('v.recordId'),
        'selectedMap': component.getReference('v.selectedTargets'),
        'segments': true,
        'lineItems': component.get('v.lineItems'),
        'hidePlacement': component.getReference('v.hidePlacement')
      },
      function(newCmp, status, errorMessage) {
        if(status === 'SUCCESS') {
          var parent = component.find('mainContainer');
          parent.set('v.body', [newCmp]);
          component.set('v.showSpinner', false);
        }
        else if(status === 'INCOMPLETE') {
          console.log('No response from server or client is offline.');
        }
        else if(status === 'ERROR') {
          console.log('Error: ', errorMessage);
        }
      }
    );
  },
  nonDfpTemplateHandler: function(component, event, flag) {
    var inventoryType = component.get('v.inventoryType');
    var selectedTargets = component.get('v.selectedTargets');
    var widgetsArr = component.get('v.widgets');
    var record = component.get('v.record');
    var isTargetDeleted = false;
    var fireCreateCmp = false;
    var isNonDFPType = (record && record.adsalescloud__Product_Type__c && record.adsalescloud__Product_Type__c === 'Non-DFP Ads');
    var isClickTrackingType = (record && record.adsalescloud__Line_Item_Type__c && record.adsalescloud__Line_Item_Type__c === 'Click Tracking Only');
    component.set('v.hidePlacement', isClickTrackingType);
    var default_cmpName = component.get('v.default_cmpName');
    var isVideoEnabled = inventoryType && inventoryType === 'Video VAST';
    for(var i = 0; i < widgetsArr.length; i++) {
      if(widgetsArr[i].name === 'Inventory') {
        if(isNonDFPType) {
          widgetsArr[i].show = false;
          if(selectedTargets && selectedTargets[widgetsArr[i].name]) {
            isTargetDeleted = true;
            delete selectedTargets[widgetsArr[i].name];
          }
          if(widgetsArr[i].active) {
            widgetsArr[i].active = false;
            flag = true;
          }
        } else {
          widgetsArr[i].show = true;
          if(isClickTrackingType) {
            widgetsArr[i].active = true;
            default_cmpName = widgetsArr[i].cmpName;
            flag = true;
          }
        }
      }
      else if(isClickTrackingType) {
        widgetsArr[i].show = false;
        widgetsArr[i].active = false;
        if(selectedTargets && selectedTargets[widgetsArr[i].name]) {
          isTargetDeleted = true;
          delete selectedTargets[widgetsArr[i].name];
        }
      }else if(!isVideoEnabled && (widgetsArr[i].name === 'Video Content' || widgetsArr[i].name === 'Video Position')) {
        fireCreateCmp = true;
        widgetsArr[i].show = false;
        widgetsArr[i].active = false;
        if(selectedTargets && selectedTargets[widgetsArr[i].name]) {
          isTargetDeleted = true;
          delete selectedTargets[widgetsArr[i].name];
        }
      } else {
        widgetsArr[i].show = true;
      }

      if(default_cmpName === 'InventoryTarget' && (fireCreateCmp || isNonDFPType || isClickTrackingType) && widgetsArr[i].enable && widgetsArr[i].show) {
        fireCreateCmp = false;
        default_cmpName = widgetsArr[i].cmpName;
        widgetsArr[i].active = true;
        flag = true;
      }
    }
    if(isTargetDeleted)
      component.set('v.selectedTargets', selectedTargets);
    component.set('v.default_cmpName', default_cmpName);
    component.set('v.widgets', widgetsArr);
    if(flag) this.createDynamicComponent(component, event);
  }
});