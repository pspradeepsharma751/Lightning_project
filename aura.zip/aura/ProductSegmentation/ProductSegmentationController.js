({
  createComponent: function(component, event, helper) {
    helper.createDynamicComponent(component, event);
  },
  doInit: function(component, event, helper) {
    helper.getSelectedTargets(component, event);
  },
  recordChangeHandler: function(component, event, helper) {
    helper.nonDfpTemplateHandler(component, event, false);
  }
});