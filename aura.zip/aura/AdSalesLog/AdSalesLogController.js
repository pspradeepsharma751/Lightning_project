({
    doInit : function(component, event, helper){
        var action = component.get("c.getErrorLogSize");
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                component.set("v.errorLogSize", response.getReturnValue());
            }
            else{
                component.set('v.message','ERROR occured while getting Error Log Size');
                component.set('v.messageType', $A.get("$Label.c.ERROR"));
            }
        });
        $A.enqueueAction(action);
    },
    setErrorLogSize : function(component, event, helper) {
            var logSize = component.get("v.errorLogSize");
        logSize = $A.util.isEmpty(logSize)?null:logSize.toString();
        if(logSize == null || (logSize.toString().indexOf('.')<0 && parseInt(logSize)>=1)){
            var action = component.get("c.updateErrorLogSize");
            action.setParams({"logSize" : logSize});
            action.setCallback(this, function(response){
                if(response.getState() === "SUCCESS"){
                    component.set('v.message','Error Log Size Updated Successfully');
                    component.set('v.messageType', $A.get("$Label.c.SUCCESS"));
                }
                else{
                    component.set('v.message','ERROR occured while updating Error Log Size');
                    component.set('v.messageType', $A.get("$Label.c.ERROR"));
                }
            });
            $A.enqueueAction(action);
        }
        else{
            component.set('v.message','Please input a correct value for Error Log Size');
            component.set('v.messageType', $A.get("$Label.c.ERROR"));
        }
    }
})