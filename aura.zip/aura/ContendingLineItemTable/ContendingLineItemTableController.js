({
	doInit : function(component, event, helper) {        
        if(component.get("v.uiLevel") == 2){
            let options = component.get("v.options");
            options[0].label = component.get("v.contendingLineItemData").higherPriority.length + " higher- or equal-priority contending line items altogether";
            options[1].label = component.get("v.contendingLineItemData").lowerPriority.length + " lower-priority contending line items altogether";
            component.set("v.options", options);
        }
        helper.doInit(component);
	},    
    previousProductPage: function(component, event, helper) {
       helper.changeProductPage(component, -1);
    },
    nextProductPage: function(component, event, helper) {
       helper.changeProductPage(component, 1);
    },
    displayPriorityChanged: function(component, event, helper) {
       helper.doInit(component);
       console.log(component.get("v.lineItemDisplayPriority"));
    },
    showModal: function(component, event, helper) {
        component.set("v.showModal", true);
    },
    closeModal: function(component, event, helper) {
        component.set("v.showModal", false);
    },
})