({
  fireSelectionEvent: function(component, action) {
    var compEvent = $A.get('e.c:TargetingEvent');
    compEvent.setParams({
      'adunit': component.get('v.adunit'),
      'action': action,
      'segments': component.get('v.segments'),
      'category': component.get('v.category'),
      'sub_category': component.get('v.sub_category')
    });
    compEvent.fire();
  },
  isEmpty: function(obj) {
    for(var key in obj) {
      if(obj.hasOwnProperty(key))
        return false;
    }
    return true;
  },
  makeTargetsSelected: function(component) {
    try {
      var targets = component.get('v.selectedMap');
      var adunit = component.get('v.adunit');

      if(targets) {
        var parentId = (adunit.parentId) ? adunit.parentId : '0000';
        var category = component.get('v.category');
        var items = targets[category];
        if(items && items[parentId]) {
          var adunits = items[parentId];
          for(var i = 0; i < adunits.length; i++) {
            if(adunits[i].adunit.id === adunit.id) {
              if(adunits[i].action === 'include')
                component.set('v.included', true);
              else
                component.set('v.excluded', true);
              break;
            }
          }
        }
      }
    } catch(e) {console.log(e.message);}
  }
});