({
  doInit: function(component, event, helper) {
    var targets = component.get('v.selectedMap');
    var adunit = component.get('v.adunit');
    helper.makeTargetsSelected(component);
  },
  handleMenuSelect: function(component, event, helper) {
    var action = event.getParam('value');
    if(action === 'include'){
      component.set('v.anyTargetIncluded', true);
      component.set('v.included', true);
    }
    else{
      component.set('v.anyTargetExcluded', true);
      component.set('v.excluded', true);
    }
    helper.fireSelectionEvent(component, action);
  },
  handleUnselection: function(component, event, helper) {
    var targets = component.get('v.selectedMap');
    var segments = component.get('v.segments');
    var eventSegments = event.getParam('segments');
    if(eventSegments !== segments) return;

    var item = event.getParam('item');
    var category = event.getParam('category');
    var parentCategory = event.getParam('parentCategory');
    var targets = component.get('v.selectedMap');
    var adunit = component.get('v.adunit');
    if(item.adunit.id === adunit.id) {
      if(item.action === 'include') {
        component.set('v.included', false);
      } else {
        component.set('v.excluded', false);
      }
    }
    if(!targets['Mobile application']){
      component.set('v.anyTargetIncluded', false);
      component.set('v.anyTargetExcluded', false);
    }

  }
});