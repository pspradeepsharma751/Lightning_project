({
    doInit: function(component, event, helper) {
        helper.doInit(component);
    },
	getPackageProduct : function(component, event, helper) {
		helper.getPackageProduct(component);
	},
    reloadPkgProductList : function(component, event, helper) {
        if(event.getSource().get("v.value") == 'Active')
        	component.set('v.displayPackageProductList', component.get('v.activePackageProductList'));
        else
            component.set('v.displayPackageProductList', component.get('v.inActivePackageProductList'));
		
        component.set('v.productStatusType', event.getSource().get("v.value"));
    },
    
    removeAtrribute : function(component, event, helper) {
		helper.removeAtrribute(component, event);
	},
    
    activateProductPkg : function(component, event, helper) {
		helper.activateProductPkg(component, event);
	},

	showHideModal : function(component, event, helper) {
		var isShowModal = component.get('v.showModal');
		var modalContainer = component.find('modalContainer');
		if(isShowModal) {
			$A.util.removeClass(modalContainer, 'slds-hide');
		} else {
			$A.util.addClass(modalContainer, 'slds-hide');
		}
	},
    
    getCompnent: function(component,event) {
        //Create component dynamically
        component.set('v.showModal', true);
        $A.createComponent(
            "c:PackageProductSelection",{
                "packageProductList":component.get("v.packageProductList"),
            },
            function(newcomponent){
                if (component.isValid()) {
                    var body = component.get("v.body");
                    body.push(newcomponent);
                    component.set("v.body", body);             
                }
            }            
        );
    },
    
	closeModal : function(component, event, helper) {
		component.set('v.showModal', false);
	},

	showModal : function(component, event, helper) {
		component.set('v.showModal', true);
	},
    
    showCurrentValues : function(component, event, helper) {
        helper.doInit(component);
		console.log('current product list => ', JSON.stringify(component.get('v.packageProductList')));
	}
})