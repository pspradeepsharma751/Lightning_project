({
    doInit: function(component) {
        var packageProductList = component.get('v.packageProductList');
        var activePackageProductList = [];
        var inActivePackageProductList = [];
        for (var index = 0; index < packageProductList.length; index++) {
            if(packageProductList[index].status == 'Active')
                activePackageProductList.push(packageProductList[index]);
            else
                inActivePackageProductList.push(packageProductList[index]);
        }
        component.set('v.activePackageProductList', activePackageProductList);
        component.set('v.inActivePackageProductList', inActivePackageProductList);
        if(component.get('v.productStatusType') == 'Active')
        	component.set('v.displayPackageProductList', activePackageProductList);
        else
            component.set('v.displayPackageProductList', inActivePackageProductList);
    },
    
    getPackageProduct : function(component) {
        var self = this;
        this.fetchData(component,'getPackageProducts',{
            'recordId': component.get('v.recordId')
        },
         function(packageProducts) {
             if(packageProducts) {       
                 component.set('v.packageProductList', packageProducts);
             }
         });
    },
    
    removeAtrribute : function(component, event) {
        var removeId = event.getSource().get('v.value');
        //var index = event.getSource().get('v.name');
        var packageProductList = JSON.parse(JSON.stringify(component.get('v.packageProductList')));
        for (var index = 0; index < packageProductList.length; index++) {
            if(packageProductList[index].id){
                if(packageProductList[index].id == removeId){
                    packageProductList[index].status = 'Archived';
                    //packageProductList[index].active = false;
                    break;
                }
            }else{
                 if(packageProductList[index].productId == removeId){
                    packageProductList[index].status = 'Archived';
                    //packageProductList[index].active = false;
                    break;   
                 }
            }
                
               
        }
        component.set('v.packageProductList', packageProductList);
        this.doInit(component);
    },
    
     activateProductPkg : function(component, event) {
        var activateProductPkgId =  event.currentTarget.dataset.id;
       // var index = event.getSource().get('v.name');
        var packageProductList = JSON.parse(JSON.stringify(component.get('v.packageProductList')));
        for (var index = 0; index < packageProductList.length; index++) {
           	if(packageProductList[index].id){
                if(packageProductList[index].id == activateProductPkgId){
                    packageProductList[index].status = 'Active';
                    //packageProductList[index].active = false;
                    break;
                }
            }else {
                if(packageProductList[index].productId == activateProductPkgId){
                    packageProductList[index].status = 'Active';
                    //packageProductList[index].active = false;
                    break;   
                 }
            }
               
        }
        component.set('v.packageProductList', packageProductList);
        this.doInit(component);
    },

})