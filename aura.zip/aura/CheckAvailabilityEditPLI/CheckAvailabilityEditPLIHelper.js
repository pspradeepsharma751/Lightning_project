({
    getAvailabilityForecast: function(component) {
        //var recordId = component.get('v.recordId');
        var objectData = JSON.parse(JSON.stringify(component.get('v.record')));
        objectData.adsalescloud__Start_Date__c = this.getDateObjectInSpecificTimezone(objectData.adsalescloud__Start_Date__c, objectData.adsalescloud__Time_Zone__c).getTime();
        objectData.adsalescloud__End_Date__c = this.getDateObjectInSpecificTimezone(objectData.adsalescloud__End_Date__c, objectData.adsalescloud__Time_Zone__c).getTime();
        component.set('v.itemName', component.get('v.record.Name'));
        component.set('v.startDate', component.get('v.record.adsalescloud__Start_Date_Time__c'));
        component.set('v.endDate', component.get('v.record.adsalescloud__End_Date_Time__c'));
        this.fetchData(component, 'checkAvailabilityPLIEdit',
                       {
                           lineItemObject:JSON.stringify(objectData),
                           isMaxAvailable: true
                       }, function(res) {
                           if(res.status === 'OK') {
                               component.set('v.data', res.data);
                               component.set('v.lineItemType', res.lineItemType.toLowerCase()); 
                           } else {
                               component.set("v.toast", {"message": res.message , "type" : "error", "closable" : true, "autoHide" : true});
                           }
                           component.set('v.showSpinner',false);
                       });
            },
    
    
})