({
    doInit : function(component, event, helper) {
        //alert("hello");
    },
    save : function(component, event, helper) {
        if(component.get("v.isAnythingChanged")){
            if(helper.validatePLI(component)){
                helper.confirm(component, "save", "Are you sure you want to save all changes?");
            }
        }
        else{ 
            $A.get("e.force:closeQuickAction").fire();
        }
    },
    perfomAction : function(component, event, helper) {
        var response = component.get("v.confirmationResponse");
        if(response.confirm){
            if(response.action === "save"){
                helper.save(component);
            }
            else
                helper.performAction(component, response.action);
            component.set("v.isAnythingChanged", true);
        }
    },
    cloneAction : function(component, event, helper) {
        if(helper.isItemSelected(component)){
            helper.confirm(component, "clone", "Are you sure you want to clone the selected proposal line items?");
        }
    },
    archiveAction : function(component, event, helper) {
        if(helper.isItemSelected(component)){
            helper.confirm(component, "archive", "Are you sure you want to archive the selected proposal line items?");
        }
    },
    unlinkAction : function(component, event, helper) {
        if(helper.isItemSelected(component)){
            helper.confirm(component, "unlink", "Are you sure you want to unlink the selected proposal line items?");
        }
    },
    deleteAction : function(component, event, helper){ 
        if(helper.isItemSelected(component)){
            if(helper.handleDeleteCase(component)){
                helper.confirm(component, "delete", "Are you sure you want to delete? This action cannot be undone.");
            }
        }
    },
    revertTargetingAction : function(component, event, helper) {
        if(helper.isItemSelected(component)){            
            helper.confirm(component, "revertTargeting", "Reverting sets proposal line item targeting to the product’s targeting. Any changes made to targeting are overwritten. <br><br>Are you sure you want to revert targeting for the selected proposal line items?");
        }
    },
    bulkEdit : function(component, event, helper) {
        if(helper.isItemSelected(component)){
            helper.performAction(component, "bulkEdit");
        }
    },
    flight : function(component, event, helper) {
        if(helper.isItemSelected(component)){
            helper.flightAction(component);
        }
    },
    refreshData : function(component, event, helper) {
        component.set("v.proposalLineItems", component.get("v.proposalLineItems"));
    },
    validate : function(component, event, helper) {
        helper.validate(component);
    },
    checkSelectedItem : function(component, event, helper){
        if(component.get("v.selectedItems") < 1){
            component.set("v.disableButtons", true);
        }
        else{
            component.set("v.disableButtons", false);
        }
    },
    handleNewFlightedPli : function(component, event, helper) {
        helper.handleNewFlightedPli(component);
    },
    close : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    },
    redirectToOpptunity : function(component, event, helper) {
        if(component.get("v.isClassic"))
            window.location.href = '/'+component.get("v.record.adsalescloud__Opportunity__r.Id");
        else{
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/"+component.get("v.record.adsalescloud__Opportunity__r.Id")
            });
            urlEvent.fire();
        }
    }
})