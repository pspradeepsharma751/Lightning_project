({
  fetchProductLineItems: function(component) {
    var action = component.get("c.getProposalLineItem");
    action.setParams({proposalId: component.get("v.recordId")});
    action.setCallback(this, function(response) {
        if(response.getState() === "SUCCESS") {
            console.log(response.getReturnValue());
            if(!$A.util.isEmpty(response.getReturnValue().propsalLineItems)){
                var timezoneIdList = new Set();
                response.getReturnValue().propsalLineItems.forEach(function(item, index) {
                    item.isSelected = false;
                    item.errors = {
                        "name": {"error": "", "msg": ""},
                        "start_date": {"error": "", "msg": ""},
                        "end_date": {"error": "", "msg": ""},
                        "quantity": {"error": "", "msg": ""},
                    };
                    item.index = index;
                    timezoneIdList.add(item.timezone);
                });
                this.initializeCloneInfo(component, response.getReturnValue().propsalLineItems);
                component.set("v.proposalLineItems", response.getReturnValue().propsalLineItems);
                component.set("v.productMap", response.getReturnValue().productMap);
                component.set("v.lineItemUrl", response.getReturnValue().lineItemUrl);
                //this.fetchTimezoneOffsetMinutes(component, Array.from(timezoneIdList));
                component.set('v.validationError', '');
            }
            else{
                component.set("v.validationError", "No proposal line items exist. Add Products to continue.");
                component.set('v.showButtonOnError', true);
                this.setStyle(component);
            }
            component.set("v.showSpinner", false);
        }
    });
    $A.enqueueAction(action);
  },/*
  fetchTimezoneOffsetMinutes: function(component, timezoneIdList) {
    var action = component.get("c.getAllTimezoneOffsetMinutes");
    action.setCallback(this, function(response) {
      if(response.getState() === "SUCCESS") {
        var itemList = component.get("v.proposalLineItems");
        itemList.forEach(function(item) {
          item.timezoneOffset = response.getReturnValue()[item.timezone];
        });
        component.set("v.timezoneOffsetMinutesMap", response.getReturnValue());
        component.set("v.proposalLineItems", itemList);
      }
      component.set("v.showSpinner", false);
    });
    $A.enqueueAction(action);
  },*/
  save: function(component) {
    component.set("v.showSpinner", true);
      component.set("v.disableButtons", true);
      
    var action = component.get("c.proposalProdutsEdit_Save");
    var modifiedPLIs = [];
    component.get("v.proposalLineItems").forEach(function(item) {
      if(item.isModified) {
        modifiedPLIs.push(item);
      }
    });
    action.setParams({proposalLineItemsJSON: JSON.stringify(modifiedPLIs), deleted_ProposalLineItems: component.get("v.deletedPliIDList")});
    action.setCallback(this, function(response) {
      if(response.getState() === "SUCCESS") {
        console.log(response.getReturnValue());
        if(response.getReturnValue().status === "ok") {
          this.showToast(component, null, "Success.", "success", 1000);
          $A.get('e.force:refreshView').fire();
          $A.get('e.force:closeQuickAction').fire();
        }
        else {
          this.showToast(component, null, "An error occured. " + response.getReturnValue().errorMessage, "error", 2000);
          console.log("An error occured. " + response.getReturnValue().errorMessage);
        }
      }
      else {
          this.showToast(component, null, "An error occured. ", "error", 1000);
          console.log("Errors: " + response.getError());          
          component.set("v.disableButtons", false);  
      }
      component.set("v.showSpinner", false);
    });
    $A.enqueueAction(action);
  },
  initializeCloneInfo: function(component, propsalLineItems) {
    var cloneInfo = new Map();
    propsalLineItems.forEach(function(item) {
      try {
        if(item.name.match(/[\w\s]+[_][\d]+/)[0] === item.name) {
          var originalName = item.name.substring(0, item.name.lastIndexOf("_"));
          var level = parseInt(item.name.substring(item.name.lastIndexOf("_") + 1));
          item.originalName = originalName;
          if(!cloneInfo.get(originalName)) {
            cloneInfo.set(originalName, {"cloneLevel": level, "occupiedEntries": [level], "availableEntries": []});
          }
          else {
            if(level > cloneInfo.get(originalName).cloneLevel)
              cloneInfo.get(originalName).cloneLevel = level;
            cloneInfo.get(originalName).occupiedEntries.push(level);
          }
        }
      }
      catch(e) {}
      if(!item.originalName) {
        item.originalName = item.name;
      }
    });
    cloneInfo.forEach(function(item) {
      var index = 1;
      for(index; index < item.cloneLevel; index++) {
        if(item.occupiedEntries.indexOf(index) == -1) {
          item.availableEntries.push(index);
        }
      }
    });
    component.set("v.cloneInfo", cloneInfo);
  },
  performAction: function(component, action) {
    component.set("v.showSpinner", true);
    var self = this;
    var pliList = component.get("v.proposalLineItems");
    var deleteList = component.get("v.deletedPliIDList");
    var selectedList = [];
    for(var index = 0; index < pliList.length; index++) {
      var item = pliList[index];
      item.index = index;
      if(item.isSelected) {
        selectedList.push(item);
        if(action === "clone")
          pliList.splice(index + 1, 0, self.clone(component, item));
        else if(action === "archive") {
          item.isArchived = true;
          self.showToast(component, null, "Line items will be archived on Save.", "success", 3000);
        }
        else if(action === "unlink") {
          self.unlink(item);
          self.showToast(component, null, "Proposal Line Items will be unlinked on save.", "success", 3000);
        }
        else if(action === "delete") {
          try {
            if(item.name.match(/[\w\s]+[_][\d]+/)[0] === item.name) {  // update cloneInfo
              var cloneInfo = component.get("v.cloneInfo");
              var originalName = item.name.substring(0, item.name.lastIndexOf("_"));
              var level = parseInt(item.name.substring(item.name.lastIndexOf("_") + 1));
              cloneInfo.get(originalName).availableEntries.push(level);
              cloneInfo.get(originalName).availableEntries.sort();
              component.set("v.cloneInfo", cloneInfo);
            }
          }
          catch(e) {}

          if(item.id) {
            deleteList.push(item.id);
          }
          pliList.splice(index, 1);
          index--;

          component.set("v.selectedItems", component.get("v.selectedItems") - 2);
        }
        else if(action === "revertTargeting") {
          self.revertTargeting(component, item);
          self.showToast(component, null, "Targeting Reverted.", "success", 3000);
        }
      }
    }
    if(action === "bulkEdit") {
      component.set("v.selectedPliList", selectedList);
      component.set("v.showBulkEdit", true);
    }
    component.set("v.proposalLineItems", pliList);
    component.set("v.deletedPliIDList", deleteList);
    component.set("v.showSpinner", false);
  },
  unlink: function(item) {
    item.linkStatus = "Unlinked";
    item.isModified = true;
    var inventorySizes = JSON.parse(item.inventorySize.replace(/&quot;/g, '\"'));
    var checkedInventorySizes = [];
    for(var i = 0; i < inventorySizes.length; i++) {
      if(inventorySizes[i].checkbox) {
        checkedInventorySizes.push(inventorySizes[i]);
      }
    }
    item.inventorySize = JSON.stringify(checkedInventorySizes);
  },
  clone: function(component, item) {
    var cloneInfo = component.get("v.cloneInfo") || new Map();
    var clone = {};
    Object.keys(item).forEach(function(key) {
      clone[key] = item[key];
    });
    clone.isSelected = false;
    delete clone.id;
    delete clone.adServerId;
    clone.errors = {
      "name": {"error": "", "msg": ""},
      "start_date": {"error": "", "msg": ""},
      "end_date": {"error": "", "msg": ""},
      "quantity": {"error": "", "msg": ""},
    };
    clone.originalName = item.originalName;

    if(cloneInfo.get(clone.originalName)) {
      var level;
      if(cloneInfo.get(clone.originalName).availableEntries.length > 0) {
        level = cloneInfo.get(clone.originalName).availableEntries[0];
        cloneInfo.get(clone.originalName).availableEntries.splice(0, 1);
      }
      else {
        cloneInfo.get(clone.originalName).cloneLevel++;
        level = cloneInfo.get(clone.originalName).cloneLevel;
      }
      clone.name = clone.originalName + "_" + level;
    }
    else {

      clone.name = clone.originalName + "_1";
      cloneInfo.set(clone.originalName, {"cloneLevel": 1, "availableEntries": []});
    }
    component.set("v.cloneInfo", cloneInfo);
    clone.isModified = true;
    component.set("v.isAnythingChanged", true);
    return clone;
  },
  revertTargeting: function(component, item) {
    var product = component.get("v.productMap")[item.productId];
    Object.keys(product).forEach(function(key) {
      if(key != 'id')
        item[key] = product[key];
    });
    item.isModified = true;
    component.set("v.isAnythingChanged", true);
  },
  flightAction: function(component) {
    if(component.get("v.selectedItems") > 2) {
      this.renderError(component, "Only 1 record may be selected to Flight");
    }
    else {
      var pliList = component.get("v.proposalLineItems");
      for(var index = 0; index < pliList.length; index++) {
        var item = pliList[index];
        if(item.isSelected) {
          var flight = {"item": item, "show": true, "flightedPliList": []};
          break;
        }
      }
      component.set("v.flight", flight);
    }
  },
  handleDeleteCase: function(component) {
    var pliList = component.get("v.proposalLineItems");
    var selectedList = [];
    let syncedSelected;
    let nonSyncedSelected;
    for(var index = 0; index < pliList.length; index++) {
      var item = pliList[index];
      if(item.isSelected) {
        if(item.adServerId != null) {
          syncedSelected = true;
        }
        else {
          nonSyncedSelected = true;
        }
        selectedList.push(item);
      }
    }
    if(syncedSelected && nonSyncedSelected) {
      this.renderError(component, "Delete is not allowed for synced line items. Unselect any synced line items before clicking Delete.");
      return false;
    }
    return true;
    /*
    if(selectedList.length == 1 && selectedList[0].adServerId){
        selectedList[0].isSelected = false;
        component.set("v.proposalLineItems", pliList);
        component.set("v.selectedItems",0);
    }*/
  },
  validate: function(component) {
    var proposal = component.get('v.record');
    if(proposal.adsalescloud__Status__c != 'Draft' && proposal.adsalescloud__Status__c != 'Draft (sold)') {
      component.set('v.validationError', 'Edit Products is not allowed unless the Proposal Status is Draft. Please retract the proposal to continue.');
    }
    else if($A.util.isEmpty(proposal.adsalescloud__Opportunity__r)) {
      component.set('v.validationError', 'Edit Products requires the Proposal’s Opportunity is configured. Please set the Opportunity and try again.');
    }
    else if($A.util.isEmpty(proposal.adsalescloud__Opportunity__r.Pricebook2Id)) {
      component.set('v.validationError', 'Edit Products requires the Proposal’s Opportunity is first configured with a Price Book. Click OK to navigate to the Opportunity and set its Price Book or click Cancel to return to the Proposal.');
      component.set('v.showButtonOnError', true);
    }
    else {
      component.set('v.validationError', '');
      //this.fetchTimezoneOffsetMinutes(component);
      this.fetchProductLineItems(component);
    }
      this.setStyle(component);
      if($A.util.isEmpty(component.get('v.validationError'))){
         component.set('v.validationError', '  ');
      }
  },
  validatePLI: function(component) {
    var proposalLineItems = component.get("v.proposalLineItems");
    var error;
    proposalLineItems.forEach(function(item, index) {
      if(item.isModified) {
        var timezone = item.timezone;
        var currentDate = Date.parse(new Date(new Date().getTime()).toLocaleString('en-US', {timeZone: timezone}));
        var startDate = Date.parse(new Date(item.start_date).toLocaleString('en-US', {timeZone: timezone}));
        var endDate = Date.parse(new Date(item.end_date).toLocaleString('en-US', {timeZone: timezone}));
        item.errors = {
          "name": {"error": "", "msg": ""},
          "start_date": {"error": "", "msg": ""},
          "end_date": {"error": "", "msg": ""},
          "quantity": {"error": "", "msg": ""},
        };
        if(endDate < startDate) {
          item.errors.end_date.msg = error = 'End Date must be greater than Start Date.';
        }
        else if(!item.adServerId) {
          if(!item.isFlighted && startDate < currentDate) {
            item.errors.start_date.msg = error = 'Start Date cannot be in the past.';
          }
        }
        if(endDate < currentDate) {
          item.errors.end_date.msg = error = 'End Date cannot be in the past.';
        }
        if((item.lineItemType === 'Price Priority' || item.lineItemType === 'Click Tracking Only')) {
          if(item.quantity < 0)
            item.errors.quantity.msg = error = "Minimum value 0";
        }
        else {
          if(item.quantity < 1)
            item.errors.quantity.msg = error = "Minimum value 1";
        }
      }
    });
    component.set("v.proposalLineItems", []);
    component.set("v.proposalLineItems", proposalLineItems);
    if(error) {
      this.renderError(component, "Please review and fix errors and try again.");
      return false;
    }
    return true;
  },
  handleNewFlightedPli: function(component) {
    var proposalLineItems = component.get("v.proposalLineItems");
    var flightedPliList = component.get("v.flightedPliList");
    var selectedItemIndex;
    for(var index = 0; index < proposalLineItems.length; index++) {
      if(proposalLineItems[index].isSelected) {
        selectedItemIndex = index;
        proposalLineItems[index].isModified = true;
        proposalLineItems[index].isFlighted = true;
        break;
      }
    }
    flightedPliList.forEach(function(item) {
      item.isSelected = false;
      item.isModified = true;
      item.id = null;
      proposalLineItems.splice(selectedItemIndex + 1, 0, item);
      selectedItemIndex++;
    });
    component.set("v.proposalLineItems", []);  // it helps to refresh all content.
    component.set("v.proposalLineItems", proposalLineItems);
    component.set("v.isAnythingChanged", true);
  },
  setStyle: function(component) {
    var style = '';
    if($A.util.isEmpty(component.get('v.validationError'))) {
      style = '.slds-modal__container { margin: 0 auto;width: 70% !important; max-width: 80% !important; min-width: 40rem; height: 92%; } .slds-modal__content{ padding: 0 !important; border-radius: .4em; overflow: auto; } .slds-modal__close { width: 2rem; height: 2rem; top: -1.8rem!important; right: -.5rem;} /*.form-element__help {margin-top: 0 !important;}*/';
      if(!component.get('v.isClassic')) {
        style = style + ' body{ font-size: .8125rem !important;  font-family: \'Salesforce Sans\',Arial,sans-serif !important; color: #222 !important; } .slds-modal__container { padding-top: 90px !important; }  .slds-modal__header {  left: 0; } .slds-modal__close { top: -5.5rem !important; } .primaryFieldRow{ height: 45px; } ' +
          '.slds-modal__header--empty { padding: 0 !important; } .container{  padding : 0 !important; } .slds-modal__header{ /*height : 57px !important;*/ } h2{  font-size: 1em !important; margin-bottom : 0 !important; } p{ margin: 0 !important; padding: 0 !important; } .slds-modal__close {top: -4.5rem !important;} ' +
          '.cuf-content {padding: 0rem !important;} .toastMessage {top: 14.5%!important;} .toastMessage {top: 8.5em!important;}';
      }
      else {
        style = style + '.toastMessage {top: 14.5% !important;}';
      }
    }
    else {
      style = '.slds-modal__content { height: 200px !important; min-height: 200px !important; } .slds-modal__container { min-width: 45rem !important} .toastMessage {position: relative !important;} ';
      if(component.get('v.isClassic')) {
        style += ' .slds-modal__close { top: -4.5rem !important; }';
      }
      component.set("v.showSpinner", false);
      component.set("v.toast", {"message": "Error: Edit Products", "type": "error", "closable": false, "autoHide": false});
    }
    style = '<style>' + style + '</style>';
    component.set('v.style', style);
  },
  isItemSelected: function(component) {
    if(component.get("v.selectedItems") > 0) {
      return true;
    }
    else {
      this.renderError(component, "Please select at least 1 product and try again.");
      return false;
    }
  },
  confirm: function(component, action, message) {
    component.set("v.confirmAction", action);
    component.set("v.confirmationMessage", message);
    component.set("v.showConfirmationBox", true);
  },
  renderError: function(component, errorMessage) {
    this.showToast(component, 'Error', errorMessage, 'error');
  },
  showToast: function(component, title, message, type, timeout) {
    component.set("v.toast", {"message": message, "type": type, "closable": true, "autoHide": true, "timeout": timeout});
  },
});