({
	myAction : function(component, event, helper) {
		
	},
    bufferChangeHandler : function(component, event, helper) {
		
	},
    dateChangeHandler : function(component, event, helper) {
		var item = component.get("v.item");
        var startDate = new Date(item.start_date.value);
        var endDate = new Date(item.end_date.value);
        if(endDate < startDate){
            startDate.setDate(startDate.getDate() + 1);
            item.end_date.value = startDate.toISOString();
            component.set("v.item", item);
            helper.refreshDateTimeComponents(component);
        }
	},
    confirm : function(component, event, helper) {
        if(helper.validate(component)){
            helper.confirm(component);
        }
	},
    showField : function(component, event, helper) {
		var field = event.currentTarget.dataset.fieldName;
        component.set("v.item."+field+".isVaries", false );
	},
    doInit : function(component, event, helper) {
		helper.doInit(component);
	},
     close : function(component, event, helper) {
		component.set("v.show", false);
	},
    handleTimezoneChange : function(component, event, helper) {
       helper.handleTimezoneChange(component);
    },
})