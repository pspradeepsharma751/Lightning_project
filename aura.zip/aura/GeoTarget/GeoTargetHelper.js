({
  timeout: null,
  getGeoTargets: function(component, allCountries) {
    var offset = component.get('v.offset');
    var limit = component.get('v.limit');
    var searchTerm = component.get('v.searchTerm');
    searchTerm = (searchTerm && searchTerm.trim()) ? searchTerm.trim() : null;
    this.fetchData(component, 'getGeoTargets', {
      'page_size': limit,
      'offset': (offset * limit),
      'parentId': null,
      'searchTerm': searchTerm,
      'showPopularCountries': allCountries
    }, function(res) {
      if(res.status === 'OK') {
        var oldTargets = component.get('v.popularCountries') ? [] : component.get('v.targets');
        var newTargets = res.geoTargets;
        if(newTargets.length > 0) {
          component.set('v.targets', oldTargets.concat(res.geoTargets));
          if(newTargets.length === limit && !allCountries) {
            component.set('v.offset', ++offset);
            component.set('v.showMore', true);
          }
          else
            component.set('v.showMore', false);
        }
        component.set('v.popularCountries', allCountries);
        component.set('v.error', '');
      } else {
        component.set('v.error', res.msg);
      }
    });
  },
  searchGeography: function(component) {
    var self = this;
    var term = component.get('v.searchTerm');
    if(term && term.trim()) {
      component.set('v.targets', []);
      component.set('v.searchEnabled', true);
      component.set('v.offset', 0);
      clearTimeout(self.timeout);
      self.timeout = setTimeout($A.getCallback(function() {
        self.getGeoTargets(component, false);
      }), 500);
    } else if(component.get('v.searchEnabled')) {
      component.set('v.targets', []);
      component.set('v.offset', 0);
      component.set('v.searchEnabled', false);
      clearTimeout(self.timeout);
      self.timeout = setTimeout($A.getCallback(function() {
        self.getGeoTargets(component, false);
      }), 500);
    }
  },
  validatePostCodeOnDFP: function(component){
    var self = this;
    var postalCodes = component.get('v.postal_codes');
    var selectedPostalCodes = component.get('v.selectedPostalCodes');
    var selectedCountryCode = component.get('v.selectedCountryCode');
    self.fetchData(component, 'checkPostCodesOnDFP', {
      'postalCodes': postalCodes,
      'countryCode': selectedCountryCode
    }, function(res) {
      if(res.targets.length > 0){
        for(var i=0;i < res.targets.length;i++){
          if(selectedPostalCodes.indexOf(res.targets[i].id) !== -1) continue;
          self.fireEvent(component,res.targets[i]);
        }
        component.set('v.postal_codes',res.invalidPostCodes.join());
      }
      if(res.invalidPostCodes.length > 0){
        component.set('v.invalidPostalcodesError',true);
      }else component.set('v.invalidPostalcodesError',false);
    });
  },
  fireEvent: function(component, adunit) {
    var includeExcludeEvent = $A.get('e.c:TargetingEvent');
    includeExcludeEvent.setParams({
      'adunit': adunit,
      'action': 'include',
      'segments':component.get('v.segments'),
      'category': 'Geography',
      'sub_category': null
    });
    includeExcludeEvent.fire();
  }
});