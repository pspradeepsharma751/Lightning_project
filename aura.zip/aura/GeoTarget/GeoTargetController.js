({
  doInit: function(component, event, helper) {
    var selectedPostalCodes = [];
    var targets = component.get('v.selectedMap');
    if(targets) {
      var items = targets['Geography'];
      if(items) {
        var keys = Object.keys(items);
        keys.forEach(function(key) {
          var pArr = items[key];
          for(var i=0;i<pArr.length;i++){
            if(pArr[i].adunit.type === 'POSTAL_CODE'){
              selectedPostalCodes.push(pArr[i].adunit.id);
            }
          }
        });
      }
    }
    component.set('v.selectedPostalCodes',selectedPostalCodes);
    helper.getGeoTargets(component, true);
  },
  loadMore: function(component, event, helper) {
    helper.getGeoTargets(component, false);
  },
  showAllCountries: function(component, event, helper) {
    helper.getGeoTargets(component, false);
  },
  searchGeographyHandler: function(component, event, helper) {
    helper.searchGeography(component);
  },
  validatePostalCode: function(component, event, helper) {
    var postalCodes = component.get('v.postal_codes');
    if(postalCodes)
      helper.validatePostCodeOnDFP(component);
  }
});