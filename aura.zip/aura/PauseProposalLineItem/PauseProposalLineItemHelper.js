({
    doInit : function(component) {  
        var self = this;
        if($A.util.isEmpty(component.get("v.record"))){
            window.setTimeout(function(){
                self.doInit(component);            
            },40);
        }
        else{
            component.set("v.showSpinner", false);
            var dfpStatus = component.get("v.record.adsalescloud__DFP_Order_Line_Item_Status__c");
            if(!(dfpStatus == "Ready" || dfpStatus == "Delivering")){
                component.set("v.hideUserPrompt", true);
                /*component.set("v.message", "Pause is only allowed if DFP Order Line Item Status is Ready or Delivering.");
                component.set("v.messageType", "info");*/
            }
        }
    },
    doAction : function(component){
        var action = component.get("c.pausePLI");
        action.setParams({
            "objectId" : component.get("v.recordId"),
            "action" : "pause"
        });
        action.setCallback(this, function(response){
            component.set("v.showSpinner", false);
            
            if(response.getState() === "SUCCESS"){
                var toastEvent = $A.get('e.force:showToast');
                toastEvent.setParams({
                    'title': 'Success!',
                    'type': 'success',
                    'message': 'Proposal line item paused succesfully.'
                });
                toastEvent.fire();
                $A.get('e.force:refreshView').fire();
                $A.get('e.force:closeQuickAction').fire();
                //component.set("v.message", "Proposal line item paused succesfully.");
               // component.set("v.messageType", "success");
            }else{
               component.set("v.showToast",true);
                component.set("v.message", "An error occured while pausing the Proposal line item.");
                component.set("v.messageType", "error");
            }
        });
        $A.enqueueAction(action);
    },
})