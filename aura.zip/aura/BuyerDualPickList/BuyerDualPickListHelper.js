({
    doInit : function(component) {
        var object = component.get("v.record");
        //component.set("v.showSpinner",true);
        var textDataFieldName = component.get('v.textDataFieldName');
        var selectedoptionName = component.get('v.selectedoptionName');
        var action=component.get("c.getProgammaticBuyer");
        action.setParams({
            'programmaticType': component.get('v.record.adsalescloud__Programmatic_Type__c'),
            'searchTerm': component.get('v.searchTerm'),
            'selectedOption' : component.get('v.record.adsalescloud__Programmatic_Buyer_Details__c')
        });
		action.setCallback(this, function(response){
			if(response.getState()==='SUCCESS'){
				var result=JSON.parse(response.getReturnValue());
                if(result.status== "Success"){
                        var optionList = [];
                        var allOptions = new Map();
                        var buyerList = result.value;
                        if(buyerList.length > 0){
                            buyerList.forEach(function(value, index){
                                optionList.push({"value" : value.key, "label" : value.label});
                                allOptions.set(value.key,value);
                                if(object[textDataFieldName] == value.key){
                                    selectedoptionName.push(value.label);
                                    component.set('v.selectedoptionName', selectedoptionName);
                                }
                            });
                        } 
                        
                        component.set("v.allOptions",allOptions);
                        component.set("v.availableOptions",optionList);
                        this.updateSelectedOptions(component);
                        this.updateSelectedOptionValue(component);
                    } else{
                        console.log('ERROR:\nCallout to fetch list of labels has been failed.');
                    }
                } else {
                    console.log("You have uncommitted work pending. Please commit or rollback before calling out");
                }
            	 component.set("v.showBuyerSpinner",false);
				
		});
		$A.enqueueAction(action);
	},
	initialize : function(component) {
        var object = component.get("v.record");
		var jsonData = {};
		var jsonDataMap = new Map();
        var textDataFieldName = component.get('v.textDataFieldName');
        if(!$A.util.isEmpty(textDataFieldName)){
            if(!$A.util.isEmpty(object[textDataFieldName])){
                jsonData = JSON.parse(object[textDataFieldName].replace(/<br>|\s\s|{\s|\s}|\[\s|\s\]/g,"").replace(/&quot;|“|”/g,"\""));
                jsonData.forEach(function(value,index){		// creating map of json objects
                    jsonDataMap.set(value.labelId, value);
                });
            }
            component.set("v.jsonData", jsonDataMap);
        }
        this.updateSelectedOptions(component);
	},
    updateSelectedOptions : function(component){
        var object = component.get("v.record");
        var selectedOptions = [];
        var selectedoptionName = [];
        var textDataFieldName = component.get('v.textDataFieldName');
        if(object && !$A.util.isEmpty(object[textDataFieldName])){
            object[textDataFieldName] = object[textDataFieldName].replace(/,\s/g,',');
            selectedOptions = object[textDataFieldName].split(",");
        }
        component.set("v.selectedOptions",selectedOptions);
    },
	updateSelectedOptionValue : function(component){
		var recordObject = component.get("v.record");
		var selectedOptions = component.get("v.selectedOptions");
        var textDataFieldName = component.get('v.textDataFieldName');
        var richTextDataFieldName = component.get('v.richTextDataFieldName');
        var modalType = component.get('v.modaltype');
		if(!$A.util.isEmpty(selectedOptions)){	// setting for textfield on recordObject
			recordObject[textDataFieldName] = selectedOptions.join(', ');
            //component.set('v.selectedoptionName', selectedOptions.join(', '));
        } 
       	var optionList = component.get("v.availableOptions");
         var selectedoptionName = [];
        if(selectedOptions[0]){
            for(var i = 0; i < optionList.length; i++){
                if(selectedOptions[0] == optionList[i].value){
                    selectedoptionName.push(optionList[i].label);
                    component.set('v.selectedoptionName', selectedoptionName);
                    
                    break;
                } 
            }
        } else
            component.set('v.selectedoptionName', selectedoptionName);
       
        component.set("v.record."+textDataFieldName, selectedOptions[0] ? recordObject[textDataFieldName] : null);
        component.set("v.record.adsalescloud__Programmatic_Buyer__c", selectedoptionName[0]);
        
    },
   
})