({
	fireCheckAllCheckBoxEvent : function(compEvent, event) {
		var target = event.getSource();
		var compEvent = $A.get("e.c:ProductSelectionRowEvent");    
        compEvent.setParams({"target" : target});
        console.log('target ==> ' + JSON.stringify(target));
        compEvent.fire();
	},

	showHidePackageProduct : function(component, event) {
		var isVisible = component.get('v.isVisible');
		var iconName = 'utility:add';
		
		if(!isVisible) {
			iconName = 'utility:dash';
		}
		
		component.set('v.iconName', iconName);
		component.set('v.isVisible', !isVisible);
	},

	checkUncheckParent : function(component, event) {
		//var isParentChecked = component.get('v.isParentChecked');
		var isProductChecked = component.get('v.productPackageCandidate.isSelected');

		if(!isProductChecked) {
			component.set('v.isParentChecked', false);
		}
	}
})