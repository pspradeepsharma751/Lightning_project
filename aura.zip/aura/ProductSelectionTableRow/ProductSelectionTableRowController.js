({
	checkAllCheckBoxes : function(component, event, helper) {
		helper.fireCheckAllCheckBoxEvent(component, event);
	},

	showHidePackageProduct : function(component, event, helper) {
		helper.showHidePackageProduct(component, event);
	},
	checkUncheckParent : function(component, event, helper) {
		helper.checkUncheckParent(component, event);
  },
  checkAvailability: function(component,event,helper) {
    var flag = component.get('v.showModal');
    flag = !flag;
    component.set('v.showModal', flag);
  },
})