({
    doInit:function(component, event, helper){
        helper.doInit(component);
    }   
})