({
    doInit : function(component){
        var actionToFetchPackageFields = component.get('c.getProductRecord');
        actionToFetchPackageFields.setParams({
            "recordId": component.get("v.recordId")
        });
        actionToFetchPackageFields.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                
                var result = JSON.parse(response.getReturnValue());
                component.set("v.productCustomAttrDetails", result.objectData.adsalescloud__Ad_Sales_Product_Template__r);
                component.set("v.video_enabled", result.video_enabled);
                component.set("v.record",result.objectData);
                
            }
            else if (state === "ERROR") {
                var errorMessage = response.getError()[0].message;
            }
        });
        $A.enqueueAction(actionToFetchPackageFields);
        
    }
   
})