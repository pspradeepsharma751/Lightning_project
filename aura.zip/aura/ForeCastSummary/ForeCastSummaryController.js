({
    doInit: function(component, event, helper) {
        
        var data = component.get('v.data');
        var goalType = component.get('v.goalType').toLowerCase();
        var lineItemType = component.get('v.lineItemType').toLowerCase();
        var items = [];
        if(goalType === 'max_available')
            items.push({'name': 'Available', 'value': (data.availableUnits || 0), 'color': '#008000', 'percent': (data.availableUnits || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' : 'background:#008000;'});  
        if(goalType === ('goal'))
        {
            items.push({'name': 'Delivered', 'value': (data.delivered || 0), 'color': '#000000', 'percent': (data.delivered || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' : 'width:'+ (data.delivered || 0) * 100 / data.matched_capacity +'%;background:#000000'});
            items.push({'name': 'Likely to deliver', 'value': (data.likelyToDeliver || 0), 'color': '#008000', 'percent': (data.likelyToDeliver || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' : 'background:#008000;'});
            if(lineItemType === ('standard'))
            {	
                items.push({'name': 'Likely to deliver, but may impact same or lower priority items', 'value': (data.likelyToDeliver_lower || 0), 'color': '#fcdc75', 'percent': (data.likelyToDeliver_lower || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' : 'background:#fcdc75;'});
            }
            items.push({'name': 'Unlikely to deliver', 'value': (data.unlikelyToDeliver || 0), 'color': '#ea4d50', 'percent': (data.unlikelyToDeliver || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' :'background:#ea4d50;'});
        }
        if(lineItemType === ('standard'))
        {
        	items.push({'name': 'Remaining unreserved impressions', 'value': (data.remaining_unreserved_imps || 0), 'color': '#FFFFFF', 'percent': (data.remaining_unreserved_imps || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' : 'background:#FFFFFF;'}); 
            items.push({'name': 'Reserved by same or lower priority line items', 'value': (data.reservedUnits_lower || 0), 'imageUrl': '/resource/adsalescloud__Ad_Sales_Cloud_Resources/Images/slantLineBox.png', 'percent': (data.reservedUnits_lower || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' : 'background:url(/resource/adsalescloud__Ad_Sales_Cloud_Resources/Images/slantLineBox.png);'});
        }
        if(lineItemType === ('sponsorship'))
            items.push({'name': 'Additional impressions available to reserve without causing overweight', 'value': (data.additionalImpressions || 0), 'color': '#FFFFFF', 'percent': (data.additionalImpressions || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' : 'background:#FFFFFF;'}); 
        
        items.push({'name': 'Unavailable', 'value': (data.unavailableUnits || 0), 'imageUrl': '/resource/adsalescloud__Ad_Sales_Cloud_Resources/Images/crossStyleBox.png', 'percent': (data.unavailableUnits || 0) * 100 / data.matched_capacity, 'showInBar': true, 'itemStyle' : 'background:url(/resource/adsalescloud__Ad_Sales_Cloud_Resources/Images/crossStyleBox.png);'});
        items.push({'name': 'Matched capacity', 'value': (data.matched_capacity || 0), 'color': '', 'percent': 0, 'showInBar': false});
        component.set('v.items', items); 
        var left,width, matched_capacity;
		left = width = 0;
		matched_capacity = data.matched_capacity;
        for(var i = 0; i < items.length; i++){ 
			var value = items[i].value;
			left = left + width;
			//items[i].itemStyle = items[i].itemStyle + '; left:' + left + '%;';
			width = (value * 100) / matched_capacity;
            
			items[i].itemStyle = items[i].itemStyle + ' ;width:' + width + '%;';
			if(items[i].name === 'Available' || items[i].name === 'Likely to deliver')
				items[i].itemStyle = items[i].itemStyle + 'float:left;';
				
		}
        component.set('v.items', items);
        var message = component.get('v.message') || {};
        var quantity = component.get('v.quantity');
        var unitType = component.get('v.unitType');
        if(goalType === ('max_available'))
        {
            message.titleMessage = 'Maximum of ' + parseInt(data.availableUnits).toLocaleString() + ' ' + unitType +' are available';
            message.styleClass = 'availableData';
        }
        else if(goalType === ('goal'))
        {
            if(!$A.util.isEmpty(quantity) && data.availableUnits >= quantity )
            {
                message.titleMessage = 'Goal of ' + parseInt(quantity).toLocaleString() +' '+ unitType + ' is likely to deliver';
                message.styleClass = 'availableData';
            }
            else
            {
                message.titleMessage = 'Not enough available units to reach goal of ' + parseInt(quantity).toLocaleString();
                message.styleClass = 'notEnoughData';
            }
        }
        component.set('v.message', message)
    }
})