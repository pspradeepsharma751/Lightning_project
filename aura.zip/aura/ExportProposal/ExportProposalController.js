({
  doInit: function(component, event, helper) {
    component.set('v.cval', '<style>.slds-modal__container{min-width: 80rem;}section .panel .closeIcon{display:none} .slds-modal__content{overflow: scroll;}</style>');
    var recordId = component.get('v.recordId');
    var today = $A.localizationService.formatDate(new Date(), "MM/DD/YYYY");
    component.set('v.today', today);

    // component.set('v.attachmentUrl', '/apex/adsalescloud__ExportProposal?id=' + recordId);
    /* window.setTimeout(
      $A.getCallback(function() {
        $A.get('e.force:closeQuickAction').fire();
      }), 5000
    ); */

    var action = component.get('c.getExportProposalRecord');
    action.setParams({
      recordId: recordId,
      oppRecId: ''
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if(state === 'SUCCESS') {
        var record = JSON.parse(response.getReturnValue());
        var proposalRecord = record.proposalRecord;
        var startDateTime = proposalRecord['adsalescloud__Start_Date__c'];
        if(startDateTime) {
          var startFormattedDate = $A.localizationService.formatDate(startDateTime, 'MM/DD/YYYY');
          component.set('v.startdate', startFormattedDate);
        }

        var endDateTime = proposalRecord['adsalescloud__End_Date_Time__c'];
        if(endDateTime) {
          var endDateFormattedDate = $A.localizationService.formatDate(endDateTime, 'MM/DD/YYYY');
          component.set('v.enddate', endDateFormattedDate);
        }

        var pliRecordList = record.lineItemsList;
        for(var key in pliRecordList) {
          pliRecordList[key]['adsalescloud__Start_Date__c'] = $A.localizationService.formatDate(pliRecordList[key]['adsalescloud__Start_Date__c'], 'MM/DD/YYYY');
          pliRecordList[key]['adsalescloud__End_Date__c'] = $A.localizationService.formatDate(pliRecordList[key]['adsalescloud__End_Date__c'], 'MM/DD/YYYY');
          component.set('v.totalCost', component.get('v.totalCost') + pliRecordList[key]['adsalescloud__Total_Cost__c']);
        }
        component.set('v.lineItemsList', record.lineItemsList);
        component.set('v.proposal', proposalRecord);
        // setTimeout(helper.tableToExcel('testTable', 'W3C Example Table'), 40000);
      }
      else if(state === 'INCOMPLETE') {
        // do something
      }
      else if(state === 'ERROR') {
        var errors = response.getError();
        if(errors) {
          if(errors[0] && errors[0].message) {
            console.log('Error message: ' + errors[0].message);
          }
        } else {
          console.log('Unknown error');
        }
      }
    });
    $A.enqueueAction(action);
  },
  onCancel: function(component, event, helper) {
    $A.get('e.force:closeQuickAction').fire();
  },

});