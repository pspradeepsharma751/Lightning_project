({
	checkProposalSync : function (component, event, helper) {
        var isMasterProposal = component.get("v.proposalRecordFields.adsalescloud__Primary_Proposal__c");
        var associatedAccoundDoubleClickId = component.get("v.proposalRecordFields.adsalescloud__Ad_Server_Account_Id__c");
        var isProgrammatic = component.get("v.proposalRecordFields.adsalescloud__isProgrammatic__c");
        //var readyForDFPInfo = component.get('v.readyForDFPInfo');
        component.set("v.sObjectName", "Proposal");
         if(isMasterProposal == undefined || isMasterProposal == null || !isMasterProposal) {
            component.set("v.showToast",true);
            component.set("v.message", "This Proposal requires setting the primary proposal field.");
            component.set("v.status",$A.get("$Label.c.ERROR"));
        } else if(associatedAccoundDoubleClickId == undefined || associatedAccoundDoubleClickId == null) {
            component.set("v.showToast",true);
            component.set("v.message","This Proposal requires the related opportunity\'s account field set. Please set the related opportunity\'s account.");
            component.set("v.status",$A.get("$Label.c.ERROR"));
        }
        else if((component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Draft" &&
                component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Rejected" &&
                component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Draft (sold)" &&
                component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Rejected (sold)" &&
                component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Pre-Approved" && 
                component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Pre-Approved (sold)")&& !isProgrammatic) {
            component.set("v.showToast",true);
            component.set("v.message","This Proposal requires the status field set to Draft/Pre-Approved/Rejected/Draft (sold)/Pre-Approved (sold)/Rejected (sold).");
            component.set("v.status",$A.get("$Label.c.ERROR")); 
        } 
        else if((component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Draft" &&
                component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Rejected" &&
                component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Draft (sold)" &&
                component.get("v.proposalRecordFields.adsalescloud__Status__c") != "Rejected (sold)")&& isProgrammatic) {
            component.set("v.showToast",true);
            component.set("v.message","This Proposal requires the status field set to Draft/Rejected/Draft (sold)/Rejected (sold).");
            component.set("v.status",$A.get("$Label.c.ERROR")); 
        } 
    },
})