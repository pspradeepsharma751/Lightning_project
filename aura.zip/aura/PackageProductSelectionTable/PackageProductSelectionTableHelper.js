({
  checkAllCheckBoxes: function(selectedProductMap, currentRecords, checked) {
    for(var key in currentRecords) {
        if(key != 'remove'){
            currentRecords[key].isSelected = checked;
            this.checkOneUnit(selectedProductMap, currentRecords[key].id, checked);
        }
      
    }
  },
  checkOneUnit: function(selectedProductMap, recordId, checked) {
    selectedProductMap[recordId] = checked;
  },
  checkIfNeedToCheckAllCheckBoxes: function(selectedProductMap, currentRecords) {
    var checkAllBox = true;
    for(var key in currentRecords) {
      if(!selectedProductMap[currentRecords[key].id]) {
        checkAllBox = false;
      }
    }
    return checkAllBox;
  },
  createProducts: function(component) {
    var createProducts = $A.get('e.c:ProductPackageEditEvent');
    var selectedProductMap = component.get('v.selectedProductMap');
    var packageProductList = component.get('v.packageProductList');
    var productList = component.get('v.productList');
    var selectedProducts = [];

    for(var key in productList) {
      var productObj = productList[key];
      if(selectedProductMap[productObj.id]) {
        productObj.id = '';
        selectedProducts.push(productObj);
      }
    }
    packageProductList = packageProductList.concat(selectedProducts);
    component.set('v.packageProductList', packageProductList);
    createProducts.setParams({
      'isSetProduct': true,
      'packageProductList': selectedProducts
    });
    createProducts.fire();
    this.removeComponent(component);

  },
  removeComponent: function(component, event) {
    component.set('v.isDestroy', true);
  }
});