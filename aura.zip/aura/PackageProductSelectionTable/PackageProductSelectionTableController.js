({
     updateSelectedItems : function(component, event, helper){
        var selectedProductMap = component.get("v.selectedProductMap");
        var count = 0;
        for(var key in selectedProductMap){
            if(selectedProductMap[key]){
                count++;
            }
        }
        component.set("v.selectedItemNum", count);
    },

    clearSelectedItems : function(component, event, helper){   
        component.set("v.selectedProductMap", {});
        component.set("v.checkedAll",false);
        component.set('v.showSpinner', false);
    },

    checkAllCheckBoxes : function(component, event, helper){   
        var selectedProductMap = component.get("v.selectedProductMap");
        if(!selectedProductMap){
            selectedProductMap = {};
        }

        var currentRecords = component.get("v.productListOnCurrentPage");
        var target = event.getSource();
        var checked = target.get("v.value");

        if(target.get("v.name") === "selectAll"){
            helper.checkAllCheckBoxes(selectedProductMap, currentRecords, checked);
            component.set("v.productListOnCurrentPage", currentRecords);
        }else{
            var recordId = target.get("v.name");                
            helper.checkOneUnit(selectedProductMap, recordId, checked);
            component.set("v.checkedAll", helper.checkIfNeedToCheckAllCheckBoxes(selectedProductMap,currentRecords));
        }
        component.set("v.selectedProductMap", selectedProductMap);
    },

     autoUpdateCheckBox : function(component, event, helper){
        var selectedProductMap = component.get("v.selectedProductMap");
        if(!selectedProductMap){
            selectedProductMap = {};
        }
        var currentRecords = component.get("v.productListOnCurrentPage");
        component.set("v.checkedAll",  helper.checkIfNeedToCheckAllCheckBoxes(selectedProductMap,currentRecords));
    },

     toggleFilterBar : function(component, event, helper){
        console.log('toggleFilterBar in child ');
        var showFilter = component.get("v.showFilterBar");
        showFilter = !showFilter;
        component.set("v.showFilterBar", showFilter);
    },

    updateFilterListStyle : function(component){
        var showFilter = component.get("v.showFilterBar");
        if(showFilter){
            $A.util.addClass(component.find("filterList"),"slds-is-selected");
        }else{
            $A.util.removeClass(component.find("filterList"),"slds-is-selected");            
        }
    },

    createProducts : function(component, event, helper) {
        helper.createProducts(component);
    },

    closeModal: function(component, event, helper) {
      helper.closeModal(component);
    },
    
    removeComponent:function(component,event, helper){
        helper.removeComponent(component, event);
    },
})