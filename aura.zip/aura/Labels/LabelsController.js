({
    doInit : function(component, event, helper) {
		helper.doInit(component);
	},
	showModal : function(component, event, helper) {
		component.set("v.showModal",true);
	},
	closeModal : function(component, event, helper) {
		component.set("v.showModal",false);
	},
	updateJson : function(component, event, helper) {
		helper.updateJson(component);
	},
    updateCompanyLabels : function(component, event, helper) {
		helper.updateCompanyLabels(component);
	},
})