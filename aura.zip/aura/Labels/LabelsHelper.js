({
    doInit : function(component) {
		var action=component.get("c.getLabels");
        action.setParams({"parentId" : component.get("v.parentId") || null,
                          "context" : component.get("v.context")});
		action.setCallback(this, function(response){
			if(response.getState()==='SUCCESS'){
				var result=JSON.parse(response.getReturnValue());
                if(result.status === 'OK'){
				var optionList = [];
				var allOptions = new Map();
                var allOptionsMapById = new Map();
				result.labels.forEach(function(value, index){
					optionList.push({"value" : value.name, "label" : value.name});
					allOptions.set(value.name,value);
                    allOptionsMapById.set(value.labelId, value);
				});
				component.set("v.allOptions",allOptions);
				component.set("v.availableOptions",optionList);
                component.set("v.allOptionsMapById",allOptionsMapById);
                component.set("v.parentLabels", result.parentLabels);
                    //component.set("v.isLabelCalloutSuccess",true);
				this.initialize(component);
				this.updateJson(component);
                }
                
                    /*else{
                        alert("An error occured while fecthing Labels");
                    }*/
            }
            else{
                alert('ERROR:\nCallout to fetch list of labels has been failed.');
            }
		});
		$A.enqueueAction(action);
	},
	initialize : function(component) {
		var object = component.get("v.record");
		var selectedOptions = new Set();
		if(!$A.util.isEmpty(object.adsalescloud__Labels__c)){
			selectedOptions = new Set(object.adsalescloud__Labels__c.split(", "));
		}
		var jsonDataMap = new Map();
		if(!$A.util.isEmpty(object.adsalescloud__Labels_Detail__c)){
			var jsonData = JSON.parse(object.adsalescloud__Labels_Detail__c.replace(/<br>|\s\s|{\s|\s}|\[\s|\s\]/g,"").replace(/&quot;|“|”/g,"\""));
			jsonData.forEach(function(value,index){		// creating map of json objects
				jsonDataMap.set(value.labelId, value);
			});
		}
		component.set("v.selectedOptions",this.toList(selectedOptions));
		component.set("v.jsonData", jsonDataMap);
	},
	updateJson : function(component){
        var recordObject = component.get("v.record");
		var allOptions = component.get("v.allOptions");
        var parentLabels = component.get("v.parentLabels");
		var selectedOptions = new Set(component.get("v.selectedOptions"));
        var companyLabelsDetails = [];
        var companyLabelsIDs = [];
		var labelsDetail = [];
        var self = this;
		if(!$A.util.isEmpty(selectedOptions)){	// setting adsalescloud__Labels__c on recordObject
			recordObject.adsalescloud__Labels__c = this.toList(selectedOptions).join(', ');
		}
        if(!$A.util.isEmpty(parentLabels)){  // logic to create JSON for Company Labels on fields - Labels_Detail__c, Parent_Labels_Detail__c
            var allOptionsMapById = component.get("v.allOptionsMapById");
            parentLabels.forEach(function(value,index){
                var option = allOptionsMapById.get(value.labelId);
                var optionObject = {"labelId" : option.labelId, "isNegated" : false, "name" : option.name};
                if(self.toList(selectedOptions).indexOf(option.name) < 0){
                    optionObject.isNegated= true;
                    labelsDetail.push(optionObject);
                }
                companyLabelsDetails.push(optionObject);
                companyLabelsIDs.push(value.labelId);
            });
        }
		selectedOptions.forEach(function(value, index){  // setting json for Labels_Detail__c field
			var option = allOptions.get(value);
            if($A.util.isEmpty(companyLabelsIDs) || companyLabelsIDs.indexOf(option.labelId)<0){
                labelsDetail.push({"labelId" : option.labelId, "isNegated" : false, "name" : option.name});
            }
		});
		component.set("v.record.adsalescloud__Labels__c", recordObject.adsalescloud__Labels__c);
        component.set("v.record.adsalescloud__Labels_Detail__c", JSON.stringify(labelsDetail));
        component.set("v.record.adsalescloud__Parent_Labels_Details__c", JSON.stringify(companyLabelsDetails));
	},
    updateCompanyLabels : function(component, event, helper) {
        var action = component.get("c.getParentLabels");
        action.setParams({"parentId" : component.get("v.parentId"),
                          "context" : component.get("v.context"),
                          "updateAccount" : false});
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                if(component.get("v.allOptionsMapById")){
                component.set("v.parentLabels", JSON.parse(response.getReturnValue()));
                if(component.get("v.isNewRecord")){
                    var allOptionsMapById = component.get("v.allOptionsMapById");
                    var selectedOptions = new Set();
                    component.get("v.parentLabels").forEach(function(value, index){
                        selectedOptions.add(allOptionsMapById.get(value.labelId).name);
                    });
                    component.set("v.selectedOptions",this.toList(selectedOptions));
                }
                else{
                    this.updateJson(component);
                }
            }
            }
        });
        $A.enqueueAction(action);
    },
    toList : function(set){
        var list = [];
        if(!$A.util.isEmpty(set)){
            set.forEach(function(value){
                list.push(value);
            });
        }
        return list;
    },
})