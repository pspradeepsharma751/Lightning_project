({
	doInit : function (component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 50rem;}.panel .closeIcon{display:none} .slds-modal__content{max-height: calc(100vh - 210px); overflow-y: auto;}</style>');
        helper.doInit(component);
    },
    
    setPliIdsListHandler : function (component, event, helper) {
       helper.setPliIdsListHandler(component,helper);
    },
    
    redirectToPrevPage : function (component, event, helper) {
        $A.get('e.force:closeQuickAction').fire();
    },
    
    redirectToDetailPage : function (component, event, helper) { 
       window.location.href = "/"+event.currentTarget.dataset.id;
    },
    
    redirectToProposalDetailPage : function (component, event, helper) { 
        $A.get('e.force:closeQuickAction').fire();
        $A.get('e.force:refreshView').fire();
    },
    
    editRecord : function (component, event, helper) {
       window.open("/"+event.currentTarget.dataset.id);
    },
    
    reloadPage : function (component, event, helper) {
        if(component.get("v.isPliRecordUpdated")){
           var ec = component.find("editDiv");
            $A.util.addClass(ec, 'slds-hide');
            component.set("v.isPliRecordUpdated", false);
        }
    },
    onSync : function (component, event, helper) {
        var ec = component.find("displaySyncingSection");
        $A.util.removeClass(ec, 'slds-hide');
        var displayPliList = component.find("displayPliList");
        $A.util.addClass(displayPliList, 'slds-hide');
        component.set("v.isStartSync", false);
        component.set("v.hasNoError", true);
        var readyForDFPInfo = component.get("v.readyForDFPInfo");
        if(component.set("v.proposalRecord.adsalescloud__Negotiation_Status__c") == 'Awaiting Buyer Review'){
            helper.editProposalForNegotiation(component);
        }
        if((readyForDFPInfo.containProposalWarningMsg && readyForDFPInfo.unarchievedProposal) && readyForDFPInfo.OrderDfpId){
            helper.unarchieveProposal(component);
        } 
        helper.syncProposal(component);
    },
    
    checkValidation : function (component, event, helper) {
        if(component.get("v.islightningCheckVald"))
            helper.doInit(component);
    },
})