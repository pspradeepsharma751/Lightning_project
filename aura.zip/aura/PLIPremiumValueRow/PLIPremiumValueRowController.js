({
  statusChangeHandler: function(component, event, helper) {
    $A.get('e.c:StatusUpdateEvent').fire();
  }
});