({
  /*
   *  Map the Field to the desired component config, including specific attribute values
   *  Source: https://www.salesforce.com/us/developer/docs/apexcode/index_Left.htm#CSHID=apex_class_Schema_FieldSetMember.htm|StartTopic=Content%2Fapex_class_Schema_FieldSetMember.htm|SkinName=webhelp
   *
   *  Change the componentDef and attributes as needed for other components
   */
  configMap: {
    'boolean': {componentDef: 'lightning:input', attributes: {type: "toggle"}},
    'double': {componentDef: 'lightning:input', attributes: {type: "number"}},
    'id': {componentDef: 'lightning:input', attributes: {type: "text"}},
    'integer': {componentDef: 'lightning:input', attributes: {type: "number"}},
    'picklist': {componentDef: 'lightning:select', attributes: {messageWhenValueMissing: "--NONE--"}},
    'string': {componentDef: 'lightning:input', attributes: {type: "text"}},
    'text': {componentDef: 'lightning:input', attributes: {type: "text"}},
    'textarea': {componentDef: 'lightning:textarea', attributes: {}},
    'reference': {componentDef: 'c:CustomLookUp', attributes: {}},
  },
  createForm: function(cmp, section) {
    var fields = cmp.get('v.fields');
    var record = cmp.get('v.record');
    var inputDesc = [];
    var multipicklistFields = [];

    for(var i = 0; i < fields.length; i++) {
      var field = fields[i];
      var type = field.Type.toLowerCase();

      var configTemplate = this.configMap[type];

      if(!configTemplate) {
        console.log('type ${ type } not supported');
        continue;
      }

      // Copy the config so that subsequent types don't overwrite a shared config for each type.
      var config = JSON.parse(JSON.stringify(configTemplate));

      config.attributes.label = field.Label;
      config.attributes.required = field.Required;
      config.attributes.disabled = cmp.get('v.readonly');


      if(type === 'datetime' || type === 'date')
        config.attributes.value = $A.localizationService.formatDate(cmp.getReference(' v.record.' + field.APIName), 'yyyy-MM-ddTHH:mm:ss');
      else if(type === 'reference') {
        config.attributes.objectAPIName = field.ReferenceTo;
        config.attributes.record = cmp.getReference('v.record');
        config.attributes.fieldName = field.APIName;
        config.attributes.fieldId = cmp.get(' v.record.' + field.APIName);
      }
      else
        config.attributes.value = cmp.getReference(' v.record.' + field.APIName);
      config.attributes.fieldPath = field.APIName;

      inputDesc.push([
        config.componentDef,
        config.attributes
      ]);
      if(type === 'picklist') {
        multipicklistFields.push(i);
      }
    }
    $A.createComponents(inputDesc, function(cmps) {
      if(multipicklistFields.length) {
        for(var idx = 0; idx < multipicklistFields.length; idx++) {
          var picklistIdx = multipicklistFields[idx];
          var pickListCfg = fields[picklistIdx];
          var options = [];
          var picklistCmp = cmps[picklistIdx]; // newly created piclist empty one
          for(var jdx = 0; jdx < pickListCfg.lstPicklistValues.length; jdx++) {
            options.push([
              'option',
              {
                'value': pickListCfg.lstPicklistValues[jdx],
                'label': pickListCfg.lstPicklistValues[jdx],
                'selected': cmp.getReference(' v.record.' + fields[picklistIdx].APIName) == pickListCfg.lstPicklistValues[jdx]
              }
            ]);
          }
          $A.createComponents(options, function(optCmps) {
            picklistCmp.set('v.body', optCmps);
          });
        }
      }
      var evenCmps = [];
      var oddCmps = [];
      for(var idx = 0; idx < cmps.length; idx++) {
        if(idx % section) {
          oddCmps.push(cmps[idx]);
        } else {
          evenCmps.push(cmps[idx]);
        }
      }
      if(oddCmps.length) {
        cmp.set('v.rightPanel', oddCmps);
      }
      if(evenCmps.length) {
        cmp.set('v.leftPanel', evenCmps);
      }
    });
  }
})