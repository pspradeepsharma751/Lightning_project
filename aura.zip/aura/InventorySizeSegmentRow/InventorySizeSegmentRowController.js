({
  showSizeSelection: function(component, event, helper) {
    component.set('v.showModal', true);
  },
  handleClearSelection:function(component,event,helper){
    var dropdownOptions = component.get('v.dropdownOptions');
    if(dropdownOptions){
      component.set('v.selectedValue',dropdownOptions[0].label);
    }
  },
  addSizeSelected: function(component, event, helper) {
    helper.addSizeSelected(component);
  }
});