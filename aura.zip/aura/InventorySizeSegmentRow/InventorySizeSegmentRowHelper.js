({
  addSizeSelected: function(component) {
    var category = component.get('v.category');
    var dropdownOptions = component.get('v.dropdownOptions');
    var selectedOptions = component.get('v.selectedOptions');
    var selectedValue = component.get('v.selectedValue');
    var allSizes = component.get('v.allSizes');
    var sizeSegmentItems = [];
    for(var i = 0; i < selectedOptions.length; i++) {
      sizeSegmentItems.push(allSizes[selectedOptions[i]]);
    }
    if(category === 'Standard' && sizeSegmentItems.length > 0) {
      for(var j = 0; j < sizeSegmentItems.length; j++) {
        sizeSegmentItems[j]['name'] = sizeSegmentItems[j].fullDisplayString;
        sizeSegmentItems[j]['id'] = sizeSegmentItems[j].fullDisplayString;
      }
      this.fireSelectionEvent(sizeSegmentItems, category);
      component.set('v.selectedOptions', []);
    }
    else if(sizeSegmentItems.length > 0) {
      var segmentNames = [];
      var sizeSegmentItem = JSON.parse(JSON.stringify(allSizes[selectedValue]));
      sizeSegmentItem['companions'] = JSON.parse(JSON.stringify(sizeSegmentItems));
      for(var j = 0; j < sizeSegmentItems.length; j++) {
        segmentNames.push(sizeSegmentItems[j].fullDisplayString);
      }
      sizeSegmentItem['name'] = sizeSegmentItem.fullDisplayString + ' : ' + segmentNames.join();
      sizeSegmentItem['id'] = sizeSegmentItem.fullDisplayString + ' : ' + segmentNames.join();
      this.fireSelectionEvent(sizeSegmentItem, category);
      component.set('v.selectedValue', dropdownOptions[0].label);
      component.set('v.selectedOptions', []);
    }
  },
  fireSelectionEvent: function(adunit, sub_category) {
    var evt = $A.get('e.c:TargetingEvent');
    var param = {
      'action': null,
      'segments': true,
      'category': 'Inventory Sizes',
      'sub_category': sub_category
    };
    param[sub_category === 'Standard' ? 'adunits' : 'adunit'] = adunit;
    evt.setParams(param);
    evt.fire();
  }

});