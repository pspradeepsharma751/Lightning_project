({
	myAction : function(component, event, helper) {
		
	},
    confirm : function(component, event, helper) {
        component.set("v.response", {"confirm" : true, "action" : component.get("v.action")});
        component.set("v.show", false);
	},
    close : function(component, event, helper) {
		component.set("v.show", false);
	}
})