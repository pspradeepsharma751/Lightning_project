({
	onSave : function(cmp, event, helper) {
        $A.util.removeClass(cmp.find('spinner'), 'slds-hide');
        cmp.find("edit").get("e.recordSave").fire();
    },
    closeModel : function(cmp, event, helper){
        cmp.set('v.isOpen', false);
    },
    onSaved : function(cmp, event, helper){
        $A.util.addClass(cmp.find('spinner'), 'slds-hide');
        cmp.set('v.isOpen', false);
        $A.get('e.adsalescloud:refreshTable').fire();
    }
})