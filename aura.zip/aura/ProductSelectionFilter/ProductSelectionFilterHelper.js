({
  combineFilter: function(component) {
    var keyword = component.get('v._keyword');
    var filterLogic = component.get('v._filter_logic');
    var filterList = component.get('v._filter_list');
    var validFilterList = [];
    if(filterList.length > 0){
      for(var i=0;i<filterList.length;i++){
        if(!filterList[i].field || filterList[i].field === '') continue;
        validFilterList.push(filterList[i]);
      }
    }
    var filter = {
      'keyword': keyword,
      'filterLogic': filterLogic,
      'filterList': validFilterList
    };
    component.set('v._filter', filter);
  }
});