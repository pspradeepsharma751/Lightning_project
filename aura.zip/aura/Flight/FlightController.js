({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component, event, helper) {
		helper.doInit(component);
	},
    flightLineItem : function(component, event, helper){
        helper.createFlightLineItem(component);
    },
    onQuantityTypeChanged : function(component, event, helper) {
		var item = component.get("v.item");
        if(item.quantityType.value == "total"){
            item.quantity.label = "Total Quantity";
            item.net_cost.label = "Total Net Cost";
        }
        else{
            item.quantity.label = "Quantity per line item";
            item.net_cost.label = "Net cost per line item";
        }
        component.set("v.item", item);
        helper.calculateQuantityAndCost(component);
	},
    
    quantityChangeHandler : function(component, event, helper) {
        var item = component.get("v.item");
         if($A.util.isEmpty(item.quantity.value)){
            item.quantity.value = 0;
        }
        else{
            item.quantity.value = Math.floor(item.quantity.value);
        }
        item.net_cost.value = helper.round((item.rateType.indexOf("CPM") == -1 ? (item.net_rate.value * item.quantity.value) : (item.net_rate.value * item.quantity.value) / 1000) , 2);
        component.set("v.item", item);
        helper.calculateQuantityAndCost(component);
    },
    costChangeHandler : function(component, event, helper) {
        var item = component.get("v.item");
         if($A.util.isEmpty(item.net_cost.value)){
            item.net_cost.value = 0;
        }
        item.quantity.value = Math.round(item.rateType.indexOf("CPM") == -1 ? (item.net_cost.value / item.net_rate.value) : (item.net_cost.value / item.net_rate.value) * 1000);
        item.net_cost.value = helper.round((item.rateType.indexOf("CPM") == -1 ? (item.net_rate.value * item.quantity.value) : (item.net_rate.value * item.quantity.value) / 1000) , 2);
        component.set("v.item", item);
        helper.calculateQuantityAndCost(component);
    },
    onSave : function(component, event, helper) {
         helper.onSave(component);
    },
    close : function(component, event, helper) {
		component.set("v.show", false);
	},
})