({
    helperMethod : function() {
        
    },
    monthName : ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    doInit : function(component){
        if(this.validateFlightItem(component)){
            var flightItem = component.get("v.flightItem");
            var item = {"name": flightItem.name,
                        "start_date": flightItem.start_date, 
                        "end_date": flightItem.end_date,
                        "timezone": flightItem.timezone ,
                        "flightBy": "month", 
                        "quantityType": {"value":"total"}, 
                        "net_rate": {"value": flightItem.net_rate}, 
                        "quantity": {"label": "Total Quantity", "value": flightItem.quantity}, 
                        "net_cost": {"label": "Total Net Cost","value": flightItem.net_rate * flightItem.quantity}, 
                        "rateType" : flightItem.rate_type};
            item.net_cost.value = this.round(item.rateType.indexOf("CPM") == -1 ? item.net_cost.value : item.net_cost.value /1000, 2);
            let quantityUnitMap = {"CPD" : "days", "CPM" : "imps", "CPC" : "clicks", "Flat fee": ""};
            item.quantityUnit = quantityUnitMap[flightItem.rate_type];
            item.quantityType.render = flightItem.rate_type.indexOf("CPD") == -1 ;
            item.quantity.render = flightItem.rate_type.indexOf("Flat fee") == -1 ;
            item.net_rate.render = flightItem.rate_type.indexOf("Flat fee") == -1 ;
            item.net_cost.disabled = flightItem.rate_type.indexOf("CPD") > -1 ;
            component.set("v.item", item);
            this.getDateObjectInPliTimezone = function(dateString){   // creates Date object from ISOString, this object represent time value in PLI timezone
                dateString = new Date(dateString).toISOString();
                var offsetMinutes = this.getPliTimezoneOffset(dateString , component.get("v.item.timezone"));
                var newDate = new Date(dateString.split(".")[0]);
                newDate.setMinutes(newDate.getMinutes() + offsetMinutes );
                return newDate;
            }
            this.toPliTimezone = function(dateString){   // converts Date from ISOString to PLI timezone by adjusting timezoneOffset.
                var newDate = new Date(dateString);
                var offsetMinutes = this.getPliTimezoneOffset(dateString , component.get("v.item.timezone"));
                newDate.setMinutes(newDate.getMinutes() - (offsetMinutes + newDate.getTimezoneOffset()));
                return newDate;
            }
            this.lastDayOf = [ 31, (new Date().getFullYear() % 4 == 0 ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            this.createFlightLineItem(component);
        }
        
    },
    validateFlightItem : function(component){
        var flightItem = component.get("v.flightItem");
        if(!flightItem.adServerId &&  new Date(flightItem.start_date) < new Date()){
            component.set("v.flightItemValidationError", "Flight not allowed if start date is in the past. Update the selected line item’s start date to continue.");
            component.set("v.validFlightItem", false);
            return false;
        }
        else{
            component.set("v.validFlightItem", true);
            return true;
        }
    },
    onSave : function(component){
        var flightItem = component.get("v.flightItem");
        var flightData = component.get("v.flightData");
        var flightedPliList = [];
        var self = this;
        flightData.newFlightedPLIs.forEach(function(newFlightItem, index){
            if(index == 0){
                flightItem.end_date = self.toPliTimezone(newFlightItem.endDate).toISOString();
                flightItem.quantity = newFlightItem.quantity;
                flightItem.cost = newFlightItem.cost;
            }else{
                var newItem = self.clone(flightItem);
                newItem.start_date = self.toPliTimezone(newFlightItem.startDate).toISOString();
                newItem.end_date = self.toPliTimezone(newFlightItem.endDate).toISOString();
                newItem.quantity = newFlightItem.quantity;
                newItem.cost = newFlightItem.cost;
                newItem.name = newItem.name+ " " + (index + 1)+"/"+ flightData.newFlightedPLIs.length;
                flightedPliList.push(newItem);
            }
        });
        flightItem.name = flightItem.name + " 1/"+ flightData.newFlightedPLIs.length;
        console.log(flightedPliList)
        component.set("v.flightedPliList", flightedPliList);
        component.set("v.flightItem", flightItem);
        component.set("v.show", false);
    },
    createFlightLineItem : function(component){
        var item = component.get("v.item");
        var flightData = {"quantityTable" : [], "costTable" : []};
        var pliStartDate = this.getDateObjectInPliTimezone(item.start_date);
        var startDate = new Date(pliStartDate);
        var endDate = this.getDateObjectInPliTimezone(item.end_date);
        var now = this.getDateObjectInPliTimezone(new Date);
        var self = this;
        var quantityPerLineItem ;
        var period ;  // number of months. 
        var newFlightedPLIs = [];
        newFlightedPLIs.totalDays = function(){
            let totalDays = 0;
            this.forEach(function(value){
                totalDays += value.days;
            });
            return totalDays;
        }
        newFlightedPLIs.getTotalFullPeriod = function(){ // all full periods included past periods
            let fullPeriods = 0;
            this.forEach(function(value){
                fullPeriods += value.fullPeriods ;
            });
            return fullPeriods;
        }
        newFlightedPLIs.getFullPeriod = function(){  // actual full periods 
            let partialPeriods = 0;
            let self = this;
            this.forEach(function(value, index){
                partialPeriods += value.partialDays  ? 1 : 0;
            });
            return this.length - partialPeriods;
        }
        newFlightedPLIs.getPartialPeriodDays = function(){
            let partialPeriodDays = 0;
            this.forEach(function(value){
                partialPeriodDays += value.partialDays;
            });
            return partialPeriodDays;
        }
        newFlightedPLIs.getTotalQuantity = function(){
            let totalQuantity = 0;
            this.forEach(function(value){
                totalQuantity += parseInt(value.quantity);
            });
            return totalQuantity;
        }
        newFlightedPLIs.getTotalCost = function(){
            let totalCost = 0;
            this.forEach(function(value){
                totalCost += value.cost;
            });
            return self.round(totalCost, 2);
        }
        if(startDate < now && endDate > now){
            startDate = new Date(now);
        }
        /*
         * calculate number of PLIs to be flighted and thier data
         */
        if(startDate.getMonth() == endDate.getMonth() && startDate.getYear() == endDate.getYear()){
            newFlightedPLIs.push(this.getFlightRecordData(new Date(item.start_date),endDate, item.flightBy));
        }
        else{                
            var tempDate = (endDate < now) || startDate > now ? new Date(startDate) : new Date(now); 
            period = item.flightBy === "month" ? 1 : (3 - (startDate.getMonth() % 3)); //
            tempDate.setDate(1); tempDate.setMinutes(0); tempDate.setHours(0); tempDate.setMonth(tempDate.getMonth() + period); tempDate.setSeconds(-1); 
            if(endDate < tempDate || endDate < now){
                tempDate = new Date(endDate);
            }
            let count = 0;
            do{
                newFlightedPLIs.push(this.getFlightRecordData(count == 0 ? new Date(pliStartDate) : startDate,tempDate, item.flightBy)); 
                startDate = new Date(tempDate); startDate.setSeconds(60);
                period = item.flightBy === "month" ? 1 :(3 - (startDate.getMonth() % 3));
                tempDate.setSeconds(60);
                tempDate.setMonth(tempDate.getMonth() + period); 
                tempDate.setSeconds(-1);
                count++;
            }
            while(tempDate < endDate);
            if(startDate < endDate){
                newFlightedPLIs.push(this.getFlightRecordData(startDate,endDate, item.flightBy)); 
            }
        }
        console.log(newFlightedPLIs);
        flightData.totalPLIs = (endDate < now) ? 1 : newFlightedPLIs.length;
        flightData.newFlightedPLIs = newFlightedPLIs;
        component.set("v.flightData", flightData);
        this.calculateQuantityAndCost(component);
    },
    calculateQuantityAndCost : function(component){ 
        var item = component.get("v.item");
        var flightData = component.get("v.flightData"); 
        var newFlightedPLIs = flightData.newFlightedPLIs; 
        var pliStartDate = this.getDateObjectInPliTimezone(item.start_date);
        var startDate = new Date(pliStartDate);
        var endDate = this.getDateObjectInPliTimezone(item.end_date);
        var now = this.getDateObjectInPliTimezone(new Date);
        var self = this;
        flightData.quantityTable = [];
        flightData.costTable = [];
        /*
         * calculate quantity and cost table
         */
        if($A.util.isEmpty(item.quantity.value)){
            item.quantity.value = 0;
        }
        let averageDays = item.flightBy === "month" ? 30 : 91;
        var totalContractedVolume = item.quantityType.value === "total" ? parseInt(item.quantity.value) : Math.floor(item.quantity.value * (newFlightedPLIs.getTotalFullPeriod() + newFlightedPLIs.getPartialPeriodDays() / averageDays));
        let quantityPerDay = totalContractedVolume / (newFlightedPLIs.getTotalFullPeriod() * averageDays + newFlightedPLIs.getPartialPeriodDays()); 
        /*    		    Qd = C / (F x A + P)
        where:        
            Qd: quantity per day
            C: total contracted volume
            F: number of full periods in the time range of a proposal line item
            A: average number of days in the period type by which the proposal line item is being flighted
            P: number of days in partial periods based on actual calendar days
        */
        newFlightedPLIs.forEach(function(newItem,index){
            if((newItem.partialDays == 0 || newFlightedPLIs.length == 1)&& item.quantityType.value === "lineItem"){ 
                newItem.quantity = parseInt(item.quantity.value); 
            }
            else{
                newItem.quantity = Math.floor((newItem.fullPeriods * averageDays + newItem.partialDays) * quantityPerDay);
            }
        });
        
        let remainingQuantityAfterCaluculation = totalContractedVolume - newFlightedPLIs.getTotalQuantity();
        remainingQuantityAfterCaluculation = remainingQuantityAfterCaluculation < 0 ? 0 : remainingQuantityAfterCaluculation;
        if(remainingQuantityAfterCaluculation != 0){
            if(newFlightedPLIs.length - newFlightedPLIs.getFullPeriod() == 0){  // for no partial period
                newFlightedPLIs[newFlightedPLIs.length - 1].quantity += remainingQuantityAfterCaluculation;
            }
            else if(newFlightedPLIs.length - newFlightedPLIs.getFullPeriod() == 1){ // for 1 partial period
                if(newFlightedPLIs[0].partialDays > 0){
                    newFlightedPLIs[0].quantity += remainingQuantityAfterCaluculation;
                }
                else{
                    newFlightedPLIs[newFlightedPLIs.length - 1].quantity += remainingQuantityAfterCaluculation;
                }
            }
                else{  // for 2 partial period
                    if(newFlightedPLIs[0].partialDays < averageDays){
                        let tempQunatity = Math.ceil(remainingQuantityAfterCaluculation * (newFlightedPLIs[0].partialDays / averageDays));
                        newFlightedPLIs[0].quantity +=  tempQunatity;
                        remainingQuantityAfterCaluculation = remainingQuantityAfterCaluculation - tempQunatity;
                    }
                    newFlightedPLIs[newFlightedPLIs.length - 1].quantity += remainingQuantityAfterCaluculation;
                }
        }
        
        /*
		 * calculate cost for each new flight item        
         */
         component.set("v.generatedPliError", "");
        newFlightedPLIs.forEach(function(newItem,index){
            newItem.cost = self.round(item.rateType.indexOf("CPM") == -1 ? (item.net_rate.value * newItem.quantity) : (item.net_rate.value * newItem.quantity) / 1000, 2) ;
            if(newItem.quantity == 0){
                component.set("v.generatedPliError", "Quantity cannot be 0 for generated line items.");
            }
        });
        if(!$A.util.isEmpty(component.get("v.generatedPliError"))){
            component.set("v.disableButton", true);
        }else{
            component.set("v.disableButton", false);
        }
        
        if(endDate < now){ // if selected PLI ended in past
            let quantity = newFlightedPLIs[0].quantity;
            let cost = 0;
            let period = "first "+ (newFlightedPLIs[0].hasMultiplePeriods ? "period" : item.flightBy)+" ("+ (newFlightedPLIs.length == 1 ? newFlightedPLIs[0].period : newFlightedPLIs[0].period +" - "+newFlightedPLIs[newFlightedPLIs.length -1].period) +")";
            flightData.quantityTable.push({"quantity": quantity.toLocaleString(), "period": item.quantityUnit+" "+period});
            flightData.costTable.push({"cost": this.fixTo2Decimal(newFlightedPLIs[0].cost.toLocaleString()), "period": " "+"USD"+" "+period});
        }else{
            /*
             * calculate quantity and cost table for first month
             */
            newFlightedPLIs.forEach(function(newFlightItem, index){
                let cost = 0;
                let period;
                let quantity;
                if(index == 0){
                    period = "first "+ (newFlightedPLIs[0].hasMultiplePeriods ? "period" : item.flightBy) + " (" + newFlightItem.period + ")" ;
                    flightData.quantityTable.push({"quantity": newFlightItem.quantity.toLocaleString(), "period": " "+item.quantityUnit+" "+period});
                    flightData.costTable.push({"cost": self.fixTo2Decimal(newFlightItem.cost.toLocaleString()), "period": " "+"USD"+" "+period});
                    
                }
                else if(newFlightedPLIs.length > 2 && index == 1){
                    period = "total for full "+item.flightBy+"s ("+ (newFlightedPLIs.length == 3 ? newFlightItem.period : newFlightItem.period +" - "+newFlightedPLIs[newFlightedPLIs.length - 2].period) +" )";
                    let fullPeriods = newFlightedPLIs.length -2;
                    quantity = Math.floor(averageDays * quantityPerDay) * fullPeriods;
                    flightData.quantityTable.push({"quantity": quantity.toLocaleString(), "period": " "+item.quantityUnit+" "+period});
                    flightData.costTable.push({"cost": self.fixTo2Decimal((newFlightItem.cost * fullPeriods).toLocaleString()), "period": " "+"USD"+" "+period});
                    flightData.quantityTable.push({"quantity": null, "period": (item.quantityType.value === "lineItem" ? parseInt(item.quantity.value) : Math.floor(averageDays * quantityPerDay)).toLocaleString()+" "+item.quantityUnit+"  for each full "+item.flightBy});
                    flightData.costTable.push({"cost": null, "period": self.fixTo2Decimal(newFlightItem.cost.toLocaleString()) +" USD"+" for each full "+item.flightBy});
                    
                }
                    else if(newFlightedPLIs.length > 1 && index == newFlightedPLIs.length - 1){
                        period = "last "+ item.flightBy+" ("+ newFlightedPLIs[newFlightedPLIs.length - 1].period +" )";
                        flightData.quantityTable.push({"quantity": newFlightItem.quantity.toLocaleString(), "period": " "+item.quantityUnit+" "+period});
                        flightData.costTable.push({"cost": self.fixTo2Decimal(newFlightItem.cost.toLocaleString()), "period": " "+"USD"+" "+period});
                        
                        flightData.quantityTable.push({"quantity": newFlightedPLIs.getTotalQuantity().toLocaleString(), "period": item.quantityUnit+" in total", isTotal : true});
                        flightData.costTable.push({"cost": self.fixTo2Decimal(newFlightedPLIs.getTotalCost().toLocaleString()), "period": " "+"USD"+" in total", isTotal : true});
                        
                    } 
                
                
                
                if(newFlightedPLIs.length > 1 && index == newFlightedPLIs.length - 1){
                }
                /*
                flightData.costTable.push(cost+" USD "+period);*/
                /*
             * calculate quantity and cost table for intermediate months
             *//*
            for(let index = 1; index < newFlightedPLIs.length-1; index++){
                
            }*/
                /*
             * calculate quantity and cost table for last month
             */
            });   
        }
        console.log(flightData);
        component.set("v.flightData", flightData);
    },
    
    getFlightRecordData : function(startDate, endDate, flightBy, isFirstPeriod, isPast){
        var period; // = flightBy === "month" ? this.monthName[this.toPliTimezone(startDate).getMonth()]+" "+startDate.getFullYear() : "Q"+(Math.floor((this.toPliTimezone(startDate).getMonth() / 3) + 1))+" "+ this.toPliTimezone(startDate).getFullYear() ;
        var multiplePeriods; 
        var fullPeriodsAndPartialPeriodsDetail = this.getFullPeriodsAndPartialPeriods(startDate, endDate, flightBy);
        if(flightBy === "month"){
            if((startDate.getMonth() == endDate.getMonth()) &&  startDate.getFullYear()  == endDate.getFullYear()){
                period = this.monthName[startDate.getMonth()]+" "+startDate.getFullYear() ;
                multiplePeriods = false ;
            }
            else{ 
                period = this.monthName[startDate.getMonth()]+" "+startDate.getFullYear() + " - " + this.monthName[endDate.getMonth()]+" "+endDate.getFullYear();
                multiplePeriods = true;
                
            }
        }
        else{
            if( (parseInt(startDate.getMonth() / 3) == parseInt(endDate.getMonth() / 3)  ) &&  startDate.getFullYear()  == endDate.getFullYear()){
                period = "Q"+(Math.floor((startDate.getMonth() / 3) + 1))+" "+ startDate.getFullYear() ;
                multiplePeriods = false;
            }
            else{
                period = "Q"+(Math.floor((startDate.getMonth() / 3) + 1))+" "+ startDate.getFullYear() +" - "+ "Q"+(Math.floor((endDate.getMonth() / 3) + 1))+" "+ endDate.getFullYear();
                multiplePeriods = true;
            }
            
        }
        if(isPast){
            period = period + " - "+ "Q"+(Math.floor((endDate.getMonth() / 3) + 1))+" "+ endDate.getFullYear();
        }
        let tempStartDate = new Date(startDate); tempStartDate.setHours(0); tempStartDate.setMinutes(0); tempStartDate.setSeconds(0);
        let tempEndDate = new Date(endDate); tempEndDate.setHours(23); tempEndDate.setMinutes(59); tempEndDate.setSeconds(59);
        let lastDateOfMonth = new Date(Date.parse(tempStartDate.toDateString())); lastDateOfMonth.setMonth(lastDateOfMonth.getMonth() +1); lastDateOfMonth.setSeconds(-1);
        return {"startDate": new Date(startDate), "endDate": new Date(endDate), "period": period, "days":Math.ceil((tempEndDate - tempStartDate) /(1000*60*60*24)), 
                "fullPeriods": fullPeriodsAndPartialPeriodsDetail.fullPeriods, "partialDays": fullPeriodsAndPartialPeriodsDetail.partialDays, "hasMultiplePeriods": multiplePeriods};
    },
    getFullPeriodsAndPartialPeriods : function(startDate, endDate, flightBy){
        startDate = new Date(startDate);
        endDate = new Date(endDate);
        var partialDays = 0;
        var fullPeriods = 0;
        if(((endDate.getMonth() - startDate.getMonth() + (endDate.getFullYear() - startDate.getFullYear()) * 12) <=1) &&  (startDate.getDate() > 1 || endDate.getDate() < this.lastDayOf[endDate.getMonth()]) ){  // ((endDate.getMonth() - startDate.getMonth() + (endDate.getFullYear() - startDate.getFullYear()) * 12) <=1)
            partialDays = Math.ceil((endDate - startDate) /(1000*60*60*24));
        }
        else{
            let tempStartDate = new Date(startDate); // end of first period
            let tempEndDate = new Date(endDate);	 // start of last period
            let period = flightBy === "month" ? 1 : (3 - (startDate.getMonth() % 3));
            if(tempStartDate.getDate() != 1){
                tempStartDate.setDate(1); tempStartDate.setMinutes(0); tempStartDate.setHours(0); tempStartDate.setMonth(tempStartDate.getMonth() + period); tempStartDate.setSeconds(-1);
            }
            if(tempEndDate.getDate() != this.lastDayOf[tempEndDate.getMonth()]){
                tempEndDate.setDate(1); tempEndDate.setMinutes(0); tempEndDate.setHours(0); tempEndDate.setMonth(tempEndDate.getMonth() - (flightBy === "month" ? 0 : (startDate.getMonth() % 3))); tempEndDate.setSeconds(0);
            }
            partialDays = Math.ceil((tempStartDate - startDate) /(1000*60*60*24)) + Math.ceil((endDate - tempEndDate) /(1000*60*60*24));
            tempStartDate.setSeconds(60);
            tempEndDate.setSeconds(-1);
            fullPeriods = Math.ceil((tempEndDate.getMonth() - tempStartDate.getMonth() + (endDate.getFullYear() - startDate.getFullYear()) * 12) +1);
            fullPeriods = flightBy === "month" ? fullPeriods : parseInt(fullPeriods / 3);
        }
        return {"partialDays": partialDays, "fullPeriods": fullPeriods};
    },
    getPliTimezoneOffset : function(date, timezone){ // returns timezone offset of given time in minutes (also considers DST)
        date = new Date(date).toISOString().split(".")[0];
        date = new Date(date);
        var offsetMinutes;
        $A.localizationService.WallTimeToUTC(date, timezone, function(walltime) {
            offsetMinutes = (date - walltime) / 1000 /60;
        })
        return offsetMinutes;
    },
    round : function(value, precision){
        return Math.round(value * Math.pow(10 , precision)) / Math.pow(10 , precision);
    },
    clone : function(obj){
        var clone = {};
        Object.keys(obj).forEach(function(key){
            clone[key] = obj[key];
        });
        return clone;
    },
    fixTo2Decimal : function(number){
        return number.split(".").length == 1 ? number + ".00" : (number.split(".")[1].length == 1 ? number + "0" : number);
    },
})