({
    checkboxDetailFields : {
        'allowGeoTargetingCustomization': true,
        'allowAdUnitTargetingCustomization': true,
        'allowPlacementTargetingCustomization': true,
        'allowUserDomainTargetingCustomization': true,
        'allowBandwidthGroupTargetingCustomization': true,
        'allowBrowserTargetingCustomization': true,
        'allowBrowserLanguageTargetingCustomization': true,
        'allowOperatingSystemTargetingCustomization': true,
        'allowDeviceCapabilityTargetingCustomization': true,
        'allowDeviceCategoryTargetingCustomization': true,
        'allowMobileApplicationTargetingCustomization': true,
        'allowMobileCarrierTargetingCustomization': true,
        'allowMobileDeviceAndManufacturerTargetingCustomization': true,
        'allowAudienceSegmentTargetingCustomization': true,
        'isAllCustomTargetingKeysCustomizable': true,
        'allowDaypartTargetingCustomization': true,
        'allowFrequencyCapsCustomization': true,
        'allowDeliverySettingsCustomization': true,
        'allowCreativePlaceholdersCustomization': true,
        'allowVideoContentCustomization': false,
        'allowContentBundleCustomization': false,
        'allowVideoPositionCustomization': true
        
    },  
	doInit : function(component) {
        var record = component.get('v.record');
		if(record['adsalescloud__Customizable_Attributes_Details__c'] && record['adsalescloud__Customizable_Attributes_Details__c'] != 'null'){
             var customizableAtt = JSON.parse(component.get('v.record.adsalescloud__Customizable_Attributes_Details__c').replace(/&quot;/g,"\""));
             var lstCustomizableAttributeField = Object.keys(this.checkboxDetailFields);
             for(var targFeildIdx = 0; targFeildIdx < lstCustomizableAttributeField.length; targFeildIdx++){
                 this.checkboxDetailFields[lstCustomizableAttributeField[targFeildIdx]] = customizableAtt[lstCustomizableAttributeField[targFeildIdx]];
             }
             
         }
        component.set('v.checkboxDetailFields',this.checkboxDetailFields);
     }
	
})