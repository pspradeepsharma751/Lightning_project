({
  doInit: function(component, event, helper) {
    helper.doInit(component);
  },
  showModal: function(component, event, helper) {
    component.set('v.showModal', true);
  },
  closeModal: function(component, event, helper) {
    component.set('v.showModal', false);
    component.set('v.errorMsg', '');
  },
  doUpdate: function(component, event, helper) {
    helper.updateJson(component);
  },
  addInputToSelectedOptions: function(component, event, helper) {
    helper.addInputToOptions(component);
  },
  handleChange: function(component, event, helper) {
    helper.selectedOptionsChanged(component, event);

  }
});