({
  configMap: {
    'Inventory': 'Ad units',
    'Ad units': 'Ad units',
    'Key-Values': 'Key-Values',
    'Ad Unit Hierarchies': 'Ad Unit Hierarchies',
    'Placements': 'Placements',
    'Geography': 'Geography',
    'Browser': 'Browser',
    'Operating System': 'Operating System',
    'Operating System Versions': 'Operating System',
    'Bandwidth': 'Bandwidth',
    'Browser Language': 'Browser Language',
    'User domains': 'User domains',
    'Device Capability': 'Device Capability',
    'Device Category': 'Device Category',
    'Device Manufacturer': 'Device Manufacturer',
    'Mobile devices': 'Device Manufacturer',
    'Mobile devices submodels': 'Device Manufacturer',
    'Mobile carrier': 'Mobile carrier',
    'Content': 'Content',
    'Content Bundle': 'Content Bundle',
    'Video Position': 'Video Position',
    'Standard': 'Inventory Sizes',
    'Master/Companion': 'Inventory Sizes',
    'Video VAST': 'Inventory Sizes',
    'Inventory Sizes': 'Inventory Sizes'
  },
  optionalMap: {
    //'Template Name':'',
    'Type': 'adsalescloud__Line_Item_Type__c',
    'Rate Type': 'adsalescloud__Rate_Type__c',
    'Frequency Cap': 'adsalescloud__Frequency_Caps_per_User_Details__c',
    // 'Inventory Sizes': 'adsalescloud__Inventory_Sizes__c',
    'Priority': 'adsalescloud__Line_Item_Priority__c',

  },

  doInit: function(component) {
    console.log('Selected Segmentation change');
    //if(component.get("v.record.adsalescloud__Product_Name__c"))
      this.getSelectedProductNameSegment(component, 'Template Name');
  },
  getSelectedProductNameSegment: function(component, productSegmentDefaultOptionType) {

    var record = component.get("v.record");
    var totalOptionList = [
      {"value": "Frequency Cap", "label": "Frequency Cap", "isCustom": false},
      {"value": "Inventory Sizes", "label": "Inventory Sizes", "isCustom": false},
      {"value": "Priority", "label": "Priority", "isCustom": false},
      {"value": "Rate Type", "label": "Rate Type", "isCustom": false},
      {"value": "Template Name", "label": "Template Name", "isCustom": false},
      {"value": "Type", "label": "Type", "isCustom": false}
    ];
    var productNameOptions = JSON.parse(record['adsalescloud__Product_Name__c'].replace(/&quot;/g, '\"'));
    var selectedSegmentOptionsValues = [];
    var deviceManufSegmentOptions = ['Device Manufacturer', 'Mobile devices', 'Mobile devices submodels'];
    var operSystemSegmentOptions = ['Operating System', 'Operating System Versions'];
    var inventorySizesSegmentOptions = ['Standard', 'Master/Companion','Video VAST'];

    //selected option default
    var selectedOptions = [];
    //selected list coming from product segment
    var selectedSegments = component.get("v.selectedSegments");
    var selectedOptionValues = [];
    var selectedSegmentValue = {};
    var requiredOptions = [];
    var devManufOptionValues = [];
    var operSysOptionValues = [];
    var inventorySizesOptionValues = [];
    //seleted option and its related values from segmentation
    var outerCounter = 1;
    for(var prodIdx = 0; prodIdx < productNameOptions.length; prodIdx++) {
      selectedSegmentOptionsValues.push(productNameOptions[prodIdx].value);
    }
    for(var prodIdx = 0; prodIdx < productNameOptions.length; prodIdx++) {
      var devSegmentFlag = false;
      var opSystemSegmentFlag = false;
      var inventorySizeSegmentFlag = false;
      //seleted option and its related default values
      if(productSegmentDefaultOptionType == productNameOptions[prodIdx].value && !productNameOptions[prodIdx].isCustom) {
        selectedOptions.push(productSegmentDefaultOptionType);
        selectedOptionValues.push([{'name': record['Name'], 'type': 'Template Name'}]);
        selectedSegmentValue[productSegmentDefaultOptionType] = [{'name': record['Name'], 'type': 'Template Name'}];
      }

      if(selectedSegments) {
        //getting the segment types with its json
        Object.entries(selectedSegments).forEach(([targetingType, targetingTypeObjectValue]) => {
          if(targetingTypeObjectValue['hasSubcategory']) {
            var selectedSubCategorySegments = targetingTypeObjectValue;
            Object.entries(selectedSubCategorySegments).forEach(([subCategoryTargetingType, subCategoryTargetingTypeObjectValue]) => {
              if(this.configMap[subCategoryTargetingType] && !selectedSegmentOptionsValues.includes(this.configMap[subCategoryTargetingType])) {
                selectedSegmentOptionsValues.push(this.configMap[subCategoryTargetingType]);
                productNameOptions.push({"value": this.configMap[subCategoryTargetingType], isCustom: false});

              }
              if(!productNameOptions[prodIdx].isCustom && this.configMap[subCategoryTargetingType] && productNameOptions[prodIdx].value == this.configMap[subCategoryTargetingType]) {
                totalOptionList.push({"value": this.configMap[subCategoryTargetingType], "label": this.configMap[subCategoryTargetingType], "isCustom": false});
                if(!selectedOptions.includes(this.configMap[subCategoryTargetingType])) {
                  selectedOptions.push(this.configMap[subCategoryTargetingType]);
                }

                if(!requiredOptions.includes(this.configMap[subCategoryTargetingType])) {
                  requiredOptions.push(this.configMap[subCategoryTargetingType]);
                }
                var optionValues = [];

                var innerCounter = 0;
                Object.entries(subCategoryTargetingTypeObjectValue).forEach(([subCategoryTargetingCategoryType, subCategoryTargetingCategoryValue]) => {
                  if(deviceManufSegmentOptions.includes(subCategoryTargetingType)) { // condition to check if current category is of Device/Manufact.
                    for(var index = 0; index < subCategoryTargetingCategoryValue.length; index++) {
                      devManufOptionValues.push({'action': subCategoryTargetingCategoryValue[index].action, 'name': subCategoryTargetingCategoryValue[index].adunit.name, 'id': subCategoryTargetingCategoryValue[index].adunit.id, 'type': subCategoryTargetingType});
                    }
                    devSegmentFlag = true;
                  }
                  else if(operSystemSegmentOptions.includes(subCategoryTargetingType)) { // condition to check if current category is of operating system.
                    for(var index = 0; index < subCategoryTargetingCategoryValue.length; index++) {
                      operSysOptionValues.push({'action': subCategoryTargetingCategoryValue[index].action, 'name': subCategoryTargetingCategoryValue[index].adunit.name, 'id': subCategoryTargetingCategoryValue[index].adunit.id, 'type': subCategoryTargetingType});
                    }
                    opSystemSegmentFlag = true;
                  }
                  else if(inventorySizesSegmentOptions.includes(subCategoryTargetingType)) { // condition to check if current category is of inventory sizes.
                    for(var index = 0; index < subCategoryTargetingCategoryValue.length; index++) {
                      inventorySizesOptionValues.push({'action': subCategoryTargetingCategoryValue[index].action, 'name': subCategoryTargetingCategoryValue[index].adunit.name, 'id': subCategoryTargetingCategoryValue[index].adunit.id, 'type': subCategoryTargetingType,'obj':subCategoryTargetingCategoryValue[index].adunit});
                    }
                    inventorySizeSegmentFlag = true;
                  }
                  else {
                    for(var index = 0; index < subCategoryTargetingCategoryValue.length; index++) {
                      innerCounter++;
                      optionValues.push({'action': subCategoryTargetingCategoryValue[index].action, 'name': subCategoryTargetingCategoryValue[index].adunit.name, 'id': subCategoryTargetingCategoryValue[index].adunit.id, 'type': subCategoryTargetingType});
                    }
                  }

                });
                //getting the total count of the segment selected values
                if(innerCounter != 0) {
                  outerCounter *= innerCounter;
                  selectedOptionValues.push(optionValues);
                }
                //pushing the option values array of particular segment type
                selectedSegmentValue[this.configMap[subCategoryTargetingType]] = optionValues;
              }
            });
          }
          else {
            if(!selectedSegmentOptionsValues.includes(this.configMap[targetingType])) {
              selectedSegmentOptionsValues.push(this.configMap[targetingType]);
              productNameOptions.push({"value": this.configMap[targetingType], isCustom: false});
            }
            if(!productNameOptions[prodIdx].isCustom && productNameOptions[prodIdx].value == this.configMap[targetingType]) {
              if(this.configMap && this.configMap[targetingType]) {
                totalOptionList.push({"value": this.configMap[targetingType], "label": this.configMap[targetingType], "isCustom": false});
                selectedOptions.push(this.configMap[targetingType]);
              }
              requiredOptions.push(this.configMap[targetingType]);
              var optionValues = [];
              var innerCounter = 0;
              var keyValueOptions = [];
              Object.entries(targetingTypeObjectValue).forEach(([targetingCategoryType, targetingCategoryValue]) => {
                for(var index = 0; index < targetingCategoryValue.length; index++) {
                  if(targetingType === 'Key-Values') {
                    optionValues = [];
                    innerCounter = 0;
                    var selectedkey = targetingCategoryValue[index].adunit.key;
                    var selectedvalues = targetingCategoryValue[index].adunit.values;

                    for(var v = 0; v < selectedvalues.length; v++) {
                      innerCounter++;
                      var children = [{
                        'logicalOperator': 'AND', 'children': [
                          {'keyId': selectedkey.value, 'isAudienceSegment':(selectedkey.value === '000000'),'operator': 'IS', 'valueIds': [selectedvalues[v].value]}
                        ]
                      }];
                      var obj = {'logicalOperator': 'OR', 'children': children};
                      optionValues.push({'type': targetingType, 'action': null, 'name': selectedkey.label + ' - ' + selectedvalues[v].label, 'id': selectedvalues[v].value, 'obj': obj});

                    }
                    selectedOptionValues.push(optionValues);
                    keyValueOptions.push(optionValues);
                    if(innerCounter != 0) {
                      outerCounter *= innerCounter;
                    }
                  }else {
                    innerCounter++;
                    var targetObj = {'type': targetingType, 'action': targetingCategoryValue[index].action, 'name': targetingCategoryValue[index].adunit.name, 'id': targetingCategoryValue[index].adunit.id};
                    if(targetingType === 'Video Position')
                      targetObj['obj'] = targetingCategoryValue[index].adunit;

                    optionValues.push(targetObj);
                  }
                }
              });

              //pushing the option values array of particular segment type
              if(targetingType === 'Key-Values') {
                //selectedOptionValues.push(optionValues);
                selectedSegmentValue[this.configMap[targetingType]] = keyValueOptions;
              } else {
                selectedOptionValues.push(optionValues);
                selectedSegmentValue[this.configMap[targetingType]] = optionValues;
                if(innerCounter != 0) {
                  outerCounter *= innerCounter;
                }
              }
            }
          }
        });
        if(devSegmentFlag) {
          selectedOptionValues.push(devManufOptionValues);
          selectedSegmentValue['Device Manufacturer'] = devManufOptionValues;
          outerCounter *= devManufOptionValues.length;
        } else if(opSystemSegmentFlag) {
          selectedOptionValues.push(operSysOptionValues);
          selectedSegmentValue['Operating System'] = operSysOptionValues;
          outerCounter *= operSysOptionValues.length;
        }
        else if(inventorySizeSegmentFlag) {
          selectedOptionValues.push(inventorySizesOptionValues);
          selectedSegmentValue['Inventory Sizes'] = inventorySizesOptionValues;
          outerCounter *= inventorySizesOptionValues.length;
        }
      }

      var optionalApiName = this.optionalMap[productNameOptions[prodIdx].value];
      switch(productNameOptions[prodIdx].value) {
        case 'Frequency Cap':
          selectedOptions.push(productNameOptions[prodIdx].value);
          if(record[optionalApiName])
            var frequencyValue = this.stringifyFreqCap(record[optionalApiName]);
          else
            frequencyValue = '';
          selectedOptionValues.push([{'type': 'Frequency Cap', 'name': frequencyValue}]);
          selectedSegmentValue[this.optionalMap[productNameOptions[prodIdx].value]] = [{'type': 'Frequency Cap', 'name': frequencyValue}];
          break;
        /* case 'Inventory Sizes':
          selectedOptions.push(productNameOptions[prodIdx].value);
          if(record[optionalApiName])
            var inventorySizeValue = this.stringifyInvenSize(record[optionalApiName]);
          else
            var inventorySizeValue = '';
          selectedOptionValues.push([{'type': 'Inventory Sizes', 'name': inventorySizeValue}]);
          selectedSegmentValue[this.optionalMap[productNameOptions[prodIdx].value]] = [{'type': 'Inventory Sizes', 'name': inventorySizeValue}];
          break; */
        case 'Rate Type':
          selectedOptions.push(productNameOptions[prodIdx].value);
          selectedOptionValues.push([{'name': record[optionalApiName], 'type': 'Rate Type'}]);
          selectedSegmentValue[this.optionalMap[productNameOptions[prodIdx].value]] = [{'name': record[optionalApiName], 'type': 'Type'}];
          break;
        case 'Type':
          selectedOptions.push(productNameOptions[prodIdx].value);
          selectedOptionValues.push([{'name': record[optionalApiName], 'type': 'Type'}]);
          selectedSegmentValue[this.optionalMap[productNameOptions[prodIdx].value]] = [{'name': record[optionalApiName], 'type': 'Type'}];
          break;
        case 'Priority':
          selectedOptions.push(productNameOptions[prodIdx].value);
          selectedOptionValues.push([{'name': record[optionalApiName], 'type': 'Priority'}]);
          selectedSegmentValue[this.optionalMap[productNameOptions[prodIdx].value]] = [{'name': record[optionalApiName], 'type': 'Priority'}];
          break;
      }

      if(productNameOptions[prodIdx].isCustom) {
        selectedOptions.push(productNameOptions[prodIdx].value);
        selectedOptionValues.push([{'name': productNameOptions[prodIdx].value, 'type': 'custom'}]);
        selectedSegmentValue[productNameOptions[prodIdx].value] = [{'name': [productNameOptions[prodIdx].value], 'type': 'custom'}];
        totalOptionList.push({"value": productNameOptions[prodIdx].value, "label": productNameOptions[prodIdx].value, "isCustom": true});
      }
    }

    //assigning it to the UI
    component.set("v.availableOptions", totalOptionList);
    component.set("v.selectedOptionKeyWithValues", selectedSegmentValue);
    component.set("v.totalProductCount", outerCounter);
    component.set("v.requiredOptions", requiredOptions);
    component.set("v.selectedOptions", selectedOptions);
    component.set("v.selectedOptionValues", selectedOptionValues);

  },
  updateJson: function(component) {
    var record = component.get("v.record");
    var optionalSelectedValue = [];
    var selectedOptions = component.get("v.selectedOptions");
    var selectedSegments = component.get("v.selectedOptionKeyWithValues");
    var updatedOption = [];

    var productNameOptionValue = [];
    for(var index = 0; index < selectedOptions.length; index++) {
      if(selectedOptions[index] === 'Template Name') {
        updatedOption.push([{'name': record['Name'], 'type': 'Template Name'}]);
        optionalSelectedValue.push({"value": selectedOptions[index], "isCustom": false});
      }
      else {
        if(this.configMap && this.configMap[selectedOptions[index]]) {
          var requiredApiName = this.configMap[selectedOptions[index]];
          if(requiredApiName === 'Key-Values') {
            var keyValuesOptions = selectedSegments[requiredApiName];
            for(var j = 0; j < keyValuesOptions.length; j++)
              updatedOption.push(keyValuesOptions[j]);
          }
          else
            updatedOption.push(selectedSegments[requiredApiName]);
          optionalSelectedValue.push({"value": selectedOptions[index], "isCustom": false});
        }
        else if(this.optionalMap && this.optionalMap[selectedOptions[index]]) {
          var optionalApiName = this.optionalMap[selectedOptions[index]];
          if(selectedOptions[index] === 'Frequency Cap') {
            if(record[optionalApiName])
              var frequencyValue = this.stringifyFreqCap(record[optionalApiName]);
            else
              frequencyValue = '';
            updatedOption.push([{'name': frequencyValue, 'type': 'Frequency Cap'}]);
            optionalSelectedValue.push({"value": selectedOptions[index], "isCustom": false});
          }
          /* else if(selectedOptions[index] === 'Inventory Sizes') {
            if(record[optionalApiName])
              var inventorySizeValue = this.stringifyInvenSize(record[optionalApiName]);
            else
              inventorySizeValue = '';
            updatedOption.push([{'name': inventorySizeValue, 'type': 'Inventory Sizes'}]);
            optionalSelectedValue.push({"value": selectedOptions[index], "isCustom": false});
          } */
          else if(selectedOptions[index] === 'Rate Type') {
            updatedOption.push([{'name': record[optionalApiName], 'type': 'Rate Type'}]);
            optionalSelectedValue.push({"value": selectedOptions[index], "isCustom": false});
          }
          else {
            updatedOption.push([{'name': record[optionalApiName], 'type': selectedOptions[index]}]);
            optionalSelectedValue.push({"value": selectedOptions[index], "isCustom": false});
          }
        }
        else {
          updatedOption.push([{'name': selectedOptions[index], 'type': 'custom'}]);
          optionalSelectedValue.push({"value": selectedOptions[index], "isCustom": true});
        }
      }
      productNameOptionValue.push(selectedOptions[index]);
    }

    component.set('v.selectedOptionValues', updatedOption);
    var productNameOptionValueList = JSON.stringify(optionalSelectedValue);
    component.set('v.record.adsalescloud__Product_Name__c', productNameOptionValueList);
  },
  stringifyFreqCap: function(frequencyCapRecord) {
    var frequencyArray = [];
    var frequencyJson = JSON.parse(frequencyCapRecord.replace(/&quot;/g, '\"'));
    for(var freqIdx = 0; freqIdx < frequencyJson.length; freqIdx++) {
      var freqString = '';
      freqString = frequencyJson[freqIdx].maxImpressions + ' impressions per ' + frequencyJson[freqIdx].numTimeUnits + ' ' + frequencyJson[freqIdx].timeUnit;
      frequencyArray.push(freqString);
    }
    var freqConvertedString = frequencyArray.toString();
    return freqConvertedString;
  },
  stringifyInvenSize: function(inventorysizeRecord) {
    var inventoryArray = [];
    var inventoryJson = JSON.parse(inventorysizeRecord.replace(/&quot;/g, '\"'));
    for(var invenIdx = 0; invenIdx < inventoryJson.length; invenIdx++) {
      var invenString = '';
      invenString = inventoryJson[invenIdx].fullDisplayString;
      inventoryArray.push(invenString);
    }
    var invenConvertedString = inventoryArray.toString();
    return invenConvertedString;
  },

  addInputToOptions: function(component) {
    component.set('v.errorMsg', '');
    var selected = component.get("v.selectedOptions");
    var availableOptions = component.get("v.availableOptions");
    var inputTextKey = component.get("v.inputText");
    if(!$A.util.isEmpty(inputTextKey) && inputTextKey.replace(/\s/g, '').length > 0) {
      var inputTextValue = component.get("v.inputText");
      availableOptions.push({"value": inputTextValue, "label": inputTextKey, "isCustom": true});
      var keyList = Object.keys(this.optionalMap);
      var counter = 1;
      keyList.forEach(function(value) {
        if(value.indexOf(inputTextKey + '_') == 0) {
          counter++;
        }
      });
      if(counter > 1) {
        inputTextKey += '_' + counter;
        //this.optionalMap[inputTextKey] = inputTextValue;
      } else {
        //this.optionalMap[inputTextKey] = inputTextValue;
      }
      selected.push(inputTextValue);
      //component.set("v.inputTextList", inputTextList);
      component.set("v.availableOptions", availableOptions);
      component.set("v.selectedOptions", selected);
      component.set("v.inputText", '');
    } else {
      component.set('v.errorMsg', 'Please input text to add it to the Selected Name Variables.');
      component.set("v.inputText", '');
    }

  },
  selectedOptionsChanged: function(component, event) {
    var options = component.get("v.availableOptions");
    var selected = component.get("v.selectedOptions");
    var keysList = [];
    options.forEach(function(value) {
      keysList.push(value.value);
    });
    keysList.forEach(function(value) {
      if(!selected.includes(value)) {
        options.forEach(function(option, index) {
          if(option.isCustom == true && option.value == value)
            options.splice(index, 1);
        });
      }
    });
    component.set("v.availableOptions", options);
  }
})