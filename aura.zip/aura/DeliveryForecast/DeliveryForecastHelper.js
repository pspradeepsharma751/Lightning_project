({
  getDeliveryForecast: function(component) {
    var recordId = component.get('v.recordId');
    var self = this;
    this.fetchData(component, 'getDeliveryForecast',
      {
        recordId: recordId,
        apiName: component.get('v.sobjectName')
      }, function(res) {
        console.log('==res data', JSON.stringify(res));
        if(res.status == 'OK') {
          if(res.data)
            component.set('v.data', res.data);
          else
          component.set('v.error','No Delivery data');

        } else {
          component.set('v.error', res.message);
        }
        component.set('v.loading',false);
      });

  }
});