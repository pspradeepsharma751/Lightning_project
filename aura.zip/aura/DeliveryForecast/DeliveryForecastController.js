({
  doInit: function(component, event, helper) {
    component.set('v.cval', '<style>.slds-modal__container{min-width: 60rem;}</style>');
    helper.getDeliveryForecast(component);
  },
  gotToRecord: function(component, event, helper) {
    if(component.get('v.isLightning')) {
        $A.get('e.force:closeQuickAction').fire();
    } 
      else{
        var navEvt = $A.get('e.force:navigateToSObject');
        navEvt.setParams({
          'recordId': component.get('v.recordId'),
          'slideDevName': 'detail'
        });
        navEvt.fire();
      }
  }
});