({
  doInit: function(component) {
    this.fetchData(component, 'getProposalLineItemRecord', {
      'recordId': component.get('v.recordId')
    }, function(response) {
      component.set('v.record', JSON.parse(response));
      /*var rawDate = component.get("v.record").adsalescloud__Start_Date__c;
      var formattedDate = $A.localizationService.formatDate(rawDate, "yyyy-MM-ddTHH:mm:ss");
      component.set("v.startdate", formattedDate);
      var rawDate1 = component.get("v.record").adsalescloud__End_Date__c;
      var formattedDate1 = $A.localizationService.formatDate(rawDate1, "yyyy-MM-ddTHH:mm:ss");
      component.set("v.enddate", formattedDate1);*/

    }, function(errors) {
      var errorMessage = errors[0].message;
    });
  }
});