({
  doInit: function(component, event, helper) {
    if(window.location.host.indexOf('lightning') >= 0) {
      component.set('v.lightning', true);
    }
    helper.calculateQtyNetCost(component);
  },
  checkError: function(component, event, helper) {
    if(component.get('v.item.start_date')) {
      component.set('v.item.errors.start_date.error', '');
    }
    else {
      component.set('v.item.errors.start_date.error', 'true');
    }
    if(component.get('v.item.end_date')) {
      component.set('v.item.errors.end_date.error', '');
    }
    else {
      component.set('v.item.errors.end_date.error', 'true');
    }
    var proposalItem = component.get('v.item');
    if(!$A.util.isEmpty(proposalItem.quantity)) {
      component.set('v.item.errors.quantity.msg', '');
      if(parseInt(proposalItem.quantity) < 1) {
        component.set('v.item.errors.quantity.msg', 'Minimum value 1');
      }
    }
    else {
      component.set('v.item.errors.quantity.msg', 'Value is required');
    }
    if(proposalItem.lineItemType == 'Sponsorship' ||
       proposalItem.lineItemType == 'House' || 
       proposalItem.lineItemType == 'Network') {
        	
        if(!$A.util.isEmpty(proposalItem.goal)) {
            component.set('v.item.errors.goal.msg', '');
            if(parseInt(proposalItem.goal) < 1) {
                component.set('v.item.errors.goal.msg', 'Minimum value 1');
            }
            if(parseInt(proposalItem.goal) > 100) {
                component.set('v.item.errors.goal.msg', 'Maximum value 100');
            }
        }
        else {
            component.set('v.item.errors.goal.msg', 'Value is required');
        }  
    }
   
  },
  showModal: function(component) {
    var flag = component.get('v.showModal');
    component.set('v.showModal', !flag);
  },
  grossRateChangeHandler: function(component) {
    var item = component.get('v.item');
    item.net_rate = parseFloat(item.gross_rate * (1 - item.agency_commission));
    component.set('v.item', item);
  },
  netRateChangeHandler: function(component) {
    var item = component.get('v.item');
    item.gross_rate = parseFloat(item.net_rate / (1 - item.agency_commission));
    component.set('v.item', item);
  },
  quantityChangeHandler: function(component) {
    var item = component.get('v.item');
    if($A.util.isEmpty(item.quantity)) {
      item.errors.quantity.msg = 'Value is required';
    }
    else if(item.quantity < 1 ) {
      item.errors.quantity.msg = 'Minimum value 1';
    }
    else {
      item.errors.quantity.msg = '';
    }
    if(item.quantity > 0 && (item.lineItemType === 'Price Priority' || item.lineItemType === 'Click Tracking Only')) {
      item.limitType = 'Lifetime';
    }
    component.set('v.item', item);
  },
  calculateQtyNetCost: function(component, event, helper) {
    helper.calculateQtyNetCost(component);
  }
});