({
  calculateQtyNetCost: function(component) {
    var item = component.get('v.item');
    var startDate = item.start_date;
    var endDate = item.end_date;
    //component.set("v.item.errors.start_date.error", "");
    //component.set("v.item.errors.end_date.error" , "");

    if(startDate && endDate) {
      var startDateObj = new Date(startDate);
      startDateObj.setMinutes(startDateObj.getMinutes() + (new Date().getTimezoneOffset() + component.get('v.timezoneOffsetMinutes')));
      var endDateObj = new Date(endDate);
      endDateObj.setMinutes(endDateObj.getMinutes() + (new Date().getTimezoneOffset() + component.get('v.timezoneOffsetMinutes')));
      if(item.rate_type === 'CPD') {
        var quantity;// = ((d2.getTime() - d1.getTime()) / (60000 * 60 * 24)) + 1;
        startDateObj.setHours(0); startDateObj.setMinutes(0);
        var days = Math.floor((endDateObj - startDateObj) / (1000 * 60 * 60 * 24));
        if(endDateObj.getHours() === 0 && endDateObj.getMinutes() <= 1) {
          if(endDateObj.getMinutes() === 0) {
            quantity = days + 1;
          }
          else {
            quantity = days;
          }
        }
        else {
          quantity = days + 1;
        }
        item.quantity = quantity;
      }
    }
    else {
      /*if(!startDate){
          component.set("v.item.errors.start_date.error", "true");
      }
      if(!endDate){
          component.set("v.item.errors.end_date.error" , "true");
      }*/
      item.quantity = 0;
    }
    if(item.rate_type === 'Flat Fee') {
      item.quantity = 1;
    }
    if(item.lineItemType != 'Sponsorship' && 
       item.lineItemType != 'House' && 
       item.lineItemType != 'Network') {
        
        component.set('v.disabledGoal', true);
        component.set('v.goalInputType', true)
        component.set('v.displayFormatter', true)
    } 
   
    component.set('v.item', item);
  },
});