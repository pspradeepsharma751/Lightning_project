({
	lineItemObject : {
        'adsalescloud__Line_Item_Type__c': 'Standard',
        'adsalescloud__Line_Item_Priority__c': 'Normal',
        'adsalescloud__Line_Item_Priority_Rating__c': 8,
        'startDateTime': {},
        'endDateTime': {},
        'formattedStartDate':{},
        'formattedEndDate':{},
        'adsalescloud__Deliver_Impressions__c': 'Frontloaded',
        'adsalescloud__Display_Creatives__c': 'One_or_more',
        'adsalescloud__Rotate_Creatives__c': 'Optimized',
        'goalType':'Max_Available',
        'unitType':'Impressions',
        'units': null,
        'advertiserId' : '',
        'disableSameAdvertiser' : false,
        'advertiserExclusion' : true,
        'adsalescloud__Time_Zone__c' :  '',
        'unlimitedEndDateTime' : false
    }, 
    
    availabilityForecastOptionsObject : {
        'includeTargetingCriteriaBreakdown' : true,
        'includeContendingLineItems' : true,
    },
    
    doInit : function(component){
        component.set("v.lineItemObject", this.lineItemObject);
        component.set("v.availabilityForecastOptionsObject", this.availabilityForecastOptionsObject);
        //setting minimum values for start and end dates
        var minStartDate = new Date();
        var minEndDate = new Date();
        minStartDate.setMinutes(minStartDate.getMinutes() + 10);
        component.set('v.minStartDate', minStartDate);
        var startDate = new Date();
        startDate.setDate(startDate.getDate()+2);
        startDate.setHours(0);
        startDate.setMinutes(0);
        startDate.setSeconds(0);
        var endDate = new Date();
        endDate.setDate(endDate.getDate()+2);
        endDate.setMonth(endDate.getMonth() + 1);
        endDate.setHours(23);
        endDate.setMinutes(59);
        endDate.setSeconds(0);
        component.set('v.lineItemObject.startDateTime', startDate.toISOString()); //setting default value for start Date
       	component.set('v.lineItemObject.endDateTime', endDate.toISOString()); //setting default value for end Date
        component.set('v.minEndDate',startDate.toISOString());
    }, 
    
    toggleEndDateValue: function(component, event){
        component.set('v.displayEndDateField', false);
        component.set('v.minEndDate', component.get('v.lineItemObject.startDateTime'));
        component.set('v.displayEndDateField', true);
    },
    
    onLineItemTypeChange : function(component,event){
        var lineItemType = component.get("v.lineItemObject.adsalescloud__Line_Item_Type__c");
        if(lineItemType == 'Standard'){
            component.set("v.displayPriority", true);
            component.set("v.lineItemObject.adsalescloud__Line_Item_Priority__c", "Normal");
            component.set("v.lineItemObject.adsalescloud__Line_Item_Priority_Rating__c",8);
            component.set("v.lineItemObject.units",null);
            component.set("v.lineItemObject.adsalescloud__Deliver_Impressions__c", "Frontloaded");
            component.set("v.displayUnlmtdEndDate", false);
        }
        else{
            component.set("v.displayPriority", false);
            component.set("v.lineItemObject.adsalescloud__Line_Item_Priority_Rating__c",4);
            component.set("v.lineItemObject.units",null);
            component.set("v.lineItemObject.adsalescloud__Deliver_Impressions__c", null);
            component.set("v.lineItemObject.unitType","Impressions");
            component.set("v.displayUnlmtdEndDate", true);
        }
    },
    
    onLineItemPriorityChange: function(component, event) {
    var lineItemPriority = component.get("v.lineItemObject.adsalescloud__Line_Item_Type__c");
        if(lineItemPriority == 'High'){
            component.set("v.lineItemObject.adsalescloud__Line_Item_Priority_Rating__c", 6);
        }
        else if(lineItemPriority == 'Normal')
            component.set("v.lineItemObject.adsalescloud__Line_Item_Priority_Rating__c", 8);
        else if(lineItemPriority == 'Low')
            component.set("v.lineItemObject.adsalescloud__Line_Item_Priority_Rating__c", 10)
 	 },
    
    onGoalTypeChange: function(component, event) {
       if(component.get("v.lineItemObject.goalType") === 'Max_Available')
           component.set("v.lineItemObject.unitType","Impressions");
       component.set("v.lineItemObject.units",null);
    },
    
    createTimezoneSelectComponent: function(component) {
	var action = component.get('c.fetchPicklistValues');
    action.setParams({
      'pickListFieldName': component.get('v.timeZoneAPIName'),
    });
    action.setCallback(this,
      function(response) {
        var state = response.getState();
        if(state === 'SUCCESS') {
          // create a empty array var for store dependent picklist values for controller field)
          var dependentFields = [];
          var listPicklistValues = response.getReturnValue();
          for(var i = 0; i < listPicklistValues.length; i++) {
            dependentFields.push({
              class: 'optionClass',
              label: listPicklistValues[i].label,
              value: listPicklistValues[i].value
            });
          }
          component.set('v.options', dependentFields);
           window.setTimeout(
                $A.getCallback(function(){
                component.set('v.lineItemObject.adsalescloud__Time_Zone__c','America/New_York'); 
                })
            ,10);  
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
          component.set('v.errorMessage', errorMessage);
        }
      }
    );
    $A.enqueueAction(action);
  },
    
    getSelectedAccRecord: function(component) {
    var accRecordId = component.get('v.selectedRecord.Id');
    if(accRecordId) {
      var getLookUpFieldRecords = component.get('c.getLookUpFieldRecords');
      getLookUpFieldRecords.setParams({
        'lookupRecordId': accRecordId
      });
      getLookUpFieldRecords.setCallback(this, function(response) {
        var state = response.getState();
        if(component.isValid() && state === 'SUCCESS') {
          var rsp = JSON.parse(response.getReturnValue());
          component.set('v.lineItemObject.advertiserId', rsp.oppRecordValue.adsalescloud__Ad_Server_Id__c);
        }
        else if(state === 'ERROR') {
          var errorMessage = response.getError()[0].message;
        }
      });
      $A.enqueueAction(getLookUpFieldRecords);
    }
  },
    getTimeZoneOffset: function(component, event) {
        var timeZone = component.get('v.lineItemObject.adsalescloud__Time_Zone__c');
        if(timeZone) {
          var getTimezoneOffsetMin = component.get('c.getTimezoneOffsetMinutes');
          getTimezoneOffsetMin.setParams({
            'timezoneId': timeZone
          });
          getTimezoneOffsetMin.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
              component.set('v.timeZoneOffsetMinutes',  response.getReturnValue());
              this.validateData(component,event);  
            }
            else if(state === 'ERROR') {
              var errorMessage = response.getError()[0].message;
            }
          });
          $A.enqueueAction(getTimezoneOffsetMin);
        }
    },
    
    validateData: function(component, event) {
        component.set('v.data','');
        var isValidData = true;
        var startDateTime = component.get('v.lineItemObject.startDateTime');
        var endDateTime = component.get('v.lineItemObject.endDateTime');
        var startTime = new Date(startDateTime);
        var endTime = new Date(endDateTime);
        var currentTime = new Date();
        startTime = startTime.setMinutes(startTime.getMinutes() + (-startTime.getTimezoneOffset()) - component.get('v.timeZoneOffsetMinutes'));
        endTime = endTime.setMinutes(endTime.getMinutes() + (-endTime.getTimezoneOffset()) + component.get('v.timeZoneOffsetMinutes'));
        //currentTime = currentTime.setMinutes(currentTime.getMinutes() + (currentTime.getTimezoneOffset()) + component.get('v.timeZoneOffsetMinutes'));
        
        if($A.util.isEmpty(startDateTime))
        {
            isValidData = false; 
            //component.set('v.error', 'Required value is  missing: Start Time'); 
            component.set("v.toast", {"message": "Error: Missing Start Date Time", "type" : "error", "closable" : true, "autoHide" : true});
        }
        else if($A.util.isEmpty(endDateTime) && !component.get('v.lineItemObject.unlimitedEndDateTime'))
        {
            isValidData = false; 
            //component.set('v.error', 'Required value is  missing: End Time');  
            component.set("v.toast", {"message": "Error: Missing End Date Time", "type" : "error", "closable" : true, "autoHide" : true});
        }
        else if((endTime < startTime) && !component.get('v.lineItemObject.unlimitedEndDateTime'))
        {
        	isValidData = false; 
            //component.set('v.error', 'End date must be later than the start date.');   
            component.set("v.toast", {"message": "Error: End date must be later than the start date.", "type" : "error", "closable" : true, "autoHide" : true});
        }
        else if(startTime < currentTime)
        {
        	isValidData = false; 
            //component.set('v.error', 'Start date is in the past.');   
            component.set("v.toast", {"message": "Error: Start date is in the past.", "type" : "error", "closable" : true, "autoHide" : true});
        }
        if(isValidData){
            this.checkInventory(component,event);
        }
    },
    
    checkInventory : function(component,event) {
        component.set('v.data','');
        component.set('v.error', '');
        component.set('v.loading',true);
        this.formatDateTime(component);
        console.log(JSON.stringify(component.get("v.lineItemObject"))+'===' + JSON.stringify(component.get("v.availabilityForecastOptionsObject"))+'====' + JSON.stringify(component.get("v.record")));
        if(component.get('v.lineItemObject.unlimitedEndDateTime')){
            component.set('v.lineItemObject.endDateTime', null)
        }
        var self = this;
        this.fetchData(component, 'getCheckInventory',
          {
             lineItemObject:JSON.stringify(component.get("v.lineItemObject")),
             availabilityForecastOptions: JSON.stringify(component.get("v.availabilityForecastOptionsObject")),
             targetingObject: JSON.stringify(component.get("v.record"))
          }, function(res) {
            if(res.status === 'OK') {
                component.set('v.data', res.data);
                Object.keys(res.targetingCriteriaBreakdowns).forEach(function(key){
                    res.targetingCriteriaBreakdowns[key].forEach(function(targetingCriteriaBreakdown){
                    targetingCriteriaBreakdown['targetingCriteriaName'] = (targetingCriteriaBreakdown.targetingCriteriaName || '0') + '';
                    targetingCriteriaBreakdown['availableUnits'] = (targetingCriteriaBreakdown.availableUnits || '0') + '';
                    targetingCriteriaBreakdown['matchedUnits'] = (targetingCriteriaBreakdown.matchedUnits || '0') + '';
                        });
                });
                component.set('v.targetingCriteriaBreakdowns', res.targetingCriteriaBreakdowns);
                res.contendingLineItems.forEach(function(contendingLineItem){
                    contendingLineItem['lineItemId'] = (contendingLineItem.lineItemId || '0') + '';
                    contendingLineItem['pliName'] = (contendingLineItem.pliName || '') + '';
                    contendingLineItem['pliId'] = (contendingLineItem.pliId || '') + '';
                    contendingLineItem['advertiserName'] = (contendingLineItem.advertiserName || '') + '';
                    contendingLineItem['contendingImpressions'] = (contendingLineItem.contendingImpressions || '0') + '';
                });
                component.set('v.contendingLineItems', res.contendingLineItems);
            } else {
              //component.set('v.error', res.message);
                component.set("v.toast", {"message": res.message, "type" : "info", "closable" : true, "autoHide" : true, "timeoutMS":7000});
              console.log('error occurred' + res.message);
            }
          component.set('v.loading',false);
      });
    },
    
    formatDateTime : function(component){
        var startDateTime = component.get('v.lineItemObject.startDateTime');
        if(startDateTime) {
            var startFormattedDate = $A.localizationService.formatDate(startDateTime, 'yyyy-MM-dd HH:mm:ss');
            component.set('v.lineItemObject.formattedStartDate', startFormattedDate);
        }
        
        var endDateTime = component.get('v.lineItemObject.endDateTime');
        if(endDateTime) {
            var endDateFormattedDate = $A.localizationService.formatDate(endDateTime, 'yyyy-MM-dd HH:mm:ss');
            component.set('v.lineItemObject.formattedEndDate', endDateFormattedDate);
        }
    },
    
    
})