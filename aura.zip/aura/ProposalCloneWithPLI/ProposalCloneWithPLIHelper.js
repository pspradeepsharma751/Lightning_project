({
	doInit: function(component) {
        var action = component.get("c.getProposalDetails");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                if(!$A.util.isEmpty(response.getReturnValue().proposalRecord)){
                    component.set('v.proposalRecord',response.getReturnValue().proposalRecord);
                }
                if(response.getReturnValue().pliCount == 0){
                    component.set("v.toast", {"message": "This proposal does not have any products to clone.", "type" : "error", "closable" : true, "autoHide" : false});
            		component.set("v.hasErrors", true);
                }
                
            }
            else if(state === 'ERROR') {
              var errorMessage = response.getError()[0].message;
            }
      });
      $A.enqueueAction(action);
    },
    
    validateProposalRecord: function(component){
        var adServerId = component.get('v.proposalRecord.adsalescloud__Ad_Server_Id__c');
        if(!$A.util.isEmpty(adServerId)){
            component.set("v.toast", {"message": "Synced proposals can only be cloned from the opportunity. Clone the related opportunity to continue.", "type" : "error", "closable" : true, "autoHide" : false});
            component.set("v.hasErrors", true);
        }
        else
            component.set("v.hasErrors", false);
            
        
    }
})