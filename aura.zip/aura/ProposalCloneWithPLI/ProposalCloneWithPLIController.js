({
	doInit : function(component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 60rem;}.panel .slds-modal__content{max-height: calc(100vh - 210px); overflow-y: auto;}</style>');
        helper.doInit(component);
	},
    
    validateProposal: function(component, event, helper){
        helper.validateProposalRecord(component);
    }
    
})