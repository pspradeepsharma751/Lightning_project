({
  showHideModal: function(component,event,helper) {
    component.set('v.currentDate',$A.localizationService.formatDateTime(new Date(),'M/d/Y, h:mm A'));
    var modalContainer = component.find('modalContainer');
    $A.util.toggleClass(modalContainer, 'slds-hide');
    helper.getAvailabilityForecast(component);
  }
});