({
  doInit: function(component, event, helper) {
    helper.initialisation(component);
  },
  reInit: function(component, event, helper) {
    helper.reInit(component);
  },
  update: function(component, event, helper) {
    var mapKeyValueList = component.get('v.depProperty');
    component.set('v.recordTemplate.' + mapKeyValueList.API_Name, event.currentTarget.value);
    if(mapKeyValueList.API_Name === 'adsalescloud__Line_Item_Type__c' ||
      mapKeyValueList.API_Name === 'adsalescloud__Proposal_Billing_Schedule__c' ||
      mapKeyValueList.API_Name === 'adsalescloud__Proposal_Caps_and_Rollovers__c') {
      helper.lineItemDependentHandler(component, event.currentTarget.value);
    }
  },
});