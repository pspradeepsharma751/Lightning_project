({
  initialisation: function(component, event) {
    var mapKeyValueList = component.get('v.depProperty');
    var listOfDependentFields = mapKeyValueList.dependentPickListProperty[component.get('v.selectedControllingFieldValue')];
    var selectedValue = component.get('v.recordTemplate.' + mapKeyValueList.API_Name);
    // create a empty array var for store dependent picklist values for controller field)
    var dependentFields = [];
    var isExistsNSelected = false;
    /*dependentFields.push({
      class: 'optionClass',
      label: '--- None ---',
      value: null
    });*/
    if((!$A.util.isEmpty(listOfDependentFields)) && listOfDependentFields.length > 0) {
      for(var i = 0; i < listOfDependentFields.length; i++) {
        isExistsNSelected = isExistsNSelected ? true : selectedValue ? listOfDependentFields[i] === selectedValue : false;
        dependentFields.push({
          class: 'optionClass',
          label: listOfDependentFields[i],
          value: '' + listOfDependentFields[i] + '',
          selected: selectedValue ? listOfDependentFields[i] === selectedValue : false
        });
      }
      // make disable false for ui:inputselect field
      component.set('v.disabled', false);
    }
    else {
      // make disable false for ui:inputselect field
      component.set('v.disabled', true);
    }
    // set the dependentFields variable values to State(dependent picklist field) on ui:inputselect
    component.set('v.options', dependentFields);
    // Set default when creating new record.
    if(component.get('v.newRecord')) {
      if(mapKeyValueList.API_Name === 'adsalescloud__Rotate_Creatives__c') {
        component.set('v.recordTemplate.adsalescloud__Rotate_Creatives__c', 'Optimized');
      }
      else {
        var selVal = isExistsNSelected?selectedValue :dependentFields.length > 0 ? dependentFields[0].value : 'None';
        component.set('v.recordTemplate.' + mapKeyValueList.API_Name, selVal);
      }
    }
  },
  reInit: function(component) {
    component.set('v.disabled', true);
    var mapKeyValueList = component.get('v.depProperty');
    var listOfDependentFields = mapKeyValueList.dependentPickListProperty[component.get('v.selectedControllingFieldValue')];
    var selectedValue = component.get('v.recordTemplate.' + mapKeyValueList.API_Name);
    var dependentFields = [];
    var lineItemValue = '';
    var lineItemSelectedValue = '';
    if(component.get('v.displayNoneOption')) {
      dependentFields.push({
        class: 'optionClass',
        label: '--None--',
        value: null,
        selected: true
      });
    }

    if((!$A.util.isEmpty(listOfDependentFields)) && listOfDependentFields.length > 0) {
      for(var i = 0; i < listOfDependentFields.length; i++) {
        var optionObject = {
          class: 'optionClass',
          label: listOfDependentFields[i],
          value: '' + listOfDependentFields[i] + '',
          selected: selectedValue ? listOfDependentFields[i] === selectedValue : false
        };
        if(mapKeyValueList.API_Name === 'adsalescloud__Line_Item_Type__c') {
          if((selectedValue === null) || (selectedValue !== null && selectedValue !== listOfDependentFields[i])) {
            lineItemValue = listOfDependentFields[0];
          }
          else {
            lineItemSelectedValue = listOfDependentFields[i];
          }
        }
        dependentFields.push(optionObject);
      }
      //dependentFields[1].selected = true;
      component.set('v.recordTemplate.' + mapKeyValueList.API_Name, dependentFields[0].value);
    }
    // make disable false for ui:inputselect field
    component.set('v.disabled', false);

    // set the dependentFields variable values to State(dependent picklist field) on ui:inputselect
    component.set('v.options', dependentFields);
    //component.set('v.recordTemplate.' + mapKeyValueList.API_Name, dependentFields[0].value);
    component.set('v.disabled', false);
    //Below code is to fire the event everytime when Template type value is changed.
    if(mapKeyValueList.API_Name === 'adsalescloud__Line_Item_Type__c') {
      this.lineItemDependentHandler(component, lineItemSelectedValue ? lineItemSelectedValue : lineItemValue);
    }
  },
  lineItemDependentHandler: function(component, lineItemSelectedValue) {
    var updateRecordEvent = component.getEvent('updateRecordEvent');
    updateRecordEvent.setParams({'updateRecordByEvent': lineItemSelectedValue});
    updateRecordEvent.fire();
  }
});