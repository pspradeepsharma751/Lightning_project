({
    checkProposalSync : function (component, event, helper) {
        	helper.checkProposalSync(component);
        	helper.getCustomSetting(component, event, helper);
    },
    
    doInit : function (component, event, helper) {
        component.set('v.cval', '<style>.slds-modal__container{min-width: 50rem;}.panel .closeIcon{display:none} .slds-modal__content{max-height: calc(100vh - 210px); overflow-y: auto;}</style>');
        component.set("v.readyForDFPError",$A.get("$Label.c.Not_Ready_for_Ad_Server"));
        var action = component.get("c.getReadyForDFPInformation");
        action.setParams({
            recordId:component.get("v.recordId")
        });
        action.setCallback(this,function (response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                var readyForDFPInfo = response.getReturnValue();
                component.set("v.readyForDFPInfo", readyForDFPInfo);
                if(readyForDFPInfo['isAccCreditStatusEnabled'] && readyForDFPInfo['accountCreditStatus'] != 'Active') {
                    component.set("v.showToast",true);
                    component.set("v.message",'The related account does not have an active credit status. Update the account\'s credit status to active to continue.');
                    component.set("v.status",$A.get("$Label.c.ERROR")); 
                } 
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
   
})