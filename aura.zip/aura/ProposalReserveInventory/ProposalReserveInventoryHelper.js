({
	checkProposalSync : function (component, event, helper) {
        var isMasterProposal = component.get("v.proposalRecordFields.adsalescloud__Primary_Proposal__c");
        var associatedAccoundDoubleClickId = component.get("v.proposalRecordFields.adsalescloud__Ad_Server_Account_Id__c");
        //var readyForDFPInfo = component.get('v.readyForDFPInfo');
        component.set("v.sObjectName", "Proposal");
         if(isMasterProposal == undefined || isMasterProposal == null || !isMasterProposal) {
            component.set("v.showToast",true);
            component.set("v.message", "This Proposal requires setting the primary proposal field.");
            component.set("v.status",$A.get("$Label.c.ERROR"));
        } else if(associatedAccoundDoubleClickId == undefined || associatedAccoundDoubleClickId == null) {
            component.set("v.showToast",true);
            component.set("v.message","This Proposal requires the related opportunity\'s account field set. Please set the related opportunity\'s account.");
            component.set("v.status",$A.get("$Label.c.ERROR"));
        }
    },
    
    getCustomSetting : function(component, event, helper) {
        var action = component.get("c.getAccessForAction");
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                var objAction = response.getReturnValue();
				if(!objAction['adsalescloud__Reservation_Proposal_Status__c'].includes(component.get("v.proposalRecordFields.adsalescloud__Status__c"))){
                    component.set("v.showToast",true);
                    component.set('v.message','This Proposal requires the status set to '+objAction['adsalescloud__Reservation_Proposal_Status__c']);
                    component.set("v.status",$A.get("$Label.c.ERROR")); 
                }
                component.set("v.objAction", objAction);
            }
            else{
                component.set('v.message','ERROR occured while getting application settings.');
                component.set('v.messageType', $A.get("$Label.c.ERROR"));
            }
        });
        $A.enqueueAction(action);
	
	},
})