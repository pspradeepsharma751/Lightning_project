({
  doInit: function(component) {
    var inventorySizesJson = component.get('v.record.adsalescloud__Inventory_Sizes__c') || "[]";
    inventorySizesJson = inventorySizesJson.replace(/&quot;/g, '\"');
    var inventorySizes = JSON.parse(inventorySizesJson);
    var type = 'Standard';
    if(inventorySizes[0] && inventorySizes[0].environmentType === 'BROWSER' && inventorySizes[0].companions) {
      type = 'Master/Companions';
    } else if(inventorySizes[0] && inventorySizes[0].environmentType === 'VIDEO_PLAYER') {
      type = 'Video VAST';
    }
    component.set('v.type', type);
    component.set('v.inventorySizes', inventorySizes);
  },
  validate: function(component) {
    var isValid = true;
    var errorMessage = '';
    var checkboxCount = 0;
    var type = component.get('v.type');
    var inventorySizes = component.get('v.inventorySizes');
    if(inventorySizes && inventorySizes.length > 0) {
      loop1:
      for(var index = 0; index < inventorySizes.length; index++) {
        var value = inventorySizes[index];
        if(value.checkbox) {
          checkboxCount++;
        }
        if(!inventorySizes[index].fullDisplayString || inventorySizes[index].fullDisplayString === '') {
          isValid = false;
          errorMessage = 'Each Inventory size row must have a value.';
          break loop1;
        }
        if(type === 'Standard' || type === 'Video VAST') { // set error here for count
          if(value.expectedCreativeCount < 1) {
            isValid = false;
            errorMessage = 'Count must be 1 or greater for each inventory size.';
            break loop1;
          }
          if(value.expectedCreativeCount - parseInt(value.expectedCreativeCount) > 0) {
            isValid = false;
            errorMessage = 'Count must not be decimal for inventory size.';
            break loop1;
          }
          if(type === 'Standard') {
            inventorySizes[index]['companions'] = null;
          }
        }
        if(type === 'Video VAST' || type === 'Master/Companions') {
          for(var col = 0; col < inventorySizes.length; col++) {
            if(index === col) {
              continue;
            }
            if(inventorySizes[index].fullDisplayString === inventorySizes[col].fullDisplayString) {
              isValid = false;
              errorMessage = 'Master size must be unique.';
              break loop1;
            }
          }
          if(!inventorySizes[index]['companions'] || inventorySizes[index]['companions'].length < 1) {
            isValid = false;
            errorMessage = 'Each master size requires at least one companion.';
            break loop1;
          }
        }
      }
      if(isValid && checkboxCount === 0) {   // validate checkboxes here
        isValid = false;
        errorMessage = 'Please specify at least one size for inventory size.';
      }
    } else {
      isValid = false;
      errorMessage = 'One or more Inventory Sizes must be selected.';
    }
    component.set('v.errorMessage', errorMessage);
    if(isValid) {
      component.set('v.record.adsalescloud__Inventory_Sizes__c', JSON.stringify(inventorySizes));
    }
  },
    fetchLabelOptions: function(component, event) {
        this.fetchData(component, 'getLabelOptions', {}, function(response) {
            if(response.status === 'OK') {  
                component.set('v.labelOptions', JSON.parse(response.labelsWrapper));
            }
            else if(response.status === 'AUTH_FAILED'){
                /*if(confirm('User authentication failed while syncing with the Ad Server.\nPlease navigate to Ad Sales User Setup, authorize your Salesforce User with the Ad Server, and try again.')){
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url":"/apex/AdSalesUserSetup"
                });
                urlEvent.fire();
            }*/
            }
                else if(response.status === 'NO_NETWORKS_TO_ACCESS'){
                    /* if(confirm('Please make sure that the user is authorized on the correct network code and try again.')){
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url":"/apex/AdSalesSetup"
                });
                urlEvent.fire();
                }*/
        }
                       });
    },
  getInventorySizeList: function(component) {
    var self = this;
    var isInline = component.get("v.isInline");   
    this.fetchData(component,
      'getAdUnitSizes', {isReadOnly: true},
      function(response) {
         
        if(response.status === 'OK') {
          component.set('v.allSizes', response.targets);
          self.convertInventorySizeList(component, response.targets);
        } else if(response.status === 'AUTH_FAILED'){
            
            if(!isInline){
                if(confirm('User authentication failed while syncing with the Ad Server.\nPlease navigate to Ad Sales User Setup, authorize your Salesforce User with the Ad Server, and try again.')){
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url":"/apex/AdSalesUserSetup"
                    });
                    urlEvent.fire();
                }
            }
            else
                component.set('v.errorMessage', 'User authentication failed while syncing with the Ad Server.\nPlease navigate to Ad Sales User Setup, authorize your Salesforce User with the Ad Server, and try again.');
        }  
            else if(response.status === 'NO_NETWORKS_TO_ACCESS'){
                if(!isInline){
                    if(confirm('User Authorization Network Mismatch: Please navigate to the Ad Sales Setup tab and authorize your user.')){
                        var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url":"/apex/AdSalesSetup"
                        });
                        urlEvent.fire();
                    }
                }
                else
                    component.set('v.errorMessage', 'User Authorization Network Mismatch: Please navigate to the Ad Sales Setup tab and authorize your user.');
            }
                else{
                    component.set('v.errorMessage', 'An unexpected error occurred: ' + response.message);
                    console.log('An unexpected error occurred: ' + response.message);
                }
      });
  },
  convertInventorySizeList: function(component, adUnitSizes) {
    var availableSizes = [];
    var videoSizes = [];
    var allSizes = Object.keys(adUnitSizes);

    for(var index = 0; index < allSizes.length; index++) {
      var inventorySize = adUnitSizes[allSizes[index]];
      if(inventorySize && inventorySize.fullDisplayString && inventorySize.environmentType !== 'VIDEO_PLAYER') {
        availableSizes.push({'label': inventorySize.fullDisplayString, 'value': inventorySize.fullDisplayString});
      } else if(inventorySize && inventorySize.environmentType === 'VIDEO_PLAYER') {
        videoSizes.push({'label': inventorySize.fullDisplayString, 'value': inventorySize.fullDisplayString});
      }
    }
    component.set('v.availableSizes', availableSizes);
    component.set('v.videoSizes', videoSizes);
  }
});