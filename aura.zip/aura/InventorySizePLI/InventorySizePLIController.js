({
  doInit: function(component, event, helper) {
    helper.doInit(component);
    helper.getInventorySizeList(component);
    helper.fetchLabelOptions(component,event);
  },
  onChange: function(component, event, helper) {
    helper.validate(component);
    //component.set("v.inventoryObject.Inventory_Sizes__c", JSON.stringify(component.get("v.inventorySizes")));
  },
  addSizeRow: function(component) {
    var inventorySizes = JSON.parse(JSON.stringify(component.get('v.inventorySizes')));
    inventorySizes.push({
      'checkbox':true,
      'environmentType':null,
      'expectedCreativeCount':1,
      'fullDisplayString':null,
      'adUnitFrequencyCapping':null
    });
    component.set('v.inventorySizes', inventorySizes);
  },
  removeRowHandler: function(component, event) {
    var ind = event.getSource().get('v.value');
    //var inventorySizes = JSON.parse(JSON.stringify(component.get('v.inventorySizes')));
      var inventorySizes = component.get('v.inventorySizes');
    inventorySizes.splice(ind, 1);
    component.set('v.inventorySizes', inventorySizes);
  },
  inventorySizesChangeHandler: function(component, event, helper) {
    helper.validate(component);
  },
  showCompanionModal: function(component,event) {
    var index = event.currentTarget.getAttribute('data-index');
    component.set('v.defaultIndex', index);
    var inventorySizes = component.get('v.inventorySizes');
    var selectedOptions = [];
    if(inventorySizes[index] && inventorySizes[index].companions) {
      var item = inventorySizes[index];
      for(var i = 0; i < item.companions.length; i++) {
        selectedOptions.push(item.companions[i].fullDisplayString);
      }
    }
    component.set('v.selectedCompanionOptions', selectedOptions);
    component.set('v.showCompanionModal', true);
  },
  showMasterModal: function(component,event) {
    var index = event.currentTarget.getAttribute('data-index');
    component.set('v.defaultIndex', index);
    var inventorySizes = JSON.parse(JSON.stringify(component.get('v.inventorySizes')));
    var selectedOptions = [];
    if(inventorySizes[index] && inventorySizes[index].fullDisplayString) {
      selectedOptions.push(inventorySizes[index].fullDisplayString);
    }
    component.set('v.selectedMasterOptions', selectedOptions);
    component.set('v.showMasterModal', true);

  },
  masterChangeHandler: function(component) {
    var allSizes = component.get('v.allSizes');
    var index = component.get('v.defaultIndex');
    if(index === -1) return;
    var inventorySizes = JSON.parse(JSON.stringify(component.get('v.inventorySizes')));

    var item = inventorySizes[index];
    var type = component.get('v.type');
    var selectedOptions = component.get('v.selectedMasterOptions');
    var selectedSize = {};
    for(var i = 0; i < selectedOptions.length; i++) {
      selectedSize = allSizes[selectedOptions[i]];
    }
    if(type !== 'Standard') {
        selectedSize['companions'] = JSON.parse(JSON.stringify(item['companions'] || []));
    }
    if(type === 'Standard' || type === 'Video VAST') {
      selectedSize['expectedCreativeCount'] = item['expectedCreativeCount'];
      selectedSize['adUnitFrequencyCapping'] = item['adUnitFrequencyCapping'];
    }
    inventorySizes[index] = selectedSize;
    component.set('v.inventorySizes', inventorySizes);
  },
  companionChangeHandler: function(component) {
    var allSizes = component.get('v.allSizes');
    var index = component.get('v.defaultIndex');
    if(index === -1) return;
    var inventorySizes = component.get('v.inventorySizes');
    var item = inventorySizes[index];
    var selectedOptions = component.get('v.selectedCompanionOptions');
    var selectedSizes = [];
    for(var i = 0; i < selectedOptions.length; i++) {
      selectedSizes.push(JSON.parse(JSON.stringify(allSizes[selectedOptions[i]] || [])));
    }
    item['companions'] = selectedSizes;
    inventorySizes[index] = item;
    component.set('v.inventorySizes', inventorySizes);
  },
});