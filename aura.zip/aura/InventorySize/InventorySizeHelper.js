({
  getInventorySizeList: function(component, event) {
    var self = this;
    var firstTime = component.get('v.firstTime');
    var isInline = component.get("v.isInline"); 
    this.fetchData(component,
      'getAdUnitSizes', {isReadOnly: false,
                         isFromPLI: false},
      function(response) {
          if(response.status === 'OK'){
              var allSize = response.allSize;
              if(allSize !== '') {
                  self.convertInventorySizeList(component, allSize);
                  component.set('v.allSizesMap', allSize);
                  if(firstTime) {
                      self.initializeSelected(component);
                      component.set('v.firstTime', false);
                  }
       		 }
          }
          else if(response.status === 'AUTH_FAILED'){
              if(!isInline){
                  if(confirm('User authentication failed while syncing with the Ad Server.\nPlease navigate to Ad Sales User Setup, authorize your Salesforce User with the Ad Server, and try again.')){
                      var urlEvent = $A.get("e.force:navigateToURL");
                      urlEvent.setParams({
                          "url":"/apex/AdSalesUserSetup"
                      });
                      urlEvent.fire();
                  }
            }
            else
                component.set('v.errorMessage', 'User authentication failed while syncing with the Ad Server.\nPlease navigate to Ad Sales User Setup, authorize your Salesforce User with the Ad Server, and try again.');
        }
            else if(response.status === 'NO_NETWORKS_TO_ACCESS'){
                if(!isInline){
                    if(confirm('User Authorization Network Mismatch: Please navigate to the Ad Sales Setup tab and authorize your user.')){
                        var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url":"/apex/AdSalesSetup"
                        });
                        urlEvent.fire();
                    }
                }
                else
                    component.set('v.errorMessage', 'User Authorization Network Mismatch: Please navigate to the Ad Sales Setup tab and authorize your user.');
            }
                else{
                    component.set('v.errorMessage', 'An unexpected error occurred: ' + response.message);
                    console.log('An unexpected error occurred: ' + response.message);
                }
        
      });
  },
  initializeSelected: function(component) {
    var record = component.get('v.record');
    var inventoryType = 'Standard';  		//= record.adsalescloud__Inventory_Type__c?record.adsalescloud__Inventory_Type__c:inventoryType;
    var inventoryTypes = [
      {'label': 'Standard', 'value': 'Standard'}
    ];
    if(record.adsalescloud__Rate_Type__c === 'Viewable CPM') {
      inventoryTypes.push({'label': 'Video VAST', 'value': 'Video VAST'});
    } else {
      inventoryTypes.push({'label': 'Master/Companions Roadblock', 'value': 'Master/Companions Roadblock'});
      if(component.get('v.videoEnabled')) {
        inventoryTypes.push({'label': 'Video VAST', 'value': 'Video VAST'});
      }
    }
    component.set('v.inventoryTypes', inventoryTypes);
    var inventorySize = record.adsalescloud__Inventory_Sizes__c;
    if(inventorySize) {
      inventorySize = JSON.parse(inventorySize.replace(/&quot;/g, '\"'));
      inventoryType = component.get('v.record.adsalescloud__Inventory_Size_Type__c');
    } else {
      inventorySize = null;
    }
    this.setInventorySizes(component, inventoryType, inventorySize);
    component.set('v.inventoryType', inventoryType);
  },
  updateInventoryTypes: function(component) {
    var record = component.get('v.record');
    var inventoryTypes = [
      {'label': 'Standard', 'value': 'Standard'},
      {'label': 'Master/Companions Roadblock', 'value': 'Master/Companions Roadblock'},
      {'label': 'Video VAST', 'value': 'Video VAST'}
    ];
    if(!component.get('v.videoEnabled')) {
      inventoryTypes.splice(2,1);
    }
    if(record.adsalescloud__Rate_Type__c === 'Viewable CPM') {
      inventoryTypes.splice(1, 1);
      component.set('v.inventoryType', 'Standard');
      component.set('v.standardInventorySizesList', []);
      component.set('v.masterInventorySizesList', [{}]);
      component.set('v.videoInventorySizesList', [{}]);
    }
    component.set('v.inventoryTypes', inventoryTypes);
  },
  convertInventorySizeList: function(component, adUnitSizes) {
    var availabelInventorySizesList = [];
    var availabelVideoSizesList = [];
    var allSizes = Object.keys(adUnitSizes);

    for(var index = 0; index < allSizes.length; index++) {
      var inventorySize = adUnitSizes[allSizes[index]];
      if(inventorySize && inventorySize.fullDisplayString && inventorySize.environmentType !== 'VIDEO_PLAYER') {
        availabelInventorySizesList.push({'label': inventorySize.fullDisplayString, 'value': inventorySize.fullDisplayString});
      } else if(inventorySize && inventorySize.environmentType === 'VIDEO_PLAYER') {
        availabelVideoSizesList.push({'label': inventorySize.fullDisplayString, 'value': inventorySize.fullDisplayString});
      }
    }
    component.set('v.availabelInventorySizesList', availabelInventorySizesList);
    component.set('v.availabelVideoSizesList', availabelVideoSizesList);

  },
  saveSelectedItems: function(component, event, selectedInventorySizes, inventoryType) {
    component.set('v.record.adsalescloud__Inventory_Sizes__c', JSON.stringify(selectedInventorySizes));
    component.set('v.record.adsalescloud__Environment_Type__c', inventoryType === 'Video VAST' ? 'Video Player' : 'Browser');
    component.set('v.record.adsalescloud__Inventory_Size_Type__c', inventoryType);
  },
  showModal: function(component) {
    var modalContainer = component.find('modalContainer');
    $A.util.removeClass(modalContainer, 'slds-hide');
  },
  closeModal: function(component) {
    var modalContainer = component.find('modalContainer');
    $A.util.addClass(modalContainer, 'slds-hide');
  },
  getSelectedInventorySizeList: function(component, event) {
    var availabelInventorySizes = component.get('v.availabelInventorySizes');
    var selectedInventorySizesList = event.getParam('inventorySizeList');
    var inventorySizesList = [];
    var inventorySizesToSave = [];
    for(var i = 0; i < selectedInventorySizesList.length; i++) {
      inventorySizesList[i] = selectedInventorySizesList[i].label;
      inventorySizesToSave[i] = availabelInventorySizes[0][selectedInventorySizesList[i].label];
    }
  },
  addRow: function(component, event) {
    var inventoryType = component.get('v.inventoryType');
    var rowObjects;
    if(inventoryType === 'Master/Companions Roadblock') {
      rowObjects = component.get('v.masterInventorySizesList');
      rowObjects.push({});
      component.set('v.masterInventorySizesList', rowObjects);
    } else if(inventoryType === 'Video VAST') {
      rowObjects = component.get('v.videoInventorySizesList');
      rowObjects.push({});
      component.set('v.videoInventorySizesList', rowObjects);
    }
  },
  setInventorySizesList: function(component, event) {
    var selectedList = event.getParam('selectedList');
    var masterVal = event.getParam('masterVal');
    var inventoryType = component.get('v.inventoryType');
    var allSizesMap = component.get('v.allSizesMap');
    var selectedSizeList = [];
    var selectedObj = {};

    if(!selectedList) return;
    for(var i = 0; i < selectedList.length; i++) {
      selectedSizeList.push(allSizesMap[selectedList[i]]);
    }
    selectedSizeList = selectedSizeList.slice();

    if(masterVal && inventoryType !== 'Standard') {
      var index = event.getParam('index');
      selectedObj = Object.assign({}, allSizesMap[masterVal]);
      selectedObj['companions'] = selectedSizeList;
      if(inventoryType === 'Master/Companions Roadblock') {
        var masterInventorySizesList = component.get('v.masterInventorySizesList');
        masterInventorySizesList[index] = selectedObj;
        component.set('v.masterInventorySizesList', masterInventorySizesList);
        component.set('v.record.adsalescloud__Inventory_Sizes__c', JSON.stringify(masterInventorySizesList));

      } else if(inventoryType === 'Video VAST') {
        var videoInventorySizesList = component.get('v.videoInventorySizesList');
        videoInventorySizesList[index] = selectedObj;
        component.set('v.videoInventorySizesList', videoInventorySizesList);
        component.set('v.record.adsalescloud__Inventory_Sizes__c', JSON.stringify(videoInventorySizesList));
      }

    } else {
      component.set('v.standardInventorySizesList', selectedSizeList);
      component.set('v.record.adsalescloud__Inventory_Sizes__c', JSON.stringify(selectedSizeList));
    }
     var updateRecordEvent = $A.get('e.c:ProductTemplateRecordUpdateEvent');
    updateRecordEvent.fire();    
    //component.set('v.record.adsalescloud__Inventory_Type__c', inventoryType);
  },
  removeAtrribute: function(component, event) {
    var index = event.getSource().get('v.name');
    var inventoryType = component.get('v.inventoryType');
    if(inventoryType === 'Master/Companions Roadblock') {
      var masterInventorySizesList = JSON.parse(JSON.stringify(component.get('v.masterInventorySizesList')));
      masterInventorySizesList.splice(index, 1);
      component.set('v.masterInventorySizesList', masterInventorySizesList);
    } else if(inventoryType === 'Video VAST') {
      var videoInventorySizesList = JSON.parse(JSON.stringify(component.get('v.videoInventorySizesList')));
      videoInventorySizesList.splice(index, 1);
      component.set('v.videoInventorySizesList', videoInventorySizesList);
    }
  },
  checkValidations: function(component, event) {
    if(component.get('v.isSave')) {
      var inventoryType = component.get('v.inventoryType');
      var selectedInventorySizes = [];
      var isValid = true;
      var errorMessage = '';

      if(inventoryType) {
        if(inventoryType === 'Standard') {
          selectedInventorySizes = JSON.parse(JSON.stringify(component.get('v.standardInventorySizesList')));
        } else if(inventoryType === 'Master/Companions Roadblock') {
          selectedInventorySizes = JSON.parse(JSON.stringify(component.get('v.masterInventorySizesList')));
        } else if(inventoryType === 'Video VAST') {
          selectedInventorySizes = JSON.parse(JSON.stringify(component.get('v.videoInventorySizesList')));
        }
      }

      if(selectedInventorySizes) {
        if(inventoryType === 'Master/Companions Roadblock') {
          for(var row = 0; row < selectedInventorySizes.length; row++) {
            for(var col = 0; col < selectedInventorySizes.length; col++) {
              if(row === col) {
                break;
              }
              if(selectedInventorySizes[row].fullDisplayString === selectedInventorySizes[col].fullDisplayString) {
                isValid = false;
                errorMessage = 'Master size of placeholders must be unique.';
                break;
              }
            }

            if(!selectedInventorySizes[row]['companions'] || selectedInventorySizes[row]['companions'].length < 1) {
              isValid = false;
              errorMessage = 'Each master size requires at least one companion.';
              break;
            }
          }
        }

        if(inventoryType === 'Standard') {
          if(selectedInventorySizes.length < 1) {
            isValid = false;
            errorMessage = 'One or more Inventory Sizes must be selected.';
          } else {
            for(var index = 0; index < selectedInventorySizes.length; index++) {
              if(selectedInventorySizes[index] && selectedInventorySizes[index].fullDisplayString) {
                selectedInventorySizes[index]['companions'] = null;
              }
            }
          }
        }

        if(inventoryType === 'Video VAST') {
          for(var row = 0; row < selectedInventorySizes.length; row++) {
            for(var col = 0; col < selectedInventorySizes.length; col++) {
              if(row === col) {
                break;
              }
              if(selectedInventorySizes[row].fullDisplayString === selectedInventorySizes[col].fullDisplayString) {
                isValid = false;
                errorMessage = 'Master size of placeholders must be unique.';
                break;
              }
            }
          }
        }
      } else {
        isValid = false;
        errorMessage = 'One or more Inventory Sizes must be selected.';
      }

      if(isValid) {
        component.set('v.errorMessage', '');
        this.saveSelectedItems(component, event, selectedInventorySizes, inventoryType);
      } else {
        component.set('v.errorMessage', errorMessage);
        component.set('v.isSave', false);
      }
    }
  },
  setInventorySizes: function(component, inventoryType, inventorySize) {
    component.set('v.standardInventorySizesList', [{}]);
    component.set('v.masterInventorySizesList', [{}]);
    component.set('v.videoInventorySizesList', [{}]);

    if(inventoryType) {
      if(inventoryType === 'Standard') {
        component.set('v.standardInventorySizesList', inventorySize);
      } else if(inventoryType === 'Master/Companions Roadblock') {
        component.set('v.masterInventorySizesList', inventorySize);
      } else if(inventoryType === 'Video VAST') {
        component.set('v.videoInventorySizesList', inventorySize);
      }
    }
  },

  updateClickTargeting: function(component) {
    var lineItemType = component.get('v.record.adsalescloud__Line_Item_Type__c');
    var isReadOnly = false;
    var selectedInventorySizeList = [];
    if(lineItemType === 'Click Tracking Only') {
      var selectedObject = {};
      var size = {};
      isReadOnly = true;
      size['width'] = 1;
      size['height'] = 1;
      size['isAspectRatio'] = false;

      selectedObject['size'] = size;
      selectedObject['fullDisplayString'] = '1x1';
      selectedObject['environmentType'] = 'BROWSER';
      selectedObject['companions'] = null;
      selectedObject['expectedCreativeCount'] = 1;
      selectedObject['checkbox'] = true;
      selectedObject['creativeSizeType'] = 'PIXEL';

      selectedInventorySizeList.push(selectedObject);
      this.setInventorySizes(component, 'Standard', selectedInventorySizeList);
    } else {
      this.setInventorySizes(component, 'Standard', null);
    }
    component.set('v.readonly', isReadOnly);
    component.set('v.inventoryType', 'Standard');
  }
});