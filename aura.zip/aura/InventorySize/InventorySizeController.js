({

  saveSelectedItems: function(component, event, helper) {
    helper.saveSelectedItems(component, event);
  },
  getInventorySizeList: function(component, event, helper) {
    helper.getInventorySizeList(component, event);
  },

  showModal: function(component) {
    var modalContainer = component.find('modalContainer');
    $A.util.removeClass(modalContainer, 'slds-hide');
  },
  closeModal: function(component) {
    var modalContainer = component.find('modalContainer');
    $A.util.addClass(modalContainer, 'slds-hide');
  },
  getSelectedInventorySizeList: function(component, event, helper) {
    helper.getSelectedInventorySizeList(component, event);
  },
  addRow: function(component, event, helper) {
    helper.addRow(component, event);
  },
  setInventorySizesList: function(component, event, helper) {
    helper.setInventorySizesList(component, event);
  },
  removeAtrribute: function(component, event, helper) {
    helper.removeAtrribute(component, event);
  },
  updateInventoryTypes: function(component, event, helper) {
    helper.updateInventoryTypes(component);
  },
  reloadInventorySize: function(component, event, helper) {
    var inventoryType = event.getParam('value');
    var allSizesMap = component.get('v.allSizesMap');
    if(!allSizesMap) {
      helper.getInventorySizeList(component, event, inventoryType);
    }
  },
  checkValidations: function(component, event, helper) {
    helper.checkValidations(component, event);
  },
  updateClickTargeting: function(component, event, helper) {
    var videoEnabled = component.get('v.videoEnabled');
    var lineItemType = component.get('v.record.adsalescloud__Line_Item_Type__c');
    var inventoryTypes = [
      {'label': 'Standard', 'value': 'Standard'},
      {'label': 'Master/Companions Roadblock', 'value': 'Master/Companions Roadblock'},
      {'label': 'Video VAST', 'value': 'Video VAST'}
    ];
    if(!videoEnabled) {
      inventoryTypes.splice(2, 1);
    }
    if(lineItemType === 'Preferred Deal') {
      inventoryTypes.splice(1, 1);
    }
    component.set('v.inventoryTypes', inventoryTypes);
    helper.updateClickTargeting(component);
  }
});