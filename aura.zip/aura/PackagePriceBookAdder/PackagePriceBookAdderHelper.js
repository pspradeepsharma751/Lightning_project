({
  getPriceBooks: function(component) {
    var self = this;
    var priceBookMap = component.get('v.allPriceBookMap');
    if(priceBookMap) {
      //Setting the Selected Pricebooks
      var selectedPriceBook = priceBookMap['packagePriceBook'];
      self.setSelectedPricebook(component, selectedPriceBook);

      //Setting the available pricebooks in the listbox
      var standardPriceBookMap = priceBookMap['standardPriceBook'];

      if(standardPriceBookMap) {
        var standardPriceBook = Object.values(standardPriceBookMap);
        var availablePriceBookList = [];

        for(var index = 0; index < standardPriceBook.length; index++) {
          availablePriceBookList.push({'label': standardPriceBook[index].Name, 'value': standardPriceBook[index].Id})
        }
        component.set('v.availablePriceBookList', availablePriceBookList);
        component.set('v.packagePriceBookList', selectedPriceBook);
        component.set('v.standardPriceBookMap', standardPriceBookMap);

      }
    }
  },

  removeAtrribute: function(component, event) {
    var index = event.getSource().get('v.name');
    var packagePriceBookList = JSON.parse(JSON.stringify(component.get('v.packagePriceBookList')));
    packagePriceBookList.splice(index, 1);
    component.set('v.packagePriceBookList', packagePriceBookList);
    this.setSelectedPricebook(component, packagePriceBookList);
    //this.onSave(component);
  },

  setSelectedPricebook: function(component, packagePriceBookList) {
    var selectedPriceBookList = [];
    for(var index = 0; index < packagePriceBookList.length; index++) {
      selectedPriceBookList.push(packagePriceBookList[index].adsalescloud__Price_Book__r.Id);
    }
    component.set('v.selectedPriceBookList', selectedPriceBookList);
  },

  setPriceBookList: function(component) {
    var standardPriceBookMap = JSON.parse(JSON.stringify(component.get('v.standardPriceBookMap')));
    var selectedPriceBookList = JSON.parse(JSON.stringify(component.get('v.selectedPriceBookList')));
    var selectedPriceBookNameList = [];

    for(var index = 0; index < selectedPriceBookList.length; index++) {
      var standaredPriceBookObj = standardPriceBookMap[selectedPriceBookList[index]];
      if(standaredPriceBookObj) {
        var priceBookObj = {};
        var priceBookChild = {};

        priceBookChild['Name'] = standaredPriceBookObj.Name;
        priceBookChild['Id'] = standaredPriceBookObj.Id;

        priceBookObj['adsalescloud__Price_Book__r'] = priceBookChild;
        selectedPriceBookNameList.push(priceBookObj);
      }
    }
    component.set('v.packagePriceBookList', selectedPriceBookNameList);
  },


  onSave: function(component) {
    /*var selectedPriceBookList = component.get('v.selectedPriceBookList');
    var recordId = component.get('v.recordId');

    console.log('selectedPriceBookList ==> ', selectedPriceBookList);

    var action = component.get("c.savePackagePriceBook");
    action.setParams({ selectedPriceBook : JSON.stringify(selectedPriceBookList),
      recordId : recordId});

    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
        window.alert('Toast Message for Save will be here');
      }
    });
    $A.enqueueAction(action);*/
  }
});