({
  getPriceBooks: function(component, event, helper) {
    helper.getPriceBooks(component);
  },

  removeAtrribute: function(component, event, helper) {
    helper.removeAtrribute(component, event);
  },

  showModal: function(component) {
    var modalContainer = component.find('modalContainer');
    $A.util.removeClass(modalContainer, 'slds-hide');
  },

  closeModal: function(component, event, helper) {
    var modalContainer = component.find('modalContainer');
    $A.util.addClass(modalContainer, 'slds-hide');
    helper.setPriceBookList(component);
    //helper.onSave(component);
  },

})