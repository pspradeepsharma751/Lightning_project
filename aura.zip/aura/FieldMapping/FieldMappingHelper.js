({
    /*
    	Getting the objectName for the picklist 
    */
	getobjectName : function(component, event) {
        component.set("v.showSpinner",true);
        var action = component.get("c.getObjectMappingName");
        action.setCallback(this, function(response) {
            component.set("v.showSpinner",false);
            var state = response.getState();
            if (state === "SUCCESS") {
                var objectNameList = response.getReturnValue();
                if(objectNameList != '') {
                    component.set("v.objectNameList",objectNameList);
                    component.set("v.objectId",objectNameList[0].Id);
                    this.getFieldMappingName(component, event, objectNameList[0].Id);
                }
            }
        });
	   	$A.enqueueAction(action);
    },
    
    getFieldMappingList : function(component, event) {
        var objectId = event.target.id;
        component.set("v.objectId",objectId);
        this.getFieldMappingName(component, event, objectId);
    },
    
    
    
    /*
    	Getting the FieldMapping Name for the selected object
    */
    getFieldMappingName : function(component, event, objectId) {
  		component.set("v.showSpinner",true);
        component.set("v.objectId",objectId);
    	var action = component.get("c.getFieldMappingNames");
        action.setParams({ "objectId" : objectId});
        action.setCallback(this, function(response) {
            component.set("v.showSpinner",false);
            var state = response.getState();
            if (state === "SUCCESS") {
                var fieldMappingNames = response.getReturnValue();
                
                if(fieldMappingNames != '') {
                    component.set("v.fieldMappingNames",fieldMappingNames);
                    this.setObjectAndField(component, event, fieldMappingNames[0].Id);
                } else {
                    component.set("v.fieldMappingNames","");
                    this.setObjectAndField(component, event, "");
                    this.addMapping(component, event);
                }
            }
        });
	   	$A.enqueueAction(action);
    },
    
    setObjectAndField : function(component, event, fieldNameId) {
        component.set("v.fieldMapId",fieldNameId);
        var compEvent = $A.get("e.c:FieldMappingEvent");    
        compEvent.setParams({"fieldMapId" : fieldNameId,
                             "objectMapId": component.get("v.objectId")});
        compEvent.fire();
    },
    
    addMapping : function(component, event) {
        // Passing the false value to the event for hide the Delete button on the FieldMappingDetails Component
        var compEvent = $A.get("e.c:FieldMappingEvent");    
        compEvent.setParams({"isEdit" : false,
                             "objectMapId" : component.get("v.objectId")});
        compEvent.fire();
        
	}
})