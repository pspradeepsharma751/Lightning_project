({
    refreshView : function(component, event, helper) {
        var objectId = event.getParam("objectMapId");
        helper.getFieldMappingName(component, event, objectId);
    },
    
    addMapping : function(component, event, helper) {
        helper.addMapping(component, event);
	},
    
    getobjectName : function(component, event, helper) {
        helper.getobjectName(component, event);
    },
    
    getFieldMappingName : function(component, event, helper) {
        helper.getFieldMappingList(component, event);
    },
    
    updateFieldsData : function(component, event, helper) {
        var fieldName = event.currentTarget.dataset.id;
        helper.setObjectAndField(component, event, fieldName);
    }
})