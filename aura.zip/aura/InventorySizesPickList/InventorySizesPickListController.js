({
    closeModal : function(component, event, helper) {
        helper.closeModal(component, event);
    },
    
    doInit : function(component, event, helper) {
    	helper.doInit(component, event);
    },    
    filterOptions : function(component, event, helper) {
        component.set("v.timestamp", new Date().getTime());
        setTimeout(function(){
            if(new Date().getTime() - component.get("v.timestamp") > 499)
                helper.filterOptions(component);
           /* else{
                component.set("v.timestamp", new Date().getTime());
            }*/
        }, 500);
    }
})