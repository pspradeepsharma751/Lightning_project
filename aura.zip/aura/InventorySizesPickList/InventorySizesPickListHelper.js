({
  doInit: function(component, event) {
    this.showModal(component);
      component.set("v.filteredInventorySizes", component.get("v.availabelInventorySizes"));
  },

  closeModal: function(component, event) {
    var modalContainer = component.find('modalContainer');
    $A.util.addClass(modalContainer, 'slds-hide');

    component.set('v.showModal', false);
    component.set('v.isGetSizes', true);
  },

  showModal: function(component) {
    var modalContainer = component.find('modalContainer');
    $A.util.removeClass(modalContainer, 'slds-hide');
    component.set('v.isGetSizes', false);
  },    
    filterOptions : function(component) {
        var allOptions = component.get("v.availabelInventorySizes");
        var selecetedOptions = component.get("v.selectedList");
        var filterKeyword = component.get("v.filterKeyword");
        var filteredOptions = [];
        if($A.util.isEmpty(filterKeyword)){
            filteredOptions = allOptions;
        }
        else{
            allOptions.forEach(function(value){
                if(value.label.includes(filterKeyword) || selecetedOptions.includes(value.label)){
                    filteredOptions.push(value);
                }
            });
        }
        component.set("v.filteredInventorySizes", filteredOptions);
    }
});