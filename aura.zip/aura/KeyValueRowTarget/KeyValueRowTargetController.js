({
  doInit: function(component, event, helper) {
    component.set('v.showAddNewKey', false);
    var setRows = component.get('v.setRows');
    var setIndex = component.get('v.setIndex');
    var rowIndex = component.get('v.rowIndex');
    var rowValue = component.get('v.rowValue');
    var selectedRowValue;
    var selectedKeys = Array.from(component.get('v.selectedKeys'));
    if(setRows && setRows[rowIndex]) {
      selectedRowValue = setRows[rowIndex].adunit;
      var selectedValuesName = [];
      var selectedKey = selectedRowValue.key;
      for(var i = 0; i < selectedRowValue.values.length; i++) {
        selectedValuesName.push(selectedRowValue.values[i].label);
      }
      component.set('v.selectedKey', selectedKey);
      component.set('v.selectedValuesName', selectedValuesName.join(','));
      selectedKeys.push(selectedKey.value);
      component.set('v.selectedKeys', selectedKeys);
    } else {
      selectedRowValue = {key: {}, values: [], operator: 'IS', 'parentId': setIndex, 'id': 'key'+rowValue, 'name': ''};
      component.set('v.lineItems',0);
    }
    component.set('v.selectedRowValue', selectedRowValue);
  },
  removeRow: function(component, event, helper) {
    var selectedKey = component.get('v.selectedKey');
    helper.removeFromSelectedTarget(component);
    helper.fireRowRemoveEvent(component, selectedKey);
  },
  selectedKeyChangeHandler: function(component) {
    var selectedKey = component.get('v.selectedKey');
    var rowValue = component.get('v.rowValue');
    var selectedRowValue = component.get('v.selectedRowValue');
    if(selectedRowValue) {
      selectedRowValue.key = selectedKey;
      selectedRowValue.id = 'key'+rowValue;
      component.set('v.selectedRowValue', selectedRowValue);
    }
    component.set('v.showAddNewKey', (selectedKey && selectedKey.value));
  },
  rowValueChangeHandler: function(component, event, helper) {
    var setRows = component.get('v.setRows');
    var rowIndex = component.get('v.rowIndex');
    var selectedRowValue = component.get('v.selectedRowValue');
    if(!setRows)
      setRows = [];
    setRows[rowIndex] = {'adunit':selectedRowValue,'customizable':true};
    component.set('v.setRows', setRows);
    if(selectedRowValue && selectedRowValue.key && selectedRowValue.values && selectedRowValue.values.length !== 0) {
      helper.fireEvent(component, selectedRowValue);
    }
  },
  handleRemovedTarget: function(component, event, helper) {
    var segments = component.get('v.segments');
    var eventSegments = event.getParam('segments');
    var rowValue = component.get('v.rowValue');
    var setIndex = component.get('v.setIndex');
    var index = event.getParam('index');
    if(index && index === -2) return;
    if(eventSegments !== segments) return;

    var item = event.getParam('item');
    var selectedKey = component.get('v.selectedKey');
    if(selectedKey && item.adunit.parentId === setIndex && item.adunit.id === 'key'+rowValue) {
      helper.fireRowRemoveEvent(component, selectedKey);
    }
  }
});