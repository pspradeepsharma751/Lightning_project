({
  fireEvent: function(component, selectedRowValue) {
    var evt = $A.get('e.c:TargetingEvent');
    var selectedKey = component.get('v.selectedKey');
    var name = selectedKey.label;

    if(component.get('v.segments')){
      name+= ' - ' + component.get('v.selectedValuesName');
    }else{
      name+= ' ' + selectedRowValue.operator+' ' + component.get('v.selectedValuesName');;
    }

    selectedRowValue.name = name;
    evt.setParams({
      'adunit': selectedRowValue,
      'segments': component.get('v.segments'),
      'category': component.get('v.category')
    });
    evt.fire();
  },
  fireRowRemoveEvent: function(component, selectedKey) {
    component.set('v.showAddNewKey', true);
    var evt = component.getEvent('removeKeyValue');
    evt.setParams({
      'index': component.get('v.rowIndex'),
      'keyId': selectedKey ? selectedKey.value : null
    });
    evt.fire();
  },
  removeFromSelectedTarget: function(component) {
    var selectedRowValue = component.get('v.selectedRowValue');
    var removeEvent = $A.get('e.c:RemoveSelectedEvent');
    removeEvent.setParams({
      'item': {'adunit': selectedRowValue},
      'segments': component.get('v.segments'),
      'index': -2,
      'category': component.get('v.category')
    });
    removeEvent.fire();
  }
});