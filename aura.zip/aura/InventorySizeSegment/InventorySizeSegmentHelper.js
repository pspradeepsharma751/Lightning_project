({
  getInventorySizeList: function(component) {
    var self = this;
    this.fetchData(component,
      'getAdUnitSizes', {isReadOnly :true},
      function(response) {
        if(response.status === 'OK') {
          component.set('v.allSizes', response.targets);
          self.convertInventorySizeList(component, response.targets);
        } else {

        }
      });
  },
  convertInventorySizeList: function(component, adUnitSizes) {
    var availableSizes = [];
    var videoSizes = [];
    var allSizes = Object.keys(adUnitSizes);

    for(var index = 0; index < allSizes.length; index++) {
      var inventorySize = adUnitSizes[allSizes[index]];
      if(inventorySize && inventorySize.fullDisplayString && inventorySize.environmentType !== 'VIDEO_PLAYER') {
        availableSizes.push({'label': inventorySize.fullDisplayString, 'value': inventorySize.fullDisplayString});
      } else if(inventorySize && inventorySize.environmentType === 'VIDEO_PLAYER') {
        videoSizes.push({'label': inventorySize.fullDisplayString, 'value': inventorySize.fullDisplayString});
      }
    }
    component.set('v.availableSizes', availableSizes);
    component.set('v.videoSizes', videoSizes);
  }
});