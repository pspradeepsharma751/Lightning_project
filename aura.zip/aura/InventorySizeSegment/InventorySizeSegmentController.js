({
  doInit: function(component, event, helper) {
    var selectedMap = component.get('v.selectedMap');
    var lineItems = component.get('v.lineItems');
    var options = [],adType = '';
    if(selectedMap && lineItems > 0) {
      var inventorySizes = selectedMap['Inventory Sizes'];
      if(inventorySizes['Video VAST']) {
        adType = 'video';
        options = [
          {'label': 'Video Ads', 'value': 'video'}
        ];
      } else {
        adType = 'display';
        options = [
          {'label': 'Display Ads', 'value': 'display'}
        ];
      }
      component.set('v.options',options);
      component.set('v.adType',adType);
    }
    helper.getInventorySizeList(component);
  },
  clearCompanions: function(component, event, helper) {
    var childCmp = component.find('childCmp');
    childCmp.clearSelection();
    $A.get('e.c:ToggleInventorySizesEvent').setParams({category: 'Inventory Sizes'}).fire();
  }
});