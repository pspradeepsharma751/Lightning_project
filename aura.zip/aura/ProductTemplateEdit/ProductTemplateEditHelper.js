({
  doInit: function(component) {
    var self = this;
    this.fetchData(component, 'getProductTemplateRecord', {
      'recordId': component.get('v.recordId') ? component.get('v.recordId') : null
    }, function(response) {
      var result = JSON.parse(response);
      var record = result.objectData;
      self.fetchLineItemPicklistValues(component, 'adsalescloud__Line_Item_Type__c', 'adsalescloud__Rate_Type__c', 'Rate Type');
      self.fetchLineItemPriorityOptionPicklistValues(component, 'adsalescloud__Line_Item_Type__c', 'adsalescloud__Line_Item_Priority__c', 'Line Priority');
      if(component.get('v.cloneRecord')) {
        record.Name = 'Copy of ' + record.Name;
        record.adsalescloud__isActive__c = false;
      }
      component.set('v.video_enabled', result.video_enabled);
      component.set('v.allPricebooks', result.pricebooks.allPricebookList);
      component.set('v.selectedPricebooks', result.pricebooks.selectedPricebookList);
      component.set('v.lineItemPriorityInitialeValue', record.adsalescloud__Line_Item_Priority__c);
      component.set('v.record', record);
      component.set('v.currentRecord', record);
      component.set('v.lineItemTypeValue', component.get('v.record.adsalescloud__Line_Item_Type__c'));
      if(component.get('v.newRecord'))
        self.updateLineItemPriority(component);
    });

  },
  onSave: function(component) {
    var record = component.get('v.record');
    var self = this;
    //record['adsalescloud__Customizable_Attributes_Details__c'] = JSON.stringify(component.get('v.checkboxDetails'));
    var checkBoxDetails = component.get('v.checkboxDetails');
    if(component.get('v.inventoryType') !== 'Video VAST') {
      checkBoxDetails['allowVideoContentCustomization'] = false;
      checkBoxDetails['allowContentBundleCustomization'] = false;
      checkBoxDetails['allowVideoPositionCustomization'] = false;
    }
    record['adsalescloud__Customizable_Attributes_Details__c'] = JSON.stringify(checkBoxDetails);

    if(component.get('v.record.adsalescloud__Product_Type__c') === 'DFP Ads - Click Tracking Only') {
      component.set('v.record.adsalescloud__Rate_Type__c', 'CPC');
    }
    if(record['adsalescloud__Line_Item_Type__c'] === 'Click Tracking Only') {
      record['adsalescloud__Deliver_Impressions__c'] = null;
      record['adsalescloud__Display_Creatives__c'] = null;
    }
    if(component.get('v.cloneRecord')) {
      record.Id = null;
    }
    if(record.adsalescloud__Product_Type__c === 'Offline') {
      delete record.adsalescloud__Deliver_Impressions__c;
      delete record.adsalescloud__Rotate_Creatives__c;
      delete record.adsalescloud__Display_Creatives__c;
    }
    var recordId = component.get('v.recordId');
    var pricebooks = {};
    var selectedPricebookList = component.get('v.selectedPricebooks');
    pricebooks.deletedPricebookList = component.get('v.deletedPriceboks');
    for(var key in selectedPricebookList) {
      if(record.adsalescloud__Rate_Type__c.includes('CPM')) {
        selectedPricebookList[key]['adsalescloud__Product_Rate__c'] = (selectedPricebookList[key]['adsalescloud__Product_Rate__c'] || 0) / 1000;
      }
      delete selectedPricebookList[key].adsalescloud__Price_Book__r;
    }

    pricebooks.selectedPricebookList = selectedPricebookList;
    pricebooks.deletedPricebookList.forEach(function(value, index) {
      delete value.adsalescloud__Price_Book__r;
    });
    component.set('v.showSpinner', true);
    this.fetchData(component, 'upsertRecord', {
      'productTemplateRecord': JSON.stringify(record),
      'lstProducts': component.get('v.products'),
      'pricebooks': JSON.stringify(pricebooks),
      'isActivatedNow': component.get('v.isActivatedNow')
    }, function(response) {
      component.set('v.showSpinner', false);
      component.set('v.disableButtons', false);
      if(response.status === "OK") {
        if(component.get('v.isLightning') && !component.get('v.cloneRecord')) {
          $A.get('e.force:refreshView').fire();
          $A.get('e.force:closeQuickAction').fire();
        } else if(component.get('v.isProdTemplateListViewEdit')) {
          var navEvt = $A.get('e.force:navigateToSObject');
          navEvt.setParams({
            'recordId': recordId,
            'slideDevName': 'detail'
          });
          navEvt.fire();
        }
        else {
          var navEvt = $A.get('e.force:navigateToSObject');
          navEvt.setParams({
            'recordId': response.recordId,
            'slideDevName': 'detail'
          });
          navEvt.fire();
        }
      }
      else {
        self.onError(component, response.errorMessage);
      }
    }, function(error) {
      component.set('v.showSpinner', false);
      this.showToast(component, 'Error', error, 'error');
    });
    component.set('v.disableButtons', true);
  },
  validate: function(component) {
    component.set('v.isInventorySizeSave', true);
    var sizeSubCat = ['Standard', 'Video VAST', 'Master/Companion'];
    var frequencyErrorMessage = component.get('v.frequencyCapErrorMessage');
    var inventoryErrorMessage = component.get('v.inventorySizeErrorMessage');
    var selectedPricebookList = component.get('v.selectedPricebooks');
    var selectedSegmentsCategories = component.get('v.selectedSegmentsCategories');
    var isSizeSegment = this.searchCat(sizeSubCat, selectedSegmentsCategories);
    var errorMessage = '';
    var record = component.get('v.record');
    if($A.util.isEmpty(record.Name) || record.Name.trim() === "") {
      errorMessage = 'Product Template Name cannot be blank.';
    }
    else if((!record.adsalescloud__Inventory_Sizes__c || record.adsalescloud__Inventory_Sizes__c === '[{}]')
      && record.adsalescloud__Product_Type__c !== 'Offline' && !isSizeSegment) {
      errorMessage = 'One or more Inventory Sizes must be selected.';
    }
    else if(frequencyErrorMessage) {
      if(inventoryErrorMessage && selectedSegmentsCategories.indexOf('Inventory Sizes') !== -1) {
        errorMessage = frequencyErrorMessage + (record.adsalescloud__Product_Type__c !== 'Offline' ? '  \n  ' + inventoryErrorMessage : '');
      }
      else {
        errorMessage = frequencyErrorMessage;
      }
    } else if(inventoryErrorMessage && (record.adsalescloud__Product_Type__c !== 'Offline' && !isSizeSegment)) {
      errorMessage = inventoryErrorMessage;
    } else {
      var selectedTargetCategories = component.get('v.selectedTargetCategories');
      if(selectedSegmentsCategories && selectedTargetCategories) {
        for(var i = 0; i < selectedSegmentsCategories.length; i++) {
          if(selectedTargetCategories.indexOf(selectedSegmentsCategories[i]) !== -1) {
            errorMessage = selectedSegmentsCategories[i] + ' cannot be included in both product segments and targeting. To target ' + selectedSegmentsCategories[i] + ' in this template, remove it from product segments and try again.';
            break;
          }
        }
      }
    }
    selectedPricebookList.forEach(function(pricebook) {
      if(parseInt(pricebook.adsalescloud__Product_Rate__c) < 0) {
        errorMessage = 'Pricebook product rate must be greater than or equal to 0.';
      }
    });
    if(isSizeSegment) {
      component.set('v.record.adsalescloud__Inventory_Sizes__c', null);
    }
    if(errorMessage) {
      this.onError(component, errorMessage);
      return false;
    }
    else {
      return true;
      //this.onSave(component);
    }
  },
  searchCat: function(haystack, arr) {
    return arr.some(function(v) {
      return haystack.indexOf(v) >= 0;
    });
  },
  showToast: function(component, title, message, type) {
    component.set('v.toastTitle', title);
    component.set('v.message', message);
    component.set('v.messageType', type);
    component.set('v.showToast', true);
  },
  onError: function(component, errorMessage) {
    component.set('v.isInventorySizeSave', false);
    this.showToast(component, 'Error', errorMessage, 'error');
  },
  concatMessage: function(component, messageToConcat) {
    var errorMessage = component.get('v.errorMessage');
    if(errorMessage) {
      if(messageToConcat) {
        errorMessage += '<br>' + messageToConcat;
      }
    } else {
      errorMessage = messageToConcat;
    }
    component.set('v.errorMessage', errorMessage);
  },
  redirect: function(component) {
    if(component.get('v.newRecord') || component.get('v.isProdTemplateListViewEdit')) {
      var evt = $A.get('e.force:navigateToObjectHome');
      evt.setParams({
        'scope': 'adsalescloud__Ad_Sales_Product_Template__c'
      });
      evt.fire();
    }
    else {
      $A.get('e.force:closeQuickAction').fire();
    }
  },
  getRateTypeOptions: function(component) {
    var mapKeyValueList = component.get('v.lineItemDependentFieldMapList');
    if(mapKeyValueList.length > 0) {
      var lineItemKey = component.get('v.record.adsalescloud__Line_Item_Type__c');
      var listOfDependentFields = mapKeyValueList[0].dependentPickListProperty[lineItemKey];
      var selectedValue = component.get('v.record.' + mapKeyValueList[0].API_Name);
      var dependentFields = [];
      if((!$A.util.isEmpty(listOfDependentFields)) && listOfDependentFields.length > 0) {
        for(var i = 0; i < listOfDependentFields.length; i++) {
          dependentFields.push({
            class: 'optionClass',
            label: listOfDependentFields[i],
            value: '' + listOfDependentFields[i] + '',
            selected: selectedValue ? listOfDependentFields[i] === selectedValue : false
          });
        }
      }
      else {
        dependentFields.push({
          class: 'optionClass',
          label: '--None--',
          value: '',
          selected: true
        });
      }
      if(component.get('v.newRecord')) {
        component.set('v.record.adsalescloud__Rate_Type__c', dependentFields[0].value);
      }
      component.set('v.lineItemOptions', dependentFields);
    }
  },
  fetchLineItemPicklistValues: function(component, controllerField, dependentField, dependentFieldLabel) {
    var self = this;
    this.fetchData(component, 'getLineItemDependentOptionsImpl', {
      'objApiName': 'adsalescloud__Ad_Sales_Product_Template__c',
      'contrfieldApiName': controllerField,
      'depfieldApiName': dependentField
    }, function(StoreResponse) {
      var depPickListArray = component.get('v.lineItemDependentFieldMapList');
      depPickListArray.push({Name: dependentFieldLabel, API_Name: dependentField, dependentPickListProperty: StoreResponse});
      component.set('v.lineItemDependentFieldMapList', depPickListArray);
      self.getRateTypeOptions(component);
    });
  },
  getLineItemPriorityOptions: function(component) {
    var mapKeyValueList = component.get('v.lineItemPriorityDependentFieldMapList');
    var record = component.get('v.record');
    if(mapKeyValueList.length > 0) {
      var lineItemKey = component.get('v.record.adsalescloud__Line_Item_Type__c');
      var listOfDependentFields = mapKeyValueList[0].dependentPickListProperty[lineItemKey];
      var selectedValue = component.get('v.record.' + mapKeyValueList[0].API_Name);
      var dependentFields = [];
      if((!$A.util.isEmpty(listOfDependentFields)) && listOfDependentFields.length > 0) {
        for(var i = 0; i < listOfDependentFields.length; i++) {
          var optionObject = {
            class: 'optionClass',
            label: listOfDependentFields[i],
            value: '' + listOfDependentFields[i] + '',
            selected: selectedValue ? listOfDependentFields[i] === selectedValue : false
          };

          dependentFields.push(optionObject);
        }
        // make disable false for ui:inputselect field
        //component.set('v.disable', false);
      }
      else {
        dependentFields.push({
          class: 'optionClass',
          label: '--None--',
          value: '',
          selected: true
        });
      }
      component.set('v.record.adsalescloud__Line_Item_Priority__c', record['adsalescloud__Line_Item_Priority__c'] ? record['adsalescloud__Line_Item_Priority__c'] : dependentFields[0].value);
      component.set('v.lineItemPriorityOptions', dependentFields);
      //component.set("v.disabled", false);
    }
  },

  getPickListValue: function(component) {
    this.fetchData(component, 'fetchPicklistValues', {
      'pickListFieldName': 'lineItemPriority'
    }, function(response) {
      // create a empty array var for store dependent picklist values for controller field)
      var dependentFields = [];
      var result = JSON.parse(response);
      var listPicklistValues = result.pickListValues;
      for(var i = 0; i < listPicklistValues.length; i++) {
        dependentFields.push({
          class: 'optionClass',
          label: listPicklistValues[i].label,
          value: listPicklistValues[i].value,
          selected: component.get('v.record').adsalescloud__Line_Item_Priority_Rating__c !== undefined && listPicklistValues[i] === component.get('v.record').adsalescloud__Line_Item_Priority_Rating__c
        });
      }
      component.set('v.lineItemRatingOptions', dependentFields);
      component.set('v.lineItemRatingIsEditable', result.isEditable);
    }, function(error) {
      component.set('v.errorMessage', error.message);
    });
  },
  fetchLineItemPriorityOptionPicklistValues: function(component, controllerField, dependentField, dependentFieldLabel) {
    var self = this;
    this.fetchData(component, 'getLineItemDependentOptionsImpl', {
      'objApiName': 'adsalescloud__Ad_Sales_Product_Template__c',
      'contrfieldApiName': controllerField,
      'depfieldApiName': dependentField
    }, function(StoreResponse) {
      var depPickListArray = component.get('v.lineItemPriorityDependentFieldMapList');
      depPickListArray.push({Name: dependentFieldLabel, API_Name: dependentField, dependentPickListProperty: StoreResponse});
      component.set('v.lineItemPriorityDependentFieldMapList', depPickListArray);
      self.getLineItemPriorityOptions(component);
    });
  },
  updateLineItemPriority: function(component) {
    var lineitemPriority = $A.util.isEmpty(component.get('v.record.adsalescloud__Line_Item_Priority__c')) ? '' : component.get('v.record.adsalescloud__Line_Item_Priority__c');
    var lineitemPriorityRate; //= component.get('v.record.adsalescloud__Line_Item_Priority_Rating__c');
    var lineitemType = component.get('v.record.adsalescloud__Line_Item_Type__c');
    switch(lineitemType) {
      case 'Standard':
        switch(lineitemPriority) {
          case 'Normal':
            lineitemPriorityRate = 8;
            break;
          case 'Low':
            lineitemPriorityRate = 10;
            break;
          case 'High':
            lineitemPriorityRate = 6;
            break;
          default:
            lineitemPriorityRate = 0;
        }
        break;
      case 'Sponsorship': lineitemPriorityRate = 4; break;
      case 'Network':
      case 'Bulk':
      case 'Price Priority': lineitemPriorityRate = 12; break;
      case 'House': lineitemPriorityRate = 16; break;
      case 'Preferred Deal': lineitemPriorityRate = 12; break;
      default: lineitemPriorityRate = 2;
    }
    component.set('v.record.adsalescloud__Line_Item_Priority_Rating__c', lineitemPriorityRate);
  },

  handleFieldChanges: function(fieldName, component) {
    var fieldChanges = component.find('inventorySizes');
    fieldChanges.handleFieldChanges(fieldName);
  }
});