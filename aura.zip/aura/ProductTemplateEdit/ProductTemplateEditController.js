({
  doInit: function(component, event, helper) {
    component.set('v.cval', '<style>.slds-modal__container{min-width: 60rem;}.panel .closeIcon{display:none}</style>');
    var recordId = component.get('v.recordId');
    component.set('v.newRecord', recordId ? false : true);
    helper.doInit(component);
    helper.getPickListValue(component);
  },
  onSave: function(component, event, helper) {
    if(helper.validate(component))
      helper.onSave(component);
  },
  onCancel: function(component, event, helper) {
    helper.redirect(component);
    component.set('v.isInventorySizeSave', false);
  },
  handlePickListEvent: function(component, event, helper) {
    var updateRecordByEvent = event.getParam('updateRecordByEvent');
    component.set('v.lineItemTypeValue', updateRecordByEvent);
    helper.getRateTypeOptions(component);
    helper.getLineItemPriorityOptions(component);
  },
  updateLineItemPriority: function(component, event, helper) {
    if(component.get('v.record.adsalescloud__Line_Item_Priority__c') !== component.get('v.lineItemPriorityInitialeValue'))
      helper.updateLineItemPriority(component);
  },
  activate: function(component, event, helper) {
    if(helper.validate(component)) {
      component.set('v.record.adsalescloud__Status__c', 'Active');
      component.set('v.isActivatedNow', true);
      helper.onSave(component);
    }
  },
  /* updateLineItemType: function(component, event, helper) {
    if(component.get('v.record.adsalescloud__Line_Item_Type__c') === 'Click Tracking Only')
      component.set('v.displayDeliveryFields', false);
    else
      component.set('v.displayDeliveryFields', true);
  }, */
  toggleInventorySizeVisibility: function(component, event, helper) {
    var selectedSegmentsCategories = component.get('v.selectedSegmentsCategories');
    var sizeSubCat = ['Standard', 'Video VAST', 'Master/Companion'];
    if(helper.searchCat(sizeSubCat, selectedSegmentsCategories)) {
      component.set('v.isInventorySizeSegment', true);
      component.set('v.record.adsalescloud__Inventory_Sizes__c', null);
      if(selectedSegmentsCategories.indexOf('Video VAST') !== -1) {
        component.set('v.record.adsalescloud__Environment_Type__c', 'Video Player');
      } else {
        component.set('v.record.adsalescloud__Environment_Type__c', 'Browser');
      }
    }
    else {
      component.set('v.isInventorySizeSegment', false);
    }
  },
   
});