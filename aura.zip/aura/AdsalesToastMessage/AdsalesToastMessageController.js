({
  hideToast: function(component, event, helper) {
    helper.hideToast(component);
  },
  destory: function(component, event, helper) {
    helper.destory(component);
  }

})