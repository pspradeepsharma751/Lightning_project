({
  fetchKeys: function(component) {
    var self = this;
    self.fetchData(component, 'getCustomKeyTargets', {'searchTerm':null}, function(res) {
      if(res.status === 'OK') {
        var allKeys = res.targets;
        if(!component.get('v.segments') && component.get('v.audiences_enabled'))
          allKeys = Object.assign({'000000':{'value':'000000','label':'Audience Segment'}},allKeys);
        component.set('v.keys',allKeys);
        self.initialise(component);
      }
    });
  },
  initialise: function(component) {
    var selectedMap = component.get('v.selectedMap');
    var category = component.get('v.category');
    var targets = [];
    if(selectedMap && selectedMap[category])
      targets = selectedMap[category];

    var keys = Object.keys(targets);
    var sets = [];
    if(keys.length === 0) {
      sets.push(0);
    }
    else {
      for(var i = 0; i < keys.length; i++)
        sets.push(i);
    }
    component.set('v.targets', targets);
    component.set('v.sets', sets);
  }
});