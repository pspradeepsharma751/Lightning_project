({
  doInit: function(component, event, helper) {
    helper.fetchKeys(component);
  },
  addNewTargetSet: function(component, event, helper) {
    var sets = component.get('v.sets');
    sets.push(sets[sets.length - 1] + 1);
    component.set('v.sets', sets);
  },
  removeKeyValueSetHandler: function(component, event, helper) {
    var ind = event.getParam('index');
    var sets = component.get('v.sets');
    sets.splice(ind, 1);
    component.set('v.sets', sets);
  },
  setsChangeHandler: function(component,event,helper){
    var sets = component.get('v.sets');
    if(!sets || sets.length === 0){
      sets = [0];
      component.set('v.selectedKeys',[]);
      component.set('v.targets',[]);
      component.set('v.sets',sets);
    }
  }
});