({
    validate: function(component) {
        var isArchived = component.get("v.record.adsalescloud__isArchived__c");
        var status = component.get("v.record.adsalescloud__Status__c");
        var delevringPLIs = component.get("v.record.adsalescloud__Delivering_Line_Items__c");
        var sObjectName = component.get("v.sObjectName") === "adsalescloud__Proposal__c" ? "proposal" : "proposal line item";
        if(isArchived ){
            component.set("v.errorMessage","This "+sObjectName+" is already archived.");
        }
        else if(sObjectName === "proposal"){
            if(status.indexOf("Pending Approval")> -1  ||  (status == 'Finalized' && delevringPLIs > 0)){
                component.set("v.errorMessage","Please retract the proposal to Draft status before archiving.");
            } else if(status.indexOf("Draft")> -1  ||  status == 'Rejected'  ||  (status == 'Finalized' && delevringPLIs == 0)){
                component.set("v.confirmationMessage","Are you sure you want to archive this proposal and its line items?");
            }
        }
        else{
             if(component.get("v.record.adsalescloud__Proposal__r.adsalescloud__Status__c").indexOf("Draft") == -1){
                 component.set("v.errorMessage","Please retract the related proposal to Draft status before archiving.");
             }
             else{
                 component.set("v.confirmationMessage","Are you sure you want to archive this proposal line item?");
             }
             
         }
    },
    
    archiveRecord:function (component) {
        component.set("v.loading",true);
        component.set("v.showToast",true);
		 var sObjectName = component.get("v.sObjectName") === "adsalescloud__Proposal__c" ? "Proposal" : "Proposal line item";
        var action = component.get("c.archiveObjRecord");
        action.setParams({
            recordId: component.get("v.record.Id")
        });
        
        action.setCallback(this,function (response) {
            component.set("v.loading",false);
            var state = response.getState();
            if(state === "SUCCESS") {
				var toastEvent = $A.get('e.force:showToast');
				toastEvent.setParams({
					'title': 'Success!',
					'type': 'success',
					'message': sObjectName+' archived succesfully.'
				});
				toastEvent.fire();
                $A.get('e.force:refreshView').fire();
                $A.get("e.force:closeQuickAction").fire();
                /*
                var recid = component.get("v.recordId");
                window.location.href = "/"+recid;*/
                
            } else if(state === "ERROR") {
                component.set("v.status",$A.get("$Label.c.ERROR"));
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.message",errors[0].message);
                    }
                } else {
                    component.set("v.message",$A.get("$Label.c.UNKNOWN_ERROR"));
                }
            }
        });
        $A.enqueueAction(action);
    },
})