({
  fetchAllPicklistValues: function(component) {
    var arrayDependentPicklistFields = component.get('v.dependentFieldAPIName');
    var dependentFieldNameLst = component.get('v.dependentFieldName');
    for(var idx = 0; idx < arrayDependentPicklistFields.length; idx++) {
      this.fetchPicklistValues(component, component.get('v.controllingFieldName'), arrayDependentPicklistFields[idx], dependentFieldNameLst[idx]);
    }
  },
  fetchPicklistValues: function(component, controllerField, dependentField, dependentFieldLabel) {
    var self = this;
    var objectName = component.get('v.objectName');
    var action = component.get('c.getDependentOptionsImpl');
    action.setParams({
      'objApiName': objectName,
      'contrfieldApiName': controllerField,
      'depfieldApiName': dependentField
    });
    //set callback
    action.setCallback(this, function(response) {
      if(response.getState() === 'SUCCESS') {
        var storeResponse = response.getReturnValue();
        var depPickListArray = component.get('v.dependentFieldMapList');

        if(component.get('v.isCustomSetting')) {
          if(dependentField === 'adsalescloud__Billing_Schedule__c')
            dependentField = 'adsalescloud__Proposal_Billing_Schedule__c';
          else
            dependentField = 'adsalescloud__Proposal_Caps_and_Rollovers__c';
        }
        var obj = {'Name': dependentFieldLabel, 'API_Name': dependentField, 'show': true, 'disable': false, 'dependentPickListProperty': storeResponse};
        self.applyConditions(component, obj);
        depPickListArray.push(obj);
        component.set('v.dependentFieldMapList', depPickListArray);
      }
    });
    $A.enqueueAction(action);
  },
  toggleVisibilty: function(component) {
    var dependentFieldMapList = component.get('v.dependentFieldMapList');
    for(var i = 0; i < dependentFieldMapList.length; i++) {
      this.applyConditions(component, dependentFieldMapList[i]);
    }
    component.set('v.dependentFieldMapList', dependentFieldMapList);
    component.set('v.refresh',false);
    component.set('v.refresh',true);
  },
  applyConditions: function(component, obj) {
    var lineItemTypeValue = component.get('v.lineItemTypeValue');
    var inventoryType = component.get('v.inventoryType');
    var objectName = component.get('v.objectName');
    var show = true;
    var disable = false;

    if(objectName === 'adsalescloud__Ad_Sales_Product_Template__c') {
      switch(obj.API_Name) {
        case 'adsalescloud__Deliver_Impressions__c':
          if(lineItemTypeValue === 'Standard' || lineItemTypeValue === 'Bulk') {
            show = true;
            disable = false;
          } else if(lineItemTypeValue === 'Preferred Deal') {
            show = true;
            disable = true;
            component.set('v.record.adsalescloud__Deliver_Impressions__c', 'Frontloaded');
          } else {
            show = false;
          }
          break;
        case 'adsalescloud__Display_Creatives__c':
          if(inventoryType === 'Standard' && lineItemTypeValue !== 'Preferred Deal' && lineItemTypeValue !== 'Click Tracking Only') {
            show = true;
            disable = false;
          } else {
            show = false;
            disable = false;
            component.set('v.record.adsalescloud__Display_Creatives__c', null);
          }
          break;
        case 'adsalescloud__Display_Companions__c':
          if(inventoryType === 'Video VAST' && lineItemTypeValue !== 'Preferred Deal') {
            show = true;
            disable = false;
          } else {
            show = false;
            disable = false;
            component.set('v.record.adsalescloud__Display_Companions__c', null);
          }
          break;
        case 'adsalescloud__Rotate_Creatives__c':
          if(lineItemTypeValue !== 'Preferred Deal') {
            show = true;
            disable = false;
            if(inventoryType !== 'Video VAST'){
              var keys = Object.keys(obj.dependentPickListProperty);
              for(var j=0;j<keys.length;j++){
                var valArr = Array.from(obj.dependentPickListProperty[keys[j]]);
                var ind =valArr.indexOf('Sequential');
                if(ind !== -1){
                  valArr.splice(ind,1);
                }
                obj.dependentPickListProperty[keys[j]] = valArr;
              }
            }
          } else {
            show = false;
            disable = false;
            component.set('v.record.adsalescloud__Rotate_Creatives__c', null);
          }
          break;
        default:
      }
    }
    obj['show'] = show;
    obj['disable'] = disable;
  }

});