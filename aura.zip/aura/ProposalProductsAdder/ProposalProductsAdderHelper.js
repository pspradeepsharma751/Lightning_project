({
  doInit: function(component) {
    this.fetchData(component, 'getTimezoneOffsetMinutes', {
      'timezoneId': component.get('v.proposal.adsalescloud__Time_Zone__c')
    }, function(response) {
      component.set('v.timezoneOffsetMinutes', response);
    }, function(error) {
      component.set('v._error', error);
    });
  },
  createProposalItems: function(component, proposalItems, recordId) {
    var self = this;
    this.fetchData(component, 'createProposalItems',
      {
        'proposalItemJSON': JSON.stringify(proposalItems),
        'recordId': recordId,
        'otherRecordId':component.get('v.otherRecordId')
      }, function(response) {
        if(response.IsSuccess) {
          self.showToast();
        } else {
          self.handleErrorOfOppItemsCreation(response, component);
        }
      }, function(error) {
        component.set('v._error', error);
      });
  },
  handleErrorOfOppItemsCreation: function(response, component) {
    var oppProdTable = component.find('opportunityProductTable');
    oppProdTable.handleError(response);
  },
  toggleProductSelection: function(component) {
    var proposalItems = component.get('v.proposal_items');
    if(proposalItems.length > 0) {
      component.set('v.showProductSelection', false);
    } else {
      component.set('v.showProductSelection', true);
    }
  },
  showToast: function() {
    $A.get('e.force:refreshView').fire();
    $A.get('e.force:closeQuickAction').fire();
  }
});