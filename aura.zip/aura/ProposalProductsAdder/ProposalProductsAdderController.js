({
  doInit: function(component, event, helper) {
    helper.doInit(component);
  },
  createPropProd: function(component, event, helper) {
    var selectedProducts = event.getParam('_selected_products');
    component.set('v.proposal_items', selectedProducts);
    helper.toggleProductSelection(component);
    component.set('v.headerTitle', 'Edit Selected Products');
  },
  handlePropProducts: function(component, event, helper) {
    var command = event.getParam('command');
    if(command === 'save') {
      var proposalItems = component.get('v.proposal_items');
      var recordId = component.get('v.proposal.Id');
      if(proposalItems.length > 0) {
        helper.createProposalItems(component, proposalItems, recordId);
      }
    } else if(command === 'cancel') {/*
      var proposal_items =  JSON.parse(JSON.stringify(component.get('v.proposal_items')));
      component.set('v.proposal_items', []);
        component.set('v.proposal_items', proposal_items);
        helper.toggleProductSelection(component);*/
      component.set('v.showProductSelection', true);
      component.set('v.headerTitle', 'Add Products');
      //helper.toggleProductSelection(component);
      //helper.retrieveProposal(component);
    }
  }

});