({
    doInit : function(component, event, helper){
        var action = component.get("c.getSchedulesPerHour");
        action.setCallback(this, function(response){
            if(response.getState() === "SUCCESS"){
                component.set("v.noOfSchedules", response.getReturnValue());
            }
            else{
                component.set('v.message','ERROR occured while getting Error Log Size');
                component.set('v.messageType', $A.get("$Label.c.ERROR"));
            }
        });
        $A.enqueueAction(action);
    },
	createSchedules : function(component, event, helper) {
		helper.createSchedules(component);
	},
    manageSchedules : function(component, event, helper) {
        if((typeof sforce != 'undefined') && sforce && (!!sforce.one))
           // window.location.href = "/lightning/setup/ScheduledJobs/home";
        {
            window.open("/lightning/setup/ScheduledJobs/home");
        }
        else{
            //window.location.href = "/08e";
            window.open("/08e");
        }
        
    },
})