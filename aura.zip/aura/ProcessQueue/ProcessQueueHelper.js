({
    createSchedules : function(component) {
        var noOfSchedules = component.get("v.noOfSchedules");
        noOfSchedules = $A.util.isEmpty(noOfSchedules)?null:noOfSchedules.toString();
        if(noOfSchedules == null || (noOfSchedules.toString().indexOf('.')<0  &&  parseInt(noOfSchedules) >0 &&  parseInt(noOfSchedules) <=60)){
            var action = component.get("c.createSchedule");
            action.setParams({"totalSchedules" : noOfSchedules});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    if(JSON.parse(response.getReturnValue()).status === "OK"){
                    component.set('v.message','Processing Queue scheduled successfully');
                    component.set('v.messageType', $A.get("$Label.c.SUCCESS"));
                    }
                    else{
                        //component.set('v.message','Processing Queue already scheduled. Please click Manage Schedule and delete the existing scheduled jobs to reschedule.');
                        component.set('v.message',JSON.parse(response.getReturnValue()).message);
                        component.set('v.messageType', "info");
                    }
                }
                else{
                    component.set('v.message','Error occured while scheduling the Processing Queue');
                    component.set('v.messageType', $A.get("$Label.c.ERROR"));
                }
            });
            $A.enqueueAction(action);
        }
        else{
            component.set('v.message','Please provide a valid integer to create schedules for Processing Queue<br>Valid range: 1-60');
            component.set('v.messageType', $A.get("$Label.c.ERROR"));
        }
    },
})