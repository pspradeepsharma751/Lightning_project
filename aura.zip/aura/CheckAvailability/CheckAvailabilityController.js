({
    gotToRecord: function(component, event, helper) {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": component.get('v.recordId'),
            "slideDevName": "detail"
        });
        navEvt.fire();
    },
    
    doInit: function(component, event, helper) {
        var startDate = component.get('v.startDate');
        var endDate = component.get('v.endDate');
        var itemName = component.get('v.itemName');
        var titleMessage = component.get('v.titleMessage');
        titleMessage = 'Check Availability for ' + itemName + ': ' + new Date(startDate).toLocaleString() + ' to ' + new Date(endDate).toLocaleString();
        component.set('v.titleMessage', titleMessage);
    }
    })