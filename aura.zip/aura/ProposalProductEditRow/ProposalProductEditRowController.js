({
    doInit: function(component, event, helper) {
        helper.initializeUtilsHelper(component);
        if(window.location.host.indexOf('lightning') >= 0) {
            component.set('v.lightning', true);
        }
        helper.doInit(component);
        helper.calculateQtyNetCost(component);
    },
    checkError: function(component, event, helper) {
        if(component.get('v.item.start_date')){
            component.set('v.item.errors.start_date.error', '');
        }
        else {
            component.set('v.item.errors.start_date.error', 'true');
        }
        if(component.get('v.item.end_date')){
            component.set('v.item.errors.end_date.error', '');
        }
        else {
            component.set('v.item.errors.end_date.error', 'true');
        }
        var proposalItem = component.get('v.item');
        if(!$A.util.isEmpty(proposalItem.quantity)) {
            component.set('v.item.errors.quantity.msg', '');
            if(parseInt(proposalItem.quantity) < 1 && !(proposalItem.lineItemType === 'Price Priority' || proposalItem.lineItemType === 'Click Tracking Only')){
                component.set('v.item.errors.quantity.msg', 'Minimum value 1');
            }
        }
        else {
            component.set('v.item.errors.quantity.msg', 'Value is required');
        }
    },
    showModal: function(component) {
        var flag = component.get('v.showModal');
        flag = !flag;
        component.set('v.showModal', flag);
    },
    quantityChangeHandler: function(component, event, helper) {
        var item = component.get('v.item');
        if($A.util.isEmpty(item.quantity)) {
            item.errors.quantity.msg = 'Value is required';
        }
        else if(item.quantity < 1 && (item.lineItemType !== 'Price Priority' || item.lineItemType !== 'Click Tracking Only')) {
            item.errors.quantity.msg = 'Minimum value 1';
        }
            else {
                item.errors.quantity.msg = '';
            }
        if(item.quantity > 0 && (item.lineItemType === 'Price Priority' || item.lineItemType === 'Click Tracking Only'))
        {item.limitType = 'Lifetime';}
        item.isModified = true;
        component.set("v.isAnythingChanged" , true);
        component.set('v.item', item);
        helper.calculateTotalCost(component);
    },
    calculateQtyNetCost: function(component, event, helper) {
		var item = component.get("v.item");
        var startDate = new Date(item.start_date);
        var endDate = new Date(item.end_date);
        if(endDate < startDate){
            startDate.setDate(startDate.getDate() + 1);
            item.end_date = startDate.toISOString();
        }
        item.isModified = true;
        component.set("v.isAnythingChanged" , true);
        component.set("v.item", item);
        helper.calculateQtyNetCost(component);
        helper.refreshUI(component);
    },
    countSelected : function(component, event, helper){
        var selectedItems = component.get("v.selectedItems");
        if(event.getSource().get("v.checked"))
            selectedItems--;
        else
            selectedItems++;
        component.set("v.selectedItems", selectedItems < 0 ? 0 : selectedItems);
    }, 
});