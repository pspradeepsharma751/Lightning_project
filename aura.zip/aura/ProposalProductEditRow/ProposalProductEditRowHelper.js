({
    doInit : function(component){
        this.durationDays = function(startDate, endDate, timezone){
            var startDateObj = this.getDateObjectInSpecificTimezone(startDate, timezone);
            var endDateObj = this.getDateObjectInSpecificTimezone(endDate, timezone);
            return Math.ceil((endDateObj - startDateObj) / (1000*60*60*24));
        }
    },
	calculateQtyNetCost: function(component) {
        var item = component.get('v.item');
        var startDate = item.start_date;
        var endDate = item.end_date;          
        //component.set("v.item.errors.start_date.error", "");
        //component.set("v.item.errors.end_date.error" , "");
        
        if(startDate && endDate) {  
            if(item.rate_type === 'CPD') {
                var days = this.durationDays(item.start_date, item.end_date, item.timezone);                
                item.quantity = days;
            }
        }
        else{
            /*if(!startDate){
                component.set("v.item.errors.start_date.error", "true");
            }
            if(!endDate){
                component.set("v.item.errors.end_date.error" , "true");
            }*/
            item.quantity = 0;
        }
        if(item.rate_type === 'Flat Fee'){
            item.quantity = 1;
        }
        component.set('v.item', item);
        this.calculateTotalCost(component); 
    },
    calculateTotalCost : function(component){
        var item = component.get("v.item"); 
        
        if(item.lineItemType === "Price Priority"){
            if(item.limitType === "Lifetime"){
                item.totalCost = item.salesPrice * item.quantity;
            }
            else if(item.limitType === "None" || item.limitType == null){
                item.totalCost = 0;
            }
            else if(item.limitType === "Daily"){
                item.totalCost = item.salesPrice * (item.quantity *  this.durationDays(item.start_date, item.end_date, item.timezone));
            }
        }
        else{
            if(item.rate_type.indexOf("CPM") == -1){
                item.totalCost = item.quantity * item.net_rate;
            }
            else{
                item.totalCost = item.quantity * item.net_rate / 1000;
            }
        }
        component.set("v.item", item);
    },
    refreshUI : function(component){
        let item = component.get("v.item");
        component.set("v.item", null); 
        component.set("v.item", item);
    },
    
})